/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015 - 2020, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.services.drive.model.File;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.AddSheetRequest;
import com.google.api.services.sheets.v4.model.AppendValuesResponse;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetRequest;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetResponse;
import com.google.api.services.sheets.v4.model.CellData;
import com.google.api.services.sheets.v4.model.DeleteSheetRequest;
import com.google.api.services.sheets.v4.model.GridData;
import com.google.api.services.sheets.v4.model.GridProperties;
import com.google.api.services.sheets.v4.model.Request;
import com.google.api.services.sheets.v4.model.Response;
import com.google.api.services.sheets.v4.model.RowData;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.Spreadsheet;
import com.google.api.services.sheets.v4.model.UpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.snaplogic.api.ConfigurationException;
import com.snaplogic.api.ExecutionException;
import com.snaplogic.api.LifecycleCallback;
import com.snaplogic.api.LifecycleEvent;
import com.snaplogic.common.SnapType;
import com.snaplogic.common.properties.builders.PropertyBuilder;
import com.snaplogic.snap.api.Document;
import com.snaplogic.snap.api.PropertyValues;
import com.snaplogic.snap.api.SnapCategory;
import com.snaplogic.snap.api.SnapDataException;
import com.snaplogic.snap.api.capabilities.Category;
import com.snaplogic.snap.api.capabilities.General;
import com.snaplogic.snap.api.capabilities.Inputs;
import com.snaplogic.snap.api.capabilities.Outputs;
import com.snaplogic.snap.api.capabilities.Version;
import com.snaplogic.snap.api.capabilities.ViewType;
import com.snaplogic.snap.api.transform.ObjectSizeCalculator;
import com.snaplogic.snap.schema.api.Schema;
import com.snaplogic.snap.schema.api.SchemaBuilder;
import com.snaplogic.snap.schema.api.SchemaProvider;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;

import static com.snaplogic.snap.Utils.MIN_RETRIES;
import static com.snaplogic.snap.Utils.MIN_RETRY_INTERVAL;
import static com.snaplogic.snap.Utils.RETRIES_PROP;
import static com.snaplogic.snap.Utils.RETRY_INTERVAL_PROP;
import static com.snaplogic.snap.Utils.evalIntProperty;
import static com.snaplogic.snaps.google.spreadsheet.Constants.GOOGLE_SPREADSHEET_MIME_TYPE;
import static com.snaplogic.snaps.google.spreadsheet.Constants.SHEET_1;
import static com.snaplogic.snaps.google.spreadsheet.Constants.VERSION_4;
import static com.snaplogic.snaps.google.spreadsheet.Messages.*;

/**
 * Snap to write data to a worksheet in a spreadsheet.
 *
 * @author smudassir
 */
@Inputs(min = 1, max = 1, accepts = {ViewType.DOCUMENT})
@Outputs(min = 0, max = 1, offers = {ViewType.DOCUMENT})
@General(title = WRITER_TITLE, purpose = WRITER_DESC)
@Version(snap = 1)
@Category(snap = SnapCategory.WRITE)
public class WorksheetWriter extends SpreadsheetsBase implements LifecycleCallback {
    private static final Logger LOG = LoggerFactory.getLogger(WorksheetWriter.class);
    private static final String BATCH_VALUE_INPUT_PROP = "batchValueInputProp";
    private static final String ROWS = "ROWS";
    private static final String TEMP_SHEET = "TempSheet";
    private static final String PATTERN_A1_CELL = "[A-Za-z]{1,3}0*[1-9]\\d*";
    private static final String PATTERN_A1_CELL_GROUPS = "([A-Za-z]+)|(\\d+)";
    private static final String NO_SHEET = "No sheet with id:";
    private static final int MEGA = 1048576;
    // Google Sheets API limits the payload size to 10MB. Payload is a Java List of List object.
    // The Snap estimates the payload size by summing the string length of each cell. Due to the
    // overhead of the Java object 2MB is chosen so that the payload Java object does not exceed
    // 10MB limit. If the average cell size is relatively small, The row count in a batch should
    // be limited so that the payload would not exceed 10MB limit.
    private static final int MAX_PAYLOAD_BYTES = 2 * MEGA;
    private static final int GOOGLE_SHEETS_MAX_COLUMN_COUNT = 18278;
    private boolean isFirstDocument = true;
    private boolean isFirstBatchWritten = false;
    private boolean isSheet1ToBeDeleted;
    protected int validRecordCount = 0;
    private int invalidRecordCount = 0;
    protected List<List<Object>> buffer = new ArrayList<>();
    protected String spreadsheetId;
    // maximum row count limit in batch write mode
    private static final int DEFAULT_ROWCOUNT_PER_BATCH = 1000;
    private Set<String> keys;
    private int payloadBytes;
    private int lastRowWritten = 0;
    private String columnWriteRange = null;
    private final ObjectSizeCalculator objectSizeCalculator = new ObjectSizeCalculator();
    // value input options
    private static final String VALUE_INPUT_OPTION_RAW = "RAW";
    private static final String VALUE_INPUT_OPTION_USER_ENTERED = "USER_ENTERED";
    private static final Set<String> VALUE_INPUT_OPTIONS = ImmutableSet.of(
            VALUE_INPUT_OPTION_RAW, VALUE_INPUT_OPTION_USER_ENTERED);
    private String valueInputOption;

    @Override
    public boolean isReadHeaderPropertyRequired() {
        return false;
    }

    @Override
    void defineAdditionalProperties(PropertyBuilder propertyBuilder) {
        propertyBuilder.describe(BATCH_VALUE_INPUT_PROP,
                BATCH_VALUE_INPUT_LABEL, BATCH_VALUE_INPUT_DESC)
                .expression()
                .withAllowedValues(VALUE_INPUT_OPTIONS)
                .defaultValue(VALUE_INPUT_OPTION_RAW)
                .add();
    }

    @Override
    public void configureAdditional(PropertyValues propertyValues) {
        //  sheet names can be evaluated from pipeline parameters
        if (evalSheetNames(null)) {
            throw new ConfigurationException(ERR_SHEET_NAMES)
                    .withReason(REASON_SHEET_NAMES)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
        overwriteWorksheet = Boolean.TRUE.equals(propertyValues.get(KEY_OVERWRITE_WORKSHEET));
        writeHeaderRow = Boolean.TRUE.equals(propertyValues.get(KEY_WRITE_HEADER_ROW));
        ((SheetsApiAccount) googleAccount).setSheetsAPIversion(VERSION_4);
        valueInputOption = StringUtils.defaultIfBlank(propertyValues.get(BATCH_VALUE_INPUT_PROP),
                VALUE_INPUT_OPTION_RAW);
        numOfRetries = evalIntProperty(propertyValues.getAsExpression(RETRIES_PROP), null,
                overwriteWorksheet ? DEFAULT_RETRIES : 0, MIN_RETRIES, errorViews);
        retryInterval = evalIntProperty(propertyValues.getAsExpression(RETRY_INTERVAL_PROP),
                null, MIN_RETRY_INTERVAL, MIN_RETRY_INTERVAL, errorViews);
        writeMode =  StringUtils.defaultIfBlank(propertyValues.get(KEY_WRITE_MODE),
                WRITE_MODE_OPTION_CREATE);
        if (!WRITE_MODE_OPTIONS.contains(writeMode)) {
            throw new ConfigurationException(ERR_INVALID_WRITE_MODE)
                    .withReason(ERR_INVALID_WRITE_MODE_REASON)
                    .withResolution(ERR_INVALID_WRITE_MODE_RESOLUTION);
        }
        cellReference = validateCellReference(propertyValues.get(KEY_CELL_REFERENCE));
        if (!StringUtils.isBlank(cellReference)) {
            cellReference = cellReference.toUpperCase();
        }
    }

    @Override
    public void process(Document document, String inputViewName) {
        Object data = document.get();
        if (!(data instanceof Map)) {
            SnapDataException dataException = new SnapDataException(ERR_INVALID_INPUT_MSG)
                    .withReason(ERR_INVALID_INPUT_REASON)
                    .withResolution(ERR_INVALID_INPUT_RESOLUTION);
            errorViews.write(dataException, document);
            return;
        }
        Map<String, Object> record = ((Map) data);
        processBatch(document, record);
    }

    @Override
    protected void processAdditional(Document document, String inputViewName) {
        // No-Op
    }

    @Override
    public void handle(LifecycleEvent event) {
        switch (event) {
            case SUCCESS:
                if (!buffer.isEmpty()) {
                    writeBatch();
                }
                if (validRecordCount > 0 || invalidRecordCount > 0) {
                    Map<String, Integer> data = new LinkedHashMap<>(2);
                    data.put(VALID_RECORD_COUNT, writeHeaderRow && validRecordCount > 0 ?
                            --validRecordCount : validRecordCount);
                    data.put(INVALID_RECORD_COUNT, invalidRecordCount);
                    outputViews.write(documentUtility.newDocument(data));
                }
        }
    }

    @Override
    public String getDescription() {
        return WRITTEN;
    }

    private void processBatch(Document document, Map<String, Object> record) {
        if (isFirstDocument) {
            int columnCount = record.size();
            if (columnCount == 0) {
                return;
            }
            initWorksheetV4();

            keys = record.keySet();
            if (writeHeaderRow) {
                updatePayloadSize(keys);
                buffer.add(new ArrayList<>(keys));
            }
            isFirstDocument = false;
        }
        RowValues rowValues = getCellValues(record);
            // The purpose of the following test is to make sure the payload would not exceed
            // the 10MB limit. If the average size of cell values are large, MAX_PAYLOAD_BYTES will
            // kick in first while, if cell values are small, rowCountPerBatch will be used to
            // determine when the batch should be sent.
        if (payloadBytes > MAX_PAYLOAD_BYTES || buffer.size() >= DEFAULT_ROWCOUNT_PER_BATCH) {
            writeBatch();
            payloadBytes = rowValues.getSize();
        }
        buffer.add(rowValues.getValues());
        document.acknowledge();
    }

    /**
     * Initializes worksheet for Sheets API v4.
     */
    protected void initWorksheetV4() {
        try {
            boolean newSpreadsheetCreated = false;
            // Retrieving null for spreadsheetId is valid only for "create" write mode
            spreadsheetId = getSpreadsheetId(googleDrive, spreadsheetNameOrId ,
                    writeMode.equals(WRITE_MODE_OPTION_CREATE));
            if (StringUtils.isBlank(spreadsheetId)) {
                spreadsheetId = createSpreadsheet();
                newSpreadsheetCreated = true;
            }
            List<Sheet> worksheetList = getWorksheets(sheets, spreadsheetId);
            Integer existingWorksheetId = null;
            Integer defaultWorksheetId = null;
            for (Sheet worksheet : worksheetList) {
                SheetProperties sheetProperties = worksheet.getProperties();
                String existingWorksheetTitle = sheetProperties.getTitle();
                if (worksheetName.equalsIgnoreCase(existingWorksheetTitle)) {
                    existingWorksheetId = sheetProperties.getSheetId();
                }
                if (isSheet1ToBeDeleted && SHEET_1.equalsIgnoreCase(existingWorksheetTitle)) {
                    defaultWorksheetId = sheetProperties.getSheetId();
                }
            }
            if (writeMode.equals(WRITE_MODE_OPTION_CREATE)) {
                if (existingWorksheetId == null) {
                    createSheet(worksheetName);
                    if (newSpreadsheetCreated) {
                        deleteSheet(defaultWorksheetId);
                    }
                } else {
                    if (newSpreadsheetCreated) {
                        // Overwrite found blank default "Sheet1" with user requested "Sheet1"
                        replaceExistingWorksheet(1, existingWorksheetId);
                    } else {
                        if (overwriteWorksheet) {
                            replaceExistingWorksheet(worksheetList.size(), existingWorksheetId);
                        } else {
                            throw new SnapDataException(ERR_CREATE_WORKSHEET + ": " + ERR_WORKSHEET_EXISTS_REASON)
                                    .formatWith(worksheetName)
                                    .withReason(ERR_WORKSHEET_EXISTS_REASON)
                                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
                        }
                    }
                }
            } else if (writeMode.equals(WRITE_MODE_OPTION_EDIT)) {
                if (existingWorksheetId == null) {
                    throw new SnapDataException(ERR_INIT_WORKSHEET + ": " + ERR_WORKSHEET_NOT_FOUND_REASON)
                            .formatWith(worksheetName)
                            .withReason(ERR_WORKSHEET_NOT_FOUND_REASON)
                            .withResolution(RESOLUTION_ADDRESS_ISSUE);
                }
            } else {
                throw new ConfigurationException(ERR_INVALID_WRITE_MODE)
                        .withReason(ERR_INVALID_WRITE_MODE_REASON)
                        .withResolution(ERR_INVALID_WRITE_MODE_RESOLUTION);
            }
        } catch (SnapDataException sde) {
            throw new SnapDataException(sde.getMessage())
                    .withReason(sde.getReason())
                    .withResolution(sde.getResolution());
        } catch (ConfigurationException e) {
           throw e;
        } catch (Throwable t) {
            throw new SnapDataException(t, ERR_INIT_WORKSHEET)
                    .formatWith(worksheetName)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
    }

    /**
     * Replaces an existing worksheet with a new one of the name defined in the snap properties.
     *
     * @param worksheetCount the total number of worksheets present in a spreadsheet
     * @param replacedWorksheetId the id of the worksheet to be replaced
     */
    private void replaceExistingWorksheet(int worksheetCount, Integer replacedWorksheetId) {
        Integer tempWorksheetId = null;
        if (worksheetCount == 1) {
            tempWorksheetId = TEMP_SHEET.equals(worksheetName) ?
                    createSheet(SHEET_1) : createSheet(TEMP_SHEET);
        }
        deleteSheet(replacedWorksheetId);
        createSheet(worksheetName);
        if (tempWorksheetId != null) {
            deleteSheet(tempWorksheetId);
        }
    }

    private Spreadsheet deleteSheet(int sheetId) {
        DeleteSheetRequest deleteSheetRequest = new DeleteSheetRequest().setSheetId(sheetId);
        Request request = new Request().setDeleteSheet(deleteSheetRequest);
        BatchUpdateSpreadsheetRequest requestBody = new BatchUpdateSpreadsheetRequest()
                .setRequests(ImmutableList.of(request));
        requestBody.setIncludeSpreadsheetInResponse(true);
        try {
            return Failsafe.with(getRetryPolicy(numOfRetries, retryInterval))
                    .onFailedAttempt(e -> LOG.warn("Failed to delete worksheet: {} in spreadsheet" +
                    ": {} for overwriting, {}", worksheetName, spreadsheetNameOrId, e.getMessage()))
                    .get(context -> {
                        logRetryAttempt(context, LOG);
                        return deleteSheet(sheetId, requestBody);
                    });
        } catch (Throwable t) {
            Throwable t2 =  t instanceof FailsafeException ? t.getCause() : t;
            if (t2 instanceof IOException &&
                    StringUtils.containsIgnoreCase(t2.getMessage(), NO_SHEET)) {
                // Worksheet does not exists. Return quietly.
                LOG.warn("Failed to delete worksheet: {} in spreadsheet: {} for overwriting, {}",
                        worksheetName, spreadsheetNameOrId, t2.getMessage());
                return null;
            }
            throw new SnapDataException(t2, ERR_DELETE_WORKSHEET)
                    .formatWith(worksheetName, spreadsheetNameOrId)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
    }

    private Spreadsheet deleteSheet(int sheetId, BatchUpdateSpreadsheetRequest requestBody)
            throws IOException {
        BatchUpdateSpreadsheetResponse response = sheets.spreadsheets()
                .batchUpdate(spreadsheetId, requestBody)
                .execute();
        Spreadsheet updatedSpreadsheet = response.getUpdatedSpreadsheet();
        if (updatedSpreadsheet == null) {
            throw new IOException(String.format(ERR_DELETE_WORKSHEET_NO_ERROR, worksheetName));
        }
        // Check if successfully deleted since intermittently the delete request completes without
        // error, but the sheet still exists.
        for (Sheet sheet : updatedSpreadsheet.getSheets()) {
            if (sheetId == sheet.getProperties().getSheetId()) {
                // throw exception so that delete can be retried
                throw new IOException(String.format(ERR_DELETE_WORKSHEET_NO_ERROR, worksheetName));
            }
        }
        return updatedSpreadsheet;
    }

    /**
     * Writes a batch of rows into a worksheet,
     */
    protected void writeBatch() {
        try {
            ValueRange valueRange = new ValueRange().setValues(buffer)
                    .setMajorDimension(ROWS);

            String writeRange = null;

            if (writeMode.equals(WRITE_MODE_OPTION_CREATE) || StringUtils.isBlank(cellReference)) {
                writeRange = worksheetName;
            } else {
                int endRow = 0;

                if (!isFirstBatchWritten) {
                    // For the first batch, calculate column range and appropriate row values from
                    // cell ref start point (cell ref serves as top left cell of written data)
                    Pattern a1CellGroupsPattern = Pattern.compile(PATTERN_A1_CELL_GROUPS);
                    Matcher matcher = a1CellGroupsPattern.matcher(cellReference);
                    matcher.find();
                    String rangeStartColumnCode = matcher.group(1).toUpperCase();

                    columnWriteRange = computeColumnRange(rangeStartColumnCode,
                            buffer.get(0).size());

                    matcher.find();
                    int startRowNum = Integer.parseInt(matcher.group(2));
                    lastRowWritten = startRowNum - 1;
                    // end row # = cell ref row # + # of rows in buffer - 1
                    // (-1 because start row is inclusive)
                    endRow = startRowNum + buffer.size() - 1;

                    isFirstBatchWritten = true;
                } else {
                    endRow = lastRowWritten + buffer.size();
                }

                writeRange = String.format(columnWriteRange, worksheetName,
                        lastRowWritten + 1, endRow);

                lastRowWritten = endRow;
            }

            if (StringUtils.isBlank(cellReference) || writeMode.equals(WRITE_MODE_OPTION_CREATE)) {
                // Default #append behavior is to automatically add data following the last row of
                // content of the last logical table in the sheet
                // (see https://developers.google.com/sheets/api/guides/values#appending_values)
                AppendValuesResponse resp = sheets.spreadsheets().values()
                        .append(spreadsheetId, writeRange, valueRange)
                        .setValueInputOption(valueInputOption)
                        .execute();
                validRecordCount += resp.getUpdates().getUpdatedRows();
            } else {
                UpdateValuesResponse resp = sheets.spreadsheets().values()
                        .update(spreadsheetId, writeRange, valueRange)
                        .setValueInputOption(valueInputOption)
                        .execute();
                validRecordCount += resp.getUpdatedRows();
            }
        } catch (SocketTimeoutException e) {
            // Intermittently, socket timeout may occur even if data is written successfully.
            LOG.warn("Timed out while a batch of data is written to the worksheet '{}' " +
                    "in the spreadsheet '{}'", worksheetName, spreadsheetNameOrId, e);
        } catch (IOException|SnapDataException e) {
            // there is no per-row error list from server
            // all data in the buffer should be routed to the error view
            int failedRecords = buffer.size();
            invalidRecordCount += failedRecords;
            SnapDataException ex;
            if (e instanceof SnapDataException) {
                ex = (SnapDataException) e;
            } else {
                ex = new SnapDataException(e, ERR_BATCH_WRITE)
                        .formatWith(failedRecords, worksheetName)
                        .withReason(e.getMessage())
                        .withResolution(RESOLUTION_ADDRESS_ISSUE);
            }
            boolean isHeader = writeHeaderRow;
            for (List<Object> row : buffer) {
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                Iterator<Object> it = row.iterator();
                Map<String, Object> data = new LinkedHashMap<>(keys.size());
                for (String key : keys) {
                    data.put(key, it.hasNext() ? it.next() : StringUtils.EMPTY);
                }
                errorViews.write(ex, data);
            }
        } finally {
            buffer.clear();
        }
    }

    private String createSpreadsheet() throws Throwable {
        try {
            File spreadsheet = new File();
            spreadsheet.setName(spreadsheetNameOrId);
            spreadsheet.setMimeType(GOOGLE_SPREADSHEET_MIME_TYPE);
            spreadsheet = createGoogleDriveFile(spreadsheet);
            if (!SHEET_1.equalsIgnoreCase(worksheetName)) {
                isSheet1ToBeDeleted = true;
            }
            return spreadsheet.getId();
        } catch (IOException e) {
            throw new ExecutionException(e, ERR_CREATE_SPREADSHEET)
                    .formatWith(spreadsheetNameOrId)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
    }

    protected File createGoogleDriveFile(File file) throws Throwable {
        try {
            return Failsafe.with(getRetryPolicy(numOfRetries, retryInterval))
                    .onFailedAttempt(e -> LOG.warn("Failed to create GoogleDrive file: {}, {}",
                            file.getName(), e.getMessage()))
                    .get(context -> {
                        logRetryAttempt(context, LOG);
                        if (keyIncludeSharedDrive) {
                            return googleDrive.files()
                                    .create(file)
                                    .setSupportsAllDrives(true)
                                    .execute();
                        } else {
                            return googleDrive.files().create(file).execute();
                        }
                    });
        } catch (Throwable t) {
            throw t instanceof FailsafeException ? t.getCause() : t;
        }
    }

    /**
     * Creates a worksheet.
     *
     * @param sheetTitle    - worksheet name
     * @return sheet ID
     */
    protected Integer createSheet(String sheetTitle) {
        try {
            SheetProperties sheetProperties = new SheetProperties();
            sheetProperties.setTitle(sheetTitle);
            GridProperties gridProperties = new GridProperties();
            gridProperties.setColumnCount(1);
            gridProperties.setRowCount(1);
            sheetProperties.setGridProperties(gridProperties);
            AddSheetRequest addSheetRequest = new AddSheetRequest();
            addSheetRequest.setProperties(sheetProperties);
            Request request = new Request();
            request.setAddSheet(addSheetRequest);
            BatchUpdateSpreadsheetRequest batchUpdateSpreadsheetRequest =
                    new BatchUpdateSpreadsheetRequest();
            batchUpdateSpreadsheetRequest.setRequests(ImmutableList.of(request));
            Sheets.Spreadsheets.BatchUpdate batchUpdate = sheets.spreadsheets()
                    .batchUpdate(spreadsheetId, batchUpdateSpreadsheetRequest);
            return Failsafe.with(getRetryPolicy(numOfRetries, retryInterval))
                    .onFailedAttempt(e -> LOG.warn("Failed to create worksheet: {} in " +
                    "spreadsheet: {}, {}", worksheetName, spreadsheetNameOrId, e.getMessage()))
                    .get(context -> {
                        logRetryAttempt(context, LOG);
                        return createSheet(batchUpdate, sheetTitle);
                    });
        } catch (Throwable t) {
            Throwable t2 =  t instanceof FailsafeException ? t.getCause() : t;
            throw t2 instanceof SnapDataException ? (SnapDataException) t2 :
                    new SnapDataException(t2, ERR_CREATE_WORKSHEET)
                    .formatWith(sheetTitle)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
    }

    private int createSheet(Sheets.Spreadsheets.BatchUpdate batchUpdate, String sheetTitle)
            throws IOException {
        BatchUpdateSpreadsheetResponse response = batchUpdate.execute();
        List<Response> responses = response.getReplies();
        if (CollectionUtils.isNotEmpty(responses)) {
            return responses.get(0)
                    .getAddSheet()
                    .getProperties()
                    .getSheetId();
        }
        throw new SnapDataException(ERR_CREATE_WORKSHEET)
                .formatWith(sheetTitle)
                .withReason(REASON_EMPTY_RESPONSE)
                .withResolution(RESOLUTION_ADDRESS_ISSUE);
    }

    private RowValues getCellValues(Map<String, Object> data) {
        List<Object> result = new ArrayList<>(data.size());
        int rowSize = 0;
        for (String key : keys) {
            Object object = data.get(key);
            Object value;
            if (object == null) {
                value = StringUtils.EMPTY;
            } else if (object instanceof Boolean || object instanceof String ||
                    object instanceof Number) {
                value = object;
            } else {
                value = object.toString();
            }
            rowSize += objectSizeCalculator.calculateObjectSize(value);
            result.add(value);
        }
        payloadBytes += rowSize;
        return new RowValues(result, rowSize);
    }

    private void updatePayloadSize(Set<String> keySet) {
        for (String value : keySet) {
            if (value == null) {
                throw new SnapDataException(ERR_INVALID_KEY)
                        .withReason(REASON_NULL_KEY)
                        .withResolution(RESOLUTION_ADDRESS_ISSUE);
            } else {
                payloadBytes += value.getBytes(StandardCharsets.UTF_8).length;
            }
        }
    }

    /**
     * Computes the column range for a range of data of a specified width, starting from a specified
     * column, and creates a range-format string partially completed with the column range.
     *
     * @param startColumnCode the alphabetical code for the column at which the computed range
     *                        should start, inclusive
     * @param writeRangeWidth the number of columns the computed range should span, inclusive of
     *                        the start column
     * @return a range-format String with the start and end column of the computed range filled in
     */
    protected String computeColumnRange(String startColumnCode, int writeRangeWidth) {
        // convert start col code to start column #
        // For column code with max three letters:
        // [(26^2) * charVal][26 * charVal][charVal]
        int startColumnNum = 0;
        for (int i = 0, power = startColumnCode.length() - 1; i < startColumnCode.length(); i++, power--) {
            int charVal = ((int) startColumnCode.charAt(i)) - 'A' + 1;
            int colVal = (int) (Math.pow(26, power) * charVal);
            startColumnNum += colVal;
        }

        // end col # = start col # + row size - 1 (-1 because start col is inclusive)
        int endColumnNum = startColumnNum + writeRangeWidth - 1;
        if (endColumnNum > GOOGLE_SHEETS_MAX_COLUMN_COUNT) {
            throw new SnapDataException(String.format(ERR_WRITE_RANGE_INVALID, writeRangeWidth, cellReference))
                    .withReason(ERR_WRITE_RANGE_INVALID_MAX_COLUMN_REASON)
                    .withResolution(ERR_WRITE_RANGE_INVALID_MAX_COLUMN_RESOLUTION);
        }

        // convert end col # to end col code
        // Since letters of the start column were converted to a 1-indexed numeric value,
        // subtract 1 from the end column to shift to 0-indexing for each letter calculation
        StringBuilder endColumnCodeBuilder = new StringBuilder();
        while (endColumnNum-- > 26) {
            int columnCharOffset = endColumnNum % 26;
            endColumnCodeBuilder.insert(0, (char) (columnCharOffset + 'A'));
            endColumnNum = endColumnNum / 26;
        }
        endColumnCodeBuilder.insert(0, (char) (endColumnNum + 'A'));
        String endColumnCode = String.valueOf(endColumnCodeBuilder);

        return String.format("%%s!%s%%d:%s%%d", startColumnCode, endColumnCode);
    }

    @Override
    public void defineInputSchema(SchemaProvider provider) {
        // get the spreadsheet and worksheet names
        try {
            evalSheetNames(null);
        } catch (Throwable e1) {
            LOG.warn("Cannot suggest schema as the sheet name does not look static", e1);
            return;
        }

        // read the worksheet if it exists
        List<GridData> values;
        try {
            String spreadsheetId = getSpreadsheetId(googleDrive, spreadsheetNameOrId);
            values = readWorksheet(spreadsheetId, worksheetName);
        } catch (Throwable t) {
            LOG.warn("Spreadsheet/Worksheet does not exist, or cannot be read", t);
            return;
        }

        if (CollectionUtils.isEmpty(values)) {
             // There is no data in the sheet.
             return;
        }

        List<RowData> allRows = values.get(0).getRowData();
        if (allRows == null) {
            // Probably empty worksheet
            return;
        }

        RowData headerRow = allRows.get(0);
        List<CellData> headerColumns = headerRow.getValues();
        List<String> header = new ArrayList<>(headerColumns.size());

        // Get the header columns
        for (CellData headerColumn : headerColumns) {
            String headerName = headerColumn.getFormattedValue();
            if (StringUtils.isBlank(headerName)) {
                // Empty header name
                return;
            }
            if (header.contains(headerName)) {
                // Duplicate header names
                return;
            }
            header.add(headerName);
        }

        if (CollectionUtils.isEmpty(header)) {
            // Empty header
            return;
        }

        // Get the first data row
        Map<Object, Object> firstDataRow;
        try {
            firstDataRow = getRecord(allRows.get(1).getValues(), header);
        } catch (Throwable t) {
            LOG.warn("Error while reading the first data row from the worksheet", t);
            return;
        }
        // Build schema
        for (String inputViewName : provider.getRegisteredViewNames()) {
            SchemaBuilder schemaBuilder = provider.getSchemaBuilder(inputViewName);
            schemaBuilder.type(SnapType.COMPOSITE);
            for (String headerCol : header) {
                Schema colSchema = provider.createSchema(getSnapType(firstDataRow.get(headerCol)),
                        headerCol);
                schemaBuilder.withChildSchema(colSchema);
            }
            schemaBuilder.build();
        }
    }

    private SnapType getSnapType(Object value) {
        if (value instanceof Boolean) {
            return SnapType.BOOLEAN;
        } else if (value instanceof Double) {
            return SnapType.NUMBER;
        } else if (value instanceof LocalDate) {
            return SnapType.DATE;
        } else {
            return SnapType.STRING;
        }
    }

    /**
     * Evaluates a worksheet cell reference to validate its format.
     *
     * @param cellReference the cell reference being validated
     * @return the validated cell reference
     */
    private String validateCellReference(String cellReference) {
        if (!StringUtils.isBlank(cellReference) && !Pattern.matches(PATTERN_A1_CELL, cellReference)) {
            throw new ConfigurationException(ERR_CELL_REFERENCE_INVALID)
                    .withReason(ERR_CELL_REFERENCE_INVALID_REASON)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
        return cellReference;
    }

    private class RowValues {
        private List<Object> values;
        private int size;

        private RowValues(List<Object> values, int size) {
            this.values = values;
            this.size = size;
        }

        public List<Object> getValues() {
            return values;
        }

        private int getSize() {
            return size;
        }
    }
}