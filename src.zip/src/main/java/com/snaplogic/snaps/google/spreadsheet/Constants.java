/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

/**
 * Constants is the container for all the constant values used in this snap pack.
 *
 * @author smudassir
 */
public class Constants {
    static final String SPREADSHEET_AND_DRIVE_SCOPE = "https://www.googleapis.com/auth/spreadsheets " +
            "https://www.googleapis.com/auth/drive";
    static final String SPREADSHEET_SERVICE_NAME = "SnapLogicSpreadsheetIntegration";
    static final String DRIVE_SERVICE_NAME = "SnapLogicDriveIntegration";
    static final String AUTH_ENDPOINT_URL = "https://accounts.google.com/o/oauth2/auth";
    static final String TOKEN_ENDPOINT_URL = "https://oauth2.googleapis.com/token";
    static final String GOOGLE_SPREADSHEET_MIME_TYPE = "application/vnd.google-apps.spreadsheet";
    static final String DEFAULT_OAUTH2_CLIENT_ID =
            "641557182446-rgnujh4f1nm1pvdd1rsqum7ehep574lf.apps.googleusercontent.com";
    static final String DEFAULT_OAUTH2_CLIENT_SECRET =
            "QtNzjPUrnQfJjKgW3l3JdkQN";
    static final String SHEET_1 = "Sheet1";
    static final int VERSION_4 = 4;
    static final String TYPE_DATE = "DATE";
    static final String SPREADSHEETS_FETCH_MODE = "Spreadsheets";
    static final String SPREADSHEETS_AND_WORKSHEETS_FETCH_MODE = "Spreadsheets and Worksheets";

    // OAuth 2.0: Approval prompt options for acquiring refresh tokens
    static final String AUTO = "auto";
    static final String FORCE = "force";
}