/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.common.collect.ImmutableSet;
import com.snaplogic.common.SnapType;
import com.snaplogic.common.properties.SnapProperty;
import com.snaplogic.common.properties.builders.PropertyBuilder;
import com.snaplogic.snap.api.Document;
import com.snaplogic.snap.api.ExpressionProperty;
import com.snaplogic.snap.api.PropertyValues;
import com.snaplogic.snap.api.SnapCategory;
import com.snaplogic.snap.api.SnapDataException;
import com.snaplogic.snap.api.SuggestViewAbortException;
import com.snaplogic.snap.api.capabilities.Category;
import com.snaplogic.snap.api.capabilities.General;
import com.snaplogic.snap.api.capabilities.Inputs;
import com.snaplogic.snap.api.capabilities.Outputs;
import com.snaplogic.snap.api.capabilities.Version;
import com.snaplogic.snap.api.capabilities.ViewType;
import com.snaplogic.snap.schema.api.Schema;
import com.snaplogic.snap.schema.api.SchemaProvider;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import static com.snaplogic.snap.Utils.STAR;
import static com.snaplogic.snap.Utils.defineRetryProperties;
import static com.snaplogic.snap.Utils.getRegexPattern;
import static com.snaplogic.snaps.google.spreadsheet.Constants.VERSION_4;
import static com.snaplogic.snaps.google.spreadsheet.Constants.SPREADSHEETS_FETCH_MODE;
import static com.snaplogic.snaps.google.spreadsheet.Constants.SPREADSHEETS_AND_WORKSHEETS_FETCH_MODE;
import static com.snaplogic.snaps.google.spreadsheet.Messages.*;

/**
 * Snap to browse the google driver folderr and fetch the details of the spreadsheets satisfying
 * the given pattern.
 *
 * @author smudassir
 */
@Inputs(min = 0, max = 1, accepts = {ViewType.DOCUMENT})
@Outputs(min = 1, max = 1, offers = {ViewType.DOCUMENT})
@General(title = BROWSER_TITLE, purpose = BROWSER_DESC)
@Version(snap = 1)
@Category(snap = SnapCategory.READ)
public class SpreadsheetsBrowser extends SpreadsheetsBase {
    private static final Logger LOG = LoggerFactory.getLogger(SpreadsheetsBrowser.class);
    private static final String KEY_NAME_FILTER = "KeyForNameFilter";
    private static final String PROP_FETCH_MODE = "KeyForFetchMode";
    private static final Set<String> ALLOWED_FETCH_MODES = ImmutableSet.of(
            SPREADSHEETS_AND_WORKSHEETS_FETCH_MODE,
            SPREADSHEETS_FETCH_MODE);
    protected ExpressionProperty nameFilter;
    private String fetchMode;

    @Override
    public void defineProperties(final PropertyBuilder propertyBuilder) {
        propertyBuilder.describe(KEY_INCLUDE_SHARED_DRIVES, LABEL_INCLUDE_SHARED_DRIVE, DESC_INCLUDE_SHARED_DRIVE)
                .type(SnapType.BOOLEAN)
                .defaultValue(false)
                .add();
        propertyBuilder.describe(KEY_NAME_FILTER, LABEL_NAME_FILTER, DESC_NAME_FILTER)
                .expression(SnapProperty.DecoratorType.ACCEPTS_SCHEMA)
                .add();

        propertyBuilder.describe(PROP_FETCH_MODE, LABEL_FETCH_MODE, DESC_FETCH_MODE)
                .withAllowedValues(ALLOWED_FETCH_MODES)
                .defaultValue(SPREADSHEETS_AND_WORKSHEETS_FETCH_MODE)
                .add();

        defineRetryProperties(propertyBuilder, RETRIES_DESC, DEFAULT_RETRIES);
    }

    @Override
    void defineAdditionalProperties(PropertyBuilder propertyBuilder) {
        //NO-OP
    }

    @Override
    public void configureAdditional(final PropertyValues propertyValues) {
        nameFilter = propertyValues.getAsExpression(KEY_NAME_FILTER);
        fetchMode = propertyValues.get(PROP_FETCH_MODE);
        // newly added PROP_FETCH_MODE property may break existing pipelines;
        // so make it backward compatible with existing pipelines
        fetchMode = StringUtils.isBlank(fetchMode) ?
                SPREADSHEETS_AND_WORKSHEETS_FETCH_MODE : fetchMode;
        ((SheetsApiAccount) googleAccount).setSheetsAPIversion(VERSION_4);
    }

    @Override
    protected void processAdditional(Document document, String inputViewName) {
        String glob = nameFilter.eval(document);
        Pattern pattern = getRegexPattern(StringUtils.isBlank(glob) ? STAR : glob);
        processV4(pattern, document);
    }

    @Override
    public void defineInputSchemaAdditional(SchemaProvider schemaProvider, List<Schema> schemas) {
        schemas.add(schemaProvider.createSchema(SnapType.STRING, BROWSER_IN_VIEW_FIELD_FILTER));
    }

    @Override
    public boolean isReadHeaderPropertyRequired() {
        return false;
    }

    @Override
    public String getDescription() {
        return StringUtils.EMPTY;
    }

    private void processV4(Pattern pattern, Document document) {
        FileList fileList;
        try {
            fileList = getSpreadSheetList(googleDrive);
        } catch (SnapDataException e) {
            errorViews.write(e, document);
            return;
        }
        try {
            if (fileList != null) {
                for (File file : fileList.getFiles()) {
                    String title = file.getName();
                    if (pattern.matcher(title).matches()) {
                        Map<String, Object> spreadsheetData = new LinkedHashMap<>();
                        spreadsheetData.put(SPREADSHEET_NAME, title);
                        String spreadsheetId = file.getId();
                        spreadsheetData.put(SPREADSHEET_ID, spreadsheetId);
                        List<Map<String, Object>> worksheets = new ArrayList<>();
                        if (fetchMode.equals(SPREADSHEETS_AND_WORKSHEETS_FETCH_MODE) &&
                                StringUtils.isNotBlank(spreadsheetId)) {
                            try {
                                List<Sheet> sheetList = getWorksheets(sheets, spreadsheetId);
                                spreadsheetData.put(WORKSHEETS, worksheets);
                                if (sheetList != null) {
                                    for (Sheet sheet : sheetList) {
                                        SheetProperties sheetProperties = sheet.getProperties();
                                        String sheetTitle = sheetProperties.getTitle();
                                        Integer sheetId = sheetProperties.getSheetId();
                                        Map<String, Object> sheetData = new LinkedHashMap<>(2);
                                        sheetData.put(WORKSHEET_NAME, sheetTitle);
                                        sheetData.put(WORKSHEET_ID, sheetId);
                                        worksheets.add(sheetData);
                                    }
                                }
                            } catch (IOException e) {
                                errorViews.write((SnapDataException)
                                        new SnapDataException(e, ERR_GET_WORKSHEETS)
                                        .formatWith(title)
                                        .withResolution(RESOLUTION_ADDRESS_ISSUE), document);
                            }
                        }
                        outputViews.write(documentUtility.newDocument(spreadsheetData));
                    }
                }
            }
        } catch (SuggestViewAbortException e) {
            throw e;
        } catch (Exception e) {
            errorViews.write((SnapDataException)
                    new SnapDataException(e, ERR_BROWSE_SPREADSHEET)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE), document);
        }
    }
}