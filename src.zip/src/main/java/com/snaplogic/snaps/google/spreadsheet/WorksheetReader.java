/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */
package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.services.drive.Drive;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.CellData;
import com.google.api.services.sheets.v4.model.GridData;
import com.google.api.services.sheets.v4.model.GridProperties;
import com.google.api.services.sheets.v4.model.RowData;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.common.collect.Lists;
import com.snaplogic.api.ExecutionException;
import com.snaplogic.common.SnapType;
import com.snaplogic.common.properties.builders.PropertyBuilder;
import com.snaplogic.snap.api.Document;
import com.snaplogic.snap.api.PropertyValues;
import com.snaplogic.snap.api.SnapCategory;
import com.snaplogic.snap.api.SnapDataException;
import com.snaplogic.snap.api.SuggestViewAbortException;
import com.snaplogic.snap.api.capabilities.Category;
import com.snaplogic.snap.api.capabilities.General;
import com.snaplogic.snap.api.capabilities.Inputs;
import com.snaplogic.snap.api.capabilities.Outputs;
import com.snaplogic.snap.api.capabilities.Version;
import com.snaplogic.snap.api.capabilities.ViewType;
import com.snaplogic.snap.schema.api.Schema;
import com.snaplogic.snap.schema.api.SchemaProvider;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.sf.json.JSONArray;

import static com.snaplogic.snap.Utils.sleepNoInterrupt;
import static com.snaplogic.snaps.google.spreadsheet.Constants.VERSION_4;
import static com.snaplogic.snaps.google.spreadsheet.Messages.*;

/**
 * Snap to read a worksheet in a spreadsheet.
 *
 * @author smudassir
 */
@Inputs(min = 0, max = 1, accepts = {ViewType.DOCUMENT})
@Outputs(min = 1, max = 1, offers = {ViewType.DOCUMENT})
@General(title = READER_TITLE, purpose = READER_DESC)
@Version(snap = 1)
@Category(snap = SnapCategory.READ)
public class WorksheetReader extends SpreadsheetsBase {
    private static final Logger LOG = LoggerFactory.getLogger(WorksheetReader.class);
    private static final String PRESERVE_DATA_TYPES_PROP = "preserveDataTypes";
    private static final String WORKSHEET_BATCH_GET_RANGE_FORMAT = "%s!%s%d:%s%d";
    private static final String VALUE_RENDER_OPTION = "FORMATTED_VALUE";
    private static final String FIRST_COLUMN = "A";
    private static final String LAST_COLUMN = "ZZZ";
    private static final int READ_BATCH_SIZE = 20000; //20K rows

    private boolean preserveDataTypes;

    @Override
    void defineAdditionalProperties(PropertyBuilder propertyBuilder) {
        propertyBuilder.describe(PRESERVE_DATA_TYPES_PROP, PRESERVE_DATA_TYPES_LBL,
                PRESERVE_DATA_TYPES_DESC)
                .type(SnapType.BOOLEAN)
                .add();
    }

    @Override
    public void configureAdditional(PropertyValues propertyValues) {
        headerExists = Boolean.TRUE.equals(propertyValues.get(KEY_HEADER_EXISTS));
        ((SheetsApiAccount) googleAccount).setSheetsAPIversion(VERSION_4);
        preserveDataTypes = Boolean.TRUE.equals(propertyValues.get(PRESERVE_DATA_TYPES_PROP));
    }

    @Override
    protected void processAdditional(Document document, String inputViewName) {
        if (evalSheetNames(document)) {
            errorViews.write((SnapDataException) new SnapDataException(ERR_SHEET_NAMES)
                    .withReason(REASON_SHEET_NAMES)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE), document);
            return;
        }
        googleDrive = googleAccount.connect().getGoogleDrive();
        if (preserveDataTypes) {
            processDataWithGridInfo(document);
        } else {
            processDataNoGridInfo(document);
        }
    }

    /**
     * Process the worksheet data along with the grid data to preserve data types
     * and write to output view
     * @param document
     */
    private void processDataWithGridInfo(Document document) {
        try {
            spreadsheetId = getSpreadsheetId(googleDrive, spreadsheetNameOrId);
            List<GridData> values;
            try {
                @SuppressWarnings("unchecked")
                RetryPolicy retryPolicy = new RetryPolicy()
                        .withMaxRetries(numOfRetries)
                        .withDelay(retryInterval, TimeUnit.SECONDS)
                        .abortOn(SuggestViewAbortException.class, SnapDataException.class);
                values = Failsafe.with(retryPolicy)
                        .onFailedAttempt(failure -> LOG.warn("Failed to read worksheet: {} in " +
                                        "spreadsheet: {}, {}", worksheetName, spreadsheetNameOrId,
                                failure.getMessage()))
                        .get(context -> {
                            logRetryAttempt(context, LOG);
                            return readWorksheet(spreadsheetId, worksheetName);
                        });
            } catch (Throwable t) {
                Throwable t2 = t instanceof FailsafeException ? t.getCause() : t;
                throw getErrorReadWorksheet(t2, worksheetName, t2.getMessage());
            }
            if (CollectionUtils.isEmpty(values)) {
                outputViews.write(documentUtility.newDocument(new JSONArray()));
                return;
            }
            List<RowData> allRows = values.get(0).getRowData();
            int dataRowIndex = 0;
            // initialize header
            int maxColumns = 0;
            List<String> header;
            // Get the max row size
            for (RowData row : allRows){
                if (!MapUtils.isEmpty(row)) {
                    maxColumns = Math.max(maxColumns, row.getValues().size());
                }
            }
            if (headerExists) {
                // first row is header so the data starts at index 1
                dataRowIndex = 1;
                RowData headerRow = allRows.get(0);
                /* HeaderRow size could be < maxColumns in case the
                 * last column header is null
                 */
                if (MapUtils.isEmpty(headerRow) || headerRow.getValues().size() < maxColumns) {
                    throw new SnapDataException(ERR_HEADER_COLUMN_EMPTY_MSG)
                            .withReason(ERR_HEADER_COLUMN_EMPTY_REASON)
                            .withResolution(ERR_HEADER_COLUMN_EMPTY_RESOLUTION);
                }
                List<CellData> headerColumns = headerRow.getValues();
                header = new ArrayList<>(headerColumns.size());
                for (CellData headerColumn : headerColumns) {
                    String headerName = headerColumn.getFormattedValue();
                    if (StringUtils.isBlank(headerName)) {
                        throw new SnapDataException(ERR_HEADER_COLUMN_EMPTY_MSG)
                                .withReason(ERR_HEADER_COLUMN_EMPTY_REASON)
                                .withResolution(ERR_HEADER_COLUMN_EMPTY_RESOLUTION);
                    }
                    if (header.contains(headerName)) {
                        throw new SnapDataException(ERR_HEADER_COLUMN_REPEATED_MSG)
                                .withReason(String.format(ERR_HEADER_COLUMN_REPEATED_REASON,
                                        headerName))
                                .withResolution(ERR_HEADER_COLUMN_REPEATED_RESOLUTION);
                    }
                    header.add(headerName);
                }
                if (CollectionUtils.isEmpty(header)) {
                    throw new SnapDataException(ERR_WORKSHEET_HEADER_NOT_FOUND)
                            .formatWith(worksheetName)
                            .withReason(REASON_EMPTY_WORKSHEET)
                            .withResolution(RESOLUTION_ADDRESS_ISSUE);
                }
            } else {
                header = new ArrayList<>(maxColumns);
                for (int i = 1; i <= maxColumns; i++) {
                    header.add(String.format(FIELD, i));
                }
            }
            // parse worksheet data
            int dataRowCount = allRows.size();
            while (dataRowIndex < dataRowCount) {
                Map<Object, Object> record = getRecord(allRows.get(dataRowIndex++).getValues(),
                        header);
                if (!isEmptyRow(record)) {
                    outputViews.write(documentUtility.newDocument(record));
                }
            }
        } catch (SnapDataException e) {
            errorViews.write(e, document);
        } catch (SuggestViewAbortException e) {
            throw e;
        } catch (Exception e) {
            errorViews.write(getErrorReadWorksheet(e, worksheetName, e.getMessage()), document);
        }
    }

    /**
     * Process the worksheet data without data type information
     * and write to output view. All cell values are returned as formatted
     * in the spreadsheet.
     * @param document
     */
    private void processDataNoGridInfo(Document document) {
        try {
            spreadsheetId = getSpreadsheetId(googleDrive, spreadsheetNameOrId);
            List<ValueRange> valueRangesList =
                    readWorksheetNoGridInfo(spreadsheetId, worksheetName);
            if (CollectionUtils.isEmpty(valueRangesList)) {
                outputViews.write(documentUtility.newDocument(new JSONArray()));
                return;
            }
            List<String> header = null;
            int maxColumns = 0;
            // Iterate through rows in all value-ranges to find the row with max columns
            // to set/validate the header
            for (ValueRange valueRange : valueRangesList) {
                List<List<Object>> valuesInRange = valueRange.getValues();
                if (CollectionUtils.isNotEmpty(valuesInRange)) {
                    for (List<Object> values : valuesInRange) {
                        if (CollectionUtils.isNotEmpty(values)) {
                            maxColumns = Math.max(maxColumns, values.size());
                        }
                    }
                }
            }

            if (headerExists) {
                // first row is header
                List<Object> headerRow = valueRangesList.get(0).getValues().get(0);
                /* HeaderRow size could be < maxColumns in case the
                 * last column header is null. Throw error in such case.
                 */
                if (CollectionUtils.isEmpty(headerRow) || headerRow.size() < maxColumns) {
                    throw new SnapDataException(ERR_HEADER_COLUMN_EMPTY_MSG)
                            .withReason(ERR_HEADER_COLUMN_EMPTY_REASON)
                            .withResolution(ERR_HEADER_COLUMN_EMPTY_RESOLUTION);
                }
                header = new ArrayList<>(headerRow.size());
                for (Object headerColumn : headerRow) {
                    String headerName = headerColumn.toString();
                    if (StringUtils.isBlank(headerName)) {
                        throw new SnapDataException(ERR_HEADER_COLUMN_EMPTY_MSG)
                                .withReason(ERR_HEADER_COLUMN_EMPTY_REASON)
                                .withResolution(ERR_HEADER_COLUMN_EMPTY_RESOLUTION);
                    }
                    if (header.contains(headerName)) {
                        throw new SnapDataException(ERR_HEADER_COLUMN_REPEATED_MSG)
                                .withReason(String.format(ERR_HEADER_COLUMN_REPEATED_REASON,
                                        headerName))
                                .withResolution(ERR_HEADER_COLUMN_REPEATED_RESOLUTION);
                    }
                    header.add(headerName);
                }
                if (CollectionUtils.isEmpty(header)) {
                    throw new SnapDataException(ERR_WORKSHEET_HEADER_NOT_FOUND)
                            .formatWith(worksheetName)
                            .withReason(REASON_EMPTY_WORKSHEET)
                            .withResolution(RESOLUTION_ADDRESS_ISSUE);
                }
            } else {
                header = new ArrayList<>(maxColumns);
                for (int i = 1; i <= maxColumns; i++) {
                    header.add(String.format(FIELD, i));
                }
            }

            // parse worksheet data
            for (int listItr = 0; listItr < valueRangesList.size(); listItr++) {
                List<List<Object>> valuesInRange = valueRangesList.get(listItr).getValues();
                // valuesInRange is null if an entire batch is empty. Skip all empty rows
                if (valuesInRange == null) {
                    continue;
                }
                ListIterator<List<Object>> rowIterator = valuesInRange.listIterator();
                if (headerExists && listItr == 0) {
                    rowIterator.next();
                }
                while (rowIterator.hasNext()) {
                    List<Object> row = rowIterator.next();
                    Map<Object, Object> record = new LinkedHashMap<>();
                    Iterator<Object> cellIterator = row.iterator();
                    for (Object key : header) {
                        Object value = cellIterator.hasNext() ?
                                cellIterator.next() : StringUtils.EMPTY;
                        if (!(value instanceof String)) {
                            value = String.valueOf(value);
                        }
                        record.put(key, value);
                    }
                    if (!isEmptyRow(record)) {
                        outputViews.write(documentUtility.newDocument(record));
                    }
                }
            }
        } catch (SnapDataException e) {
            errorViews.write(e, document);
        } catch (SuggestViewAbortException e) {
            throw e;
        } catch (Exception e) {
            errorViews.write(getErrorReadWorksheet(e, worksheetName, e.getMessage()), document);
        }
    }

    @Override
    public void defineInputSchemaAdditional(SchemaProvider schemaProvider, List<Schema> schemas) {
        schemas.add(schemaProvider.createSchema(SnapType.STRING,
                READER_IN_VIEW_FIELD_SPREADSHEET));
        schemas.add(schemaProvider.createSchema(SnapType.STRING, READER_IN_VIEW_FIELD_WORKSHEET));
    }

    @Override
    public boolean isReadHeaderPropertyRequired() {
        return true;
    }

    @Override
    public String getDescription() {
        return READ;
    }

    /**
     * Read worksheet data in batches specified by ranges, with no additional
     * cell metadata. All data returned are as formatted in the spreadsheet.
     * @param spreadsheetId
     * @param worksheetName
     * @return list of values in ranges of size = READ_BATCH_SIZE
     */
    protected List<ValueRange> readWorksheetNoGridInfo(String spreadsheetId, String worksheetName) {
        GridProperties gp = getSheetGridProperties(spreadsheetId, worksheetName);
        if (gp == null) {
            throw new SnapDataException(ERR_READ_WORKSHEET)
                    .formatWith(worksheetName, spreadsheetNameOrId)
                    .withReason(ERROR_FETCHING_WORKSHEET_ROW_COL_INFO)
                    .withResolution(RESOLUTION_VERIFY_WORKSHEET_EXISTS);
        }
        int rowCount = gp.getRowCount();
        List<String> ranges = Lists.newArrayList();
        int startRow = 1;
        // Set up ranges to be read
        while (startRow <= rowCount) {
            String range = String.format(WORKSHEET_BATCH_GET_RANGE_FORMAT, worksheetName,
                    FIRST_COLUMN, startRow, LAST_COLUMN, startRow + READ_BATCH_SIZE - 1);
            ranges.add(range);
            startRow = startRow + READ_BATCH_SIZE;
        }
        try {
            @SuppressWarnings("unchecked")
            RetryPolicy retryPolicy = new RetryPolicy()
                    .withMaxRetries(numOfRetries)
                    .withDelay(retryInterval, TimeUnit.SECONDS)
                    .abortOn(SuggestViewAbortException.class, SnapDataException.class);
            return Failsafe.with(retryPolicy)
                    .onFailedAttempt(failure -> LOG.warn("Failed to read worksheet: {} in " +
                            "spreadsheet: {}, {}", worksheetName, spreadsheetNameOrId,
                            failure.getMessage()))
                    .get(context -> {
                       logRetryAttempt(context, LOG);
                       return readWorksheetNoGridInfo(spreadsheetId, ranges);
                    });
        } catch (Throwable t) {
            Throwable t2 = t instanceof FailsafeException ? t.getCause() : t;
            throw getErrorReadWorksheet(t2, worksheetName, t2.getMessage());
        }
    }

    protected List<ValueRange> readWorksheetNoGridInfo(String spreadsheetId, List<String> ranges)
            throws IOException {
        try {
            Sheets.Spreadsheets.Values.BatchGet batchGetRequest = sheets
                    .spreadsheets()
                    .values()
                    .batchGet(spreadsheetId);
            batchGetRequest.setRanges(ranges);
            batchGetRequest.setValueRenderOption(VALUE_RENDER_OPTION);
            return batchGetRequest.execute().getValueRanges();
        } catch (GoogleJsonResponseException e) {
            String errMessage = e.getMessage();
            if (StringUtils.startsWithIgnoreCase(errMessage, TOO_MANY_REQUESTS)) {
                // if number of requests exceeded the hourly limit, wait longer and retry
                sleepNoInterrupt(SLEEP_SECONDS_ERR_429, TimeUnit.SECONDS, LOG);
            } else if (StringUtils.containsIgnoreCase(errMessage, INVALID_RANGE)) {
                // The error "Invalid range" occurs if the worksheet is a chart or an image.
                String sheetType = getSheetType(spreadsheetId, worksheetName);
                if (sheetType != null && !GRID.equalsIgnoreCase(sheetType)) {
                    // Worksheet Reader can read 'GRID' type only
                    throw getErrorReadWorksheet(e, worksheetName, String.format(
                            REASON_UPSUPPORTED_WORKSHEET_TYPE, sheetType));
                }
            }
            throw e;
        }
    }

    /**
     * Get grid properties of the worksheet to get the row, column dimensions
     * @param spreadsheetId
     * @param worksheetName
     * @return GridProperties
     */
    private GridProperties getSheetGridProperties(String spreadsheetId, String worksheetName) {
        try {
            SheetProperties properties;
            for (Sheet sheet : getWorksheets(sheets, spreadsheetId)) {
                properties = sheet.getProperties();
                if (properties.getTitle().equals(worksheetName)) {
                    return properties.getGridProperties();
                }
            }
        } catch (IOException ioe) {
            throw new ExecutionException(ioe, ERR_READ_WORKSHEET)
                    .formatWith(worksheetName, spreadsheetNameOrId)
                    .withReason(ioe.getMessage())
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
        return null;
    }
}
