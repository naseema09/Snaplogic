/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.apache.v2.ApacheHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.drive.Drive;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.inject.Inject;
import com.snaplogic.account.api.AccountType;
import com.snaplogic.account.api.ValidatableAccount;
import com.snaplogic.account.api.capabilities.AccountCategory;
import com.snaplogic.api.ExecutionException;
import com.snaplogic.common.properties.SnapProperty;
import com.snaplogic.common.properties.builders.PropertyBuilder;
import com.snaplogic.common.services.SnapControl;
import com.snaplogic.snap.api.PropertyValues;
import com.snaplogic.snap.api.SnapDataException;
import com.snaplogic.snap.api.account.oauth2.OAuth2Account;
import com.snaplogic.snap.api.capabilities.General;
import com.snaplogic.snap.api.capabilities.Version;
import com.snaplogic.util.ProxyHttpClient;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Set;

import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;

import static com.snaplogic.snaps.google.spreadsheet.Constants.AUTH_ENDPOINT_URL;
import static com.snaplogic.snaps.google.spreadsheet.Constants.AUTO;
import static com.snaplogic.snaps.google.spreadsheet.Constants.DEFAULT_OAUTH2_CLIENT_ID;
import static com.snaplogic.snaps.google.spreadsheet.Constants.DEFAULT_OAUTH2_CLIENT_SECRET;
import static com.snaplogic.snaps.google.spreadsheet.Constants.DRIVE_SERVICE_NAME;
import static com.snaplogic.snaps.google.spreadsheet.Constants.FORCE;
import static com.snaplogic.snaps.google.spreadsheet.Constants.SPREADSHEET_AND_DRIVE_SCOPE;
import static com.snaplogic.snaps.google.spreadsheet.Constants.TOKEN_ENDPOINT_URL;
import static com.snaplogic.snaps.google.spreadsheet.Messages.ACCESS_TYPE_DESC;
import static com.snaplogic.snaps.google.spreadsheet.Messages.ACCESS_TYPE_LABEL;
import static com.snaplogic.snaps.google.spreadsheet.Messages.APPROVAL_PROMPT_DESC;
import static com.snaplogic.snaps.google.spreadsheet.Messages.APPROVAL_PROMPT_LABEL;
import static com.snaplogic.snaps.google.spreadsheet.Messages.ERR_RELOAD_ACCOUNT;
import static com.snaplogic.snaps.google.spreadsheet.Messages.OAUTH_ACCOUNT_DOC_LINK;
import static com.snaplogic.snaps.google.spreadsheet.Messages.OAUTH_ACCOUNT_TITLE;
import static com.snaplogic.snaps.google.spreadsheet.Messages.REASON_UNKNOWN;
import static com.snaplogic.snaps.google.spreadsheet.Messages.RESOLUTION_ADDRESS_ISSUE;
import static com.snaplogic.snaps.google.spreadsheet.SpreadsheetsBase.DEFAULT_RETRIES;
import static com.snaplogic.snaps.google.spreadsheet.SpreadsheetsBase.DEFAULT_RETRY_INTERVAL;
import static com.snaplogic.snaps.google.spreadsheet.SpreadsheetsBase.FORMAT_RETRIED;
import static com.snaplogic.snaps.google.spreadsheet.SpreadsheetsBase.getRetryPolicy;
import static com.snaplogic.snaps.google.spreadsheet.SpreadsheetsBase.logRetryAttempt;

/**
 * Represents connection to google spreadsheet server. Encapsulate credentials (client-id,
 * client-secret), scope, etc.
 *
 * @author smudassir
 * @author rhowlett
 */
@General(title = OAUTH_ACCOUNT_TITLE, docLink = OAUTH_ACCOUNT_DOC_LINK)
@Version(snap = 1)
@AccountCategory(type = AccountType.OAUTH2)
public class GoogleSpreadsheetOAuth2Account extends OAuth2Account<ConnectionResult>
        implements ValidatableAccount<ConnectionResult>, SheetsApiAccount {
    private static final Logger LOG = LoggerFactory.getLogger(GoogleSpreadsheetOAuth2Account.class);
    private static final Set<String> APPROVAL_PROMPT_TYPES = ImmutableSet.of(AUTO, FORCE);
    protected static final String ACCESS_TYPE = "access_type";
    protected static final String APPROVAL_PROMPT = "approval_prompt";
    protected static final String AUTO_REFRESH_TOKEN = "autoRefreshToken";
    protected static final String OFFLINE = "offline";
    protected static final String REFRESH_TOKEN = "refresh_token";
    private PropertyValues propertyValues;
    protected boolean isRetry;
    private int sheetsApiVersion = 3;
    private int numOfRetries = DEFAULT_RETRIES;
    private int retryInterval = DEFAULT_RETRY_INTERVAL;
    private  String retriedTimes = String.format(FORMAT_RETRIED, numOfRetries);
    @Inject
    private SnapControl snapControl;

    // package-private static variables
    static final HttpTransport HTTP_TRANSPORT;
    static final JacksonFactory JACKSON_FACTORY;
    static {
        HTTP_TRANSPORT = new ApacheHttpTransport(new ProxyHttpClient());
        JACKSON_FACTORY = JacksonFactory.getDefaultInstance();
    }

    private Boolean autoRefreshToken;
    private String refreshToken;

    /**
     * Ensures that the OAuth 2.0 authorization request URL, sent by the UI using the saved account
     * properties, will include {@code "access_type=offline"} so that a {@code refresh_token} is
     * received in Google's token response.
     *
     * @param propertyBuilder as the builder
     * @see <a href="https://developers.google.com/identity/protocols/OAuth2WebServer">Redirecting
     * to Google's OAuth 2.0 server</a>
     */
    @Override
    public List<SnapProperty> defineAuthEndpointProperties(final PropertyBuilder propertyBuilder) {
        return new ImmutableList.Builder<SnapProperty>()
                /*
                see "Offline Access"
                https://developers.google.com/identity/protocols/OAuth2WebServer?hl=en

                and "When should I use force",
                http://www.riskcompletefailure.com/2013/12/are-you-using-approvalpromptforce.html
                 */
                .add(propertyBuilder.describe(ACCESS_TYPE, ACCESS_TYPE_LABEL, ACCESS_TYPE_DESC)
                        .makeReadOnly()
                        .defaultValue(OFFLINE)
                        .build())
                .add(propertyBuilder.describe(APPROVAL_PROMPT, APPROVAL_PROMPT_LABEL,
                        APPROVAL_PROMPT_DESC)
                        .withAllowedValues(APPROVAL_PROMPT_TYPES)
                        .defaultValue(AUTO)
                        .build())
                .build();
    }

    @Override
    protected void configureAdditional(final PropertyValues propertyValues) {
        this.propertyValues = propertyValues;
        this.autoRefreshToken = propertyValues.get(AUTO_REFRESH_TOKEN);
        this.refreshToken = (Boolean.TRUE.equals(autoRefreshToken) ? (String) propertyValues.get
                (REFRESH_TOKEN) : null);
    }

    @Override
    public ConnectionResult connect() {
        try {
            /*
            The Platform has a scheduled job ("refresh_every_account"; runs every 20 minutes)
            to refresh access tokens for OAuth 2.0 accounts that are due to expire within the
            next 30 minutes.

            Even if that fails to run, accounts with "autoRefreshToken== true", GoogleCredential
            will use the refresh token (if set) to automatically request a new access token when
            the existing access token has expired.
             */
            GoogleCredential credential = createGoogleCrendential(HTTP_TRANSPORT, JACKSON_FACTORY,
                    getClientId(), getClientSecret(), getAccessToken(), getRefreshToken());
            Drive googleDrive = createGoogleDriveApiClient(HTTP_TRANSPORT, JACKSON_FACTORY,
                    credential, DRIVE_SERVICE_NAME);
            return new ConnectionResult(googleDrive)
                    .withCredential(credential);
        } catch (Throwable e) {
            // try to refresh access token
            try {
                Failsafe.with(getRetryPolicy(numOfRetries, retryInterval))
                        .onFailedAttempt(failure -> LOG.warn("Failed to refresh access token, {}",
                                failure.getMessage()))
                        .run(context -> {
                            logRetryAttempt(context, LOG);
                            reloadAccount();
                        });
                return connect();
            } catch (Throwable t) {
                Throwable t2 = t instanceof FailsafeException ? t.getCause() : t;
                throw t2 instanceof SnapDataException ? (SnapDataException) t2 :
                        new SnapDataException(t2, ERR_RELOAD_ACCOUNT)
                        .withResolution(RESOLUTION_ADDRESS_ISSUE);
            }
        }
    }

    protected GoogleCredential createGoogleCrendential(
            HttpTransport httpTransport, JacksonFactory jacksonFactory,
            String clientId, String clientSecret,
            String accessToken, String refreshToken) {
        GoogleCredential credential = new GoogleCredential.Builder()
                .setTransport(httpTransport)
                .setJsonFactory(jacksonFactory)
                .setClientSecrets(clientId, clientSecret)
                .build();
        credential.setAccessToken(accessToken);

        // ensures requests that fail due to expired access tokens will attempt refreshing the
        // access token
        credential.setRefreshToken(refreshToken);

        return credential;
    }

    protected Drive createGoogleDriveApiClient(HttpTransport httpTransport,
            JacksonFactory jacksonFactory, GoogleCredential credential, String name) {
        return new Drive.Builder(httpTransport, jacksonFactory, credential).setApplicationName
                (name).build();
    }

    @Override
    public void disconnect() throws ExecutionException {
        // NO OP
    }

    @Override
    public String setDefaultScope() {
        return SPREADSHEET_AND_DRIVE_SCOPE;
    }

    @Override
    protected String setDefaultClientId() {
        return DEFAULT_OAUTH2_CLIENT_ID;
    }

    @Override
    protected String setDefaultClientSecret() {
        return DEFAULT_OAUTH2_CLIENT_SECRET;
    }

    @Override
    public String setAuthorizationEndpoint() {
        return AUTH_ENDPOINT_URL;
    }

    @Override
    public String setTokenEndpoint() {
        return TOKEN_ENDPOINT_URL;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * Gets the access token expiration time. An example on how to convert to a datetime format is
     *     SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
     *     long accessTokenExpiration = account.getAccessTokenExpiration() * 1000;
     *     LOG.info("Access token will expire at {}", formatter.format(accessTokenExpiration));
     *
     * @return long integer in seconds from 01/01/1970
     */
    public Long getAccessTokenExpiration() {
        return Long.parseLong(propertyValues.get(ACCESS_TOKEN_EXPIRATION));
    }

    /**
     * Refreshes access token.
     *
     * @return true if successfully refreshed,
     *         false if failed to refresh, should continue to use the same access token
     */
    public boolean reloadAccount() {
        if (!isRetry) {
            boolean refreshed = snapControl.reloadSnapAccount();
            if (refreshed) {
                return true;
            }
        }
        throw new SnapDataException(ERR_RELOAD_ACCOUNT)
                .withReason(REASON_UNKNOWN)
                .withResolution(RESOLUTION_ADDRESS_ISSUE);
    }

    @Override
    public int getSheetsAPIversion() {
        return sheetsApiVersion;
    }

    @Override
    public void setSheetsAPIversion(int version) {
        this.sheetsApiVersion = version;
    }

    @Override
    public void setRetry(int numOfRetries, int retryInterval) {
        this.numOfRetries = numOfRetries;
        this.retryInterval = retryInterval;
        retriedTimes = String.format(FORMAT_RETRIED, numOfRetries);
    }
}