/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

/**
 * Messages is the container for all the externalized messages used in this snap pack.
 *
 * @author smudassir
 */
@SuppressWarnings("nls")
public class Messages {
    // OAuth Account messages
    static final String OAUTH_ACCOUNT_TITLE = "Spreadsheet OAuth2 Account";
    static final String OAUTH_ACCOUNT_DOC_LINK =
            "https://docs-snaplogic.atlassian.net/wiki/spaces/SD/pages/2466218077/Spreadsheet+OAuth2+Account";
    static final String ERR_SERVICES_INSTANTIATION_MSG = "Error instantiating Google spreadsheet" +
            " or docs service";
    static final String ERR_SERVICES_INSTANTIATION_RESOLUTION = "Check if the credentials and the" +
            "  token are valid";
    // OAuth 2.0: Offline access for refresh tokens
    static final String ACCESS_TYPE_LABEL = "Access Type";
    static final String ACCESS_TYPE_DESC = "Indicates whether the Snap needs to access a Google " +
            "API when the user is not present at the browser. The property value \"offline\" " +
            "results in obtaining a refresh token the first time authorization has been " +
            "received.";
    // OAuth 2.0: Approval prompts for refresh tokens
    static final String APPROVAL_PROMPT_LABEL = "Approval Prompt";
    static final String APPROVAL_PROMPT_DESC = "Indicates whether the user should be re-prompted " +
            "for offline consent to receive a new refresh token. The property value \"auto\" " +
            "will only display the consent prompt on the first time through the OAuth 2.0 " +
            "authorization sequence. To manually acquire a new refresh token, set this property " +
            "value to \"force\" and re-authorize.";
    // Dynamic Auth Account messages
    static final String DYNAMIC_AUTH_ACCOUNT_TITLE = "Spreadsheet Dynamic OAuth2 Account";
    static final String DYNAMIC_AUTH_ACCOUNT_DOC_LINK =
            "https://docs-snaplogic.atlassian.net/wiki/spaces/SD/pages/2466218068/Spreadsheet+" +
                    "Dynamic+OAuth2+Account";
    // Base snap messages
    static final String LABEL_INCLUDE_SHARED_DRIVE = "Include Shared Drives";
    static final String LABEL_DISPLAY_SPREADSHEET_ID = "Display Spreadsheet ID in Suggestions";
    static final String LABEL_SPREADSHEET = "Spreadsheet";
    static final String DESC_SPREADSHEET = "Name and/or ID of the Spreadsheet to %s";
    static final String LABEL_WORKSHEET = "Worksheet";
    static final String DESC_WORKSHEET = "Worksheet to be %s";
    static final String LABEL_WRITE_MODE = "Write mode";
    static final String DESC_WRITE_MODE = "The type of write operation to be performed for the " +
            "specified worksheet";
    static final String LABEL_CELL_REFERENCE = "Starting cell reference";
    static final String DESC_CELL_REFERENCE = "The reference to a cell at which data will " +
            "start being written, in A1 notation. The specified cell will be the top left corner " +
            "of the table of data written to the worksheet (potentially overwriting existing " +
            "worksheet data). If left blank, data will be appended following the last existing " +
            "worksheet row with content.";
    static final String READ = "read";
    static final String WRITTEN = "written";
    static final String LABEL_HEADER_EXISTS = "Header exists";
    static final String LABEL_OVERWRITE_WORKSHEET = "Overwrite worksheet if it exists";
    static final String LABEL_WRITE_HEADER_ROW = "Write header row";
    static final String DESC_HEADER_EXISTS = "Select this checkbox to check if the worksheet's first row is a header or not.";
    static final String DESC_INCLUDE_SHARED_DRIVE = "Select this checkbox to read spreadsheets from the" +
            " Shared Drive";
    static final String DESC_DISPLAY_SPREADSHEET_ID = "Select this checkbox to display Spreadsheet ID " +
            "along with the Spreadsheet name in the Suggestions";
    static final String DESC_OVERWRITE_WORKSHEET = "Select this checkbox to overwrite the worksheet if it already exists " ;
    static final String DESC_WRITE_HEADER_ROW = "Select this checkbox to include a row containing " +
            "column names as the first row written to the worksheet.";
    static final String ERR_NO_SHEETS_FOUND_MSG = "No %s found";
    static final String ERR_UNEXPECTED_SEARCH_RESULT = "Unexpected spreadsheet search result " +
            "for %s";
    static final String REASON_EMPTY_ID = "Found an empty ID";
    static final String REASON_TOO_MANY = "Found multiple spreadsheets for the given name";
    static final String ERR_SPREADSHEET_NOT_FOUND = "Spreadsheet not found: %s";
    static final String REASON_SPREADSHEET_NOT_FOUND = "The spreadsheet may not exist or cannot " +
            "be accessed";
    // Browser snap messages
    static final String BROWSER_TITLE = "Spreadsheets Browser";
    static final String BROWSER_DESC = "Browses the Google drive folder for spreadsheets matching" +
            " the given name pattern and displays the spreadsheet's details.";
    static final String LABEL_NAME_FILTER = "Name Filter";
    static final String DESC_NAME_FILTER = "GLOB pattern to select specific spreadsheets.";
    static final String LABEL_FETCH_MODE = "Fetch Mode";
    static final String DESC_FETCH_MODE = "Indicates whether to fetch both spreadsheets " +
            "and worksheets or not. 'Spreadsheets and Worksheets' " +
            "option fetches each spreadsheet with all its worksheets. " +
            "'Spreadsheets' option fetches only Spreadsheets.";
    static final String SPREADSHEET_NAME = "Spreadsheet Name";
    static final String SPREADSHEET_ID = "Spreadsheet ID";
    static final String SPREADSHEETS = "spreadsheets";
    static final String WORKSHEETS = "worksheets";
    static final String WORKSHEET_ID = "worksheet ID";
    static final String WORKSHEET_NAME = "worksheet name";
    static final String BROWSER_IN_VIEW_FIELD_FILTER = "filter";
    static final String ERR_GET_SPREADSHEETS = "Failed to get the list of spreadsheets";
    static final String ERR_GET_WORKSHEETS = "Failed to get the list of worksheets in the " +
            "spreadsheet: %s";
    static final String ERR_BROWSE_SPREADSHEET = "Failed to browse spreadsheets";
    // Reader snap messages
    static final String READER_TITLE = "Worksheet Reader";
    static final String READER_DESC = "Reads a worksheet in the given spreadsheet";
    static final String READER_IN_VIEW_FIELD_SPREADSHEET = "spreadsheet";
    static final String READER_IN_VIEW_FIELD_WORKSHEET = "worksheet";
    static final String FIELD = "Field%s";
    static final String REASON_UPSUPPORTED_WORKSHEET_TYPE = "Unsupported worksheet type: %s";
    static final String PRESERVE_DATA_TYPES_LBL = "Preserve data types";
    static final String PRESERVE_DATA_TYPES_DESC = "Select this checkbox to display the columns" +
            "actual data types (boolean, number, etc) instead of as strings";
    static final String ERROR_FETCHING_WORKSHEET_ROW_COL_INFO = "Error getting row-column " +
            "properties from worksheet";
    static final String RESOLUTION_VERIFY_WORKSHEET_EXISTS = "Verify if worksheet exists and " +
            "if the name is correct";
    // Writer snap messages
    static final String WRITER_TITLE = "Worksheet Writer";
    static final String WRITER_DESC = "Writes to the given worksheet in a spreadsheet";
    static final String ERR_INVALID_INPUT_MSG = "Input data error";
    static final String ERR_INVALID_INPUT_REASON = "Data is not a key-value pair";
    static final String ERR_INVALID_INPUT_RESOLUTION = "Check the input data and" +
            " try again";
    static final String ERR_INVALID_WRITE_MODE = "Invalid write mode";
    static final String ERR_INVALID_WRITE_MODE_REASON = "Current write mode is not recognized";
    static final String ERR_INVALID_WRITE_MODE_RESOLUTION = "Please contact SnapLogic technical support";
    static final String ERR_WORKSHEET_EXISTS_REASON = "Worksheet with given name already exists";
    static final String ERR_WORKSHEET_NOT_FOUND_REASON = "Worksheet was not found";
    static final String ERR_CELL_REFERENCE_INVALID = "Cell reference is invalid";
    static final String ERR_CELL_REFERENCE_INVALID_REASON = "Cell reference does not follow A1 notation";
    static final String ERR_WRITE_RANGE_INVALID = "Invalid range to write %d columns starting at cell %s";
    static final String ERR_WRITE_RANGE_INVALID_MAX_COLUMN_REASON = "Range end column exceeds max column ZZZ";
    static final String ERR_WRITE_RANGE_INVALID_MAX_COLUMN_RESOLUTION = "Reduce the number of " +
            "columns in the written data or adjust the starting cell reference to fit all columns";
    static final String VALID_RECORD_COUNT = "Number of valid records written";
    static final String INVALID_RECORD_COUNT = "Number of invalid records encountered";
    /**
     * Google sheets Batch Write/Insert API reference:
     * https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets.values/update
     * https://developers.google.com/sheets/api/reference/rest/v4/ValueInputOption
     * Example:
     * In Google spreadsheet, let's say you type in values in 2 rows as :
     *                  |1234  |  |ABCD  |  |19/12/11  |
     * RAW -            |1234  |  |ABCD  |  |19/12/11  | - treats as plain-text format
     * USER_ENTERED -   |  1234|  |ABCD  |  |  19/12/11| - automatically parses numbers,
     *                                                     strings that look like dates,
     *                                                     as seen from the alignment in the column
     */
    static final String BATCH_VALUE_INPUT_LABEL = "Parse Data";
    static final String BATCH_VALUE_INPUT_DESC = "Choose if the input data should be as-is or " +
            "needs to be parsed by Google Sheets when using Batch Write." +
            "RAW - the values you have entered are not parsed and are stored as-is " +
            "(in plan-text format). USER_ENTERED - The values are parsed as if the " +
            "user entered them into the UI. Numbers will stay as numbers, but strings " +
            "may be converted to numbers, dates, etc. following the same rules that are " +
            "applied when entering text into a cell via the Google Sheets UI. " +
            "Refer to ValueInputOption in Google Sheets API";
    static final String ERR_WRITE_WORKSHEET = "Failed to write data to the worksheet %s";
    static final String ERR_INIT_GOOGLE_ACCOUNT = "Failed to connect to Google account";
    static final String REASON_GOOGLE_ACCOUNT = "Google account is required";
    static final String ERR_INIT_WORKSHEET = "Failed to initialize worksheet %s for batch write";
    static final String ERR_SHEET_NAMES = "Spreadsheet or Worksheet value is blank";
    static final String REASON_SHEET_NAMES = "Spreadsheet and worksheet names are required";
    static final String ERR_CREATE_SPREADSHEET = "Failed to create a new spreadsheet for %s";
    static final String ERR_CREATE_WORKSHEET = "Failed to create a new worksheet for %s";
    static final String RESOLUTION_ADDRESS_ISSUE = "Address the reported issue.";
    static final String ERR_BATCH_WRITE = "Failed to write a batch of %d records for worksheet %s";
    static final String ERR_INVALID_KEY = "Invalid key name: null";
    static final String REASON_NULL_KEY = "Null key is not allowed";
    static final String ERR_READ_WORKSHEET = "Failed to read the worksheet '%s' in the " +
            "spreadsheet '%s'";
    static final String ERR_WORKSHEET_HEADER_NOT_FOUND = "Worksheet header not found: %s";
    static final String REASON_EMPTY_WORKSHEET = "Empty worksheet header";
    static final String ERR_DELETE_WORKSHEET = "Failed to delete worksheet: %s, in spreadsheet:" +
            " %s";
    static final String ERR_DELETE_WORKSHEET_NO_ERROR = "Failed to delete worksheet '%s' " +
            "without producing any error";
    static final String REASON_EMPTY_RESPONSE = "Empty response";
    static final String ERR_HEADER_COLUMN_EMPTY_MSG = "Invalid header column";
    static final String ERR_HEADER_COLUMN_EMPTY_REASON = "Blank or empty header column(s)";
    static final String ERR_HEADER_COLUMN_EMPTY_RESOLUTION = "Ensure all header columns are " +
            "non-empty";
    static final String ERR_HEADER_COLUMN_REPEATED_MSG = "Invalid header in the worksheet";
    static final String ERR_HEADER_COLUMN_REPEATED_REASON = "Column header with name '%s' " +
            "occurs more than once";
    static final String ERR_HEADER_COLUMN_REPEATED_RESOLUTION = "Ensure all header columns " +
            "occur exactly once";
    static final String READ_TIMEOUT_LABEL = "Read Timeout in Seconds";
    static final String READ_TIMEOUT_DESC = "Number of seconds to wait before terminating the" +
            "request due to a failure to read from the target service.";
    static final String CONN_TIMEOUT_LABEL = "Connection Timeout in Seconds";
    static final String CONN_TIMEOUT_DESC = "Number of seconds to wait before aborting the " +
            "request due to a failure to establish a connection with the target service.";
    static final String CONNECTION_PROPERTIES_LABEL = "Connection Properties";
    static final String CONNECTION_PROPERTIES_DESC = "Set the timeout parameters to communicate " +
            "with Google sheets.";
    static final String RETRIES_DESC = "Number of retries to perform when the Snap fails.";
    static final String ERR_RELOAD_ACCOUNT = "Failed to reload account";
    static final String REASON_UNKNOWN = "Unknown reason";
    static final String RESOLUTION_DUPLICATE_SPREADSHEET = "Provide Spreadsheet ID instead" +
            " of Spreadsheet name.";
}
