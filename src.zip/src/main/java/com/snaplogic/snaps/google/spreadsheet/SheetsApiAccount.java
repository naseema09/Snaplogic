/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2018, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */
package com.snaplogic.snaps.google.spreadsheet;

/**
 * Interface for getter/setter of Google Sheets API version
 *
 * @since Aug, 2018
 */
public interface SheetsApiAccount {

    int getSheetsAPIversion();

    void setSheetsAPIversion(int version);

    void setRetry(int numOfRetries, int retryInterval);
}
