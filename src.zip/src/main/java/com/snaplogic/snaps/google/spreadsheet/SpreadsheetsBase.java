/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.CellData;
import com.google.api.services.sheets.v4.model.CellFormat;
import com.google.api.services.sheets.v4.model.ExtendedValue;
import com.google.api.services.sheets.v4.model.GridData;
import com.google.api.services.sheets.v4.model.NumberFormat;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.Spreadsheet;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.ImmutableSet;
import com.google.inject.AbstractModule;
import com.google.inject.Inject;
import com.google.inject.Key;
import com.google.inject.Module;
import com.google.inject.TypeLiteral;
import com.snaplogic.account.api.Account;
import com.snaplogic.account.api.capabilities.Accounts;
import com.snaplogic.account.api.capabilities.MultiAccountBinding;
import com.snaplogic.api.ConfigurationException;
import com.snaplogic.api.ExecutionException;
import com.snaplogic.api.InputSchemaProvider;
import com.snaplogic.common.SnapType;
import com.snaplogic.common.properties.SnapProperty;
import com.snaplogic.common.properties.builders.PropertyBuilder;
import com.snaplogic.snap.api.Document;
import com.snaplogic.snap.api.ExpressionProperty;
import com.snaplogic.snap.api.PropertyValues;
import com.snaplogic.snap.api.SimpleSnap;
import com.snaplogic.snap.api.SnapDataException;
import com.snaplogic.snap.api.SuggestViewAbortException;
import com.snaplogic.snap.schema.api.Schema;
import com.snaplogic.snap.schema.api.SchemaBuilder;
import com.snaplogic.snap.schema.api.SchemaProvider;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.DateUtil;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;

import net.jodah.failsafe.ExecutionContext;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;

import static com.snaplogic.snap.Utils.MIN_RETRIES;
import static com.snaplogic.snap.Utils.MIN_RETRY_INTERVAL;
import static com.snaplogic.snap.Utils.RETRIES_PROP;
import static com.snaplogic.snap.Utils.RETRY_INTERVAL_PROP;
import static com.snaplogic.snap.Utils.defineRetryProperties;
import static com.snaplogic.snap.Utils.evalIntProperty;
import static com.snaplogic.snap.Utils.sleepNoInterrupt;
import static com.snaplogic.snaps.google.spreadsheet.Constants.TYPE_DATE;
import static com.snaplogic.snaps.google.spreadsheet.Constants.VERSION_4;
import static com.snaplogic.snaps.google.spreadsheet.Messages.*;

/**
 * Base class containing common features for all the snaps.
 *
 * @author smudassir
 */
@Accounts(provides = {GoogleSpreadsheetDynamicOAuth2Account.class,
        GoogleSpreadsheetOAuth2Account.class})
public abstract class SpreadsheetsBase extends SimpleSnap
        implements MultiAccountBinding<Account<ConnectionResult>>, InputSchemaProvider {
    private static final Logger LOG = LoggerFactory.getLogger(SpreadsheetsBase.class);
    static final String FILES_ID_NAME = "files(id, name)";
    private static final String DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";
    static final String ACTIVE_SHEETS = "mimeType='application/vnd.google-apps.spreadsheet'" +
            " AND trashed = false";
    private static final String FORMAT_NAME = "name='%s' AND " + ACTIVE_SHEETS;
    private static final String IS_UNDEFINED = "is undefined.  Perhaps you meant:";
    private static final String CONNECTION_PROPERTIES_PROP = "connectionProperties";
    private static final String READ_TIMEOUT_PROP = "timeout";
    private static final String CONN_TIMEOUT_PROP = "connTimeout";
    private static final int DEFAULT_READ_TIMEOUT_IN_SEC = 180;
    private static final int DEFAULT_CONN_TIMEOUT_IN_SEC = 20;
    protected static final String FORMAT_RETRIED = "retried %d times";
    protected static final String KEY_SPREADSHEET = "KeySpreadsheet";
    protected static final String KEY_INCLUDE_SHARED_DRIVES = "KeyIncludeSharedDrive";
    protected static final String KEY_DISPLAY_SPREADSHEET_ID = "KeyDisplaySpreadsheetId";
    protected static final String KEY_WORKSHEET = "KeyWorksheet";
    protected static final String KEY_HEADER_EXISTS = "KeyHeaderExists";
    protected static final String KEY_OVERWRITE_WORKSHEET = "KeyOverwriteWorksheet";
    protected static final String KEY_WRITE_HEADER_ROW = "KeyWriteHeaderRow";
    protected static final String KEY_WRITE_MODE = "KeyWriteMode";
    protected static final String KEY_CELL_REFERENCE = "KeyCellReference";
    protected static final String TOO_MANY_REQUESTS = "429 Too Many Requests";
    protected static final int SLEEP_SECONDS_ERR_429 = 10;
    protected static final int DEFAULT_RETRIES = 3;
    protected static final int DEFAULT_RETRY_INTERVAL = 1;
    protected static final String INVALID_RANGE = "Invalid range:";
    private static final String DEFAULT_RANGE = "%s!A:ZZZ";
    private static final String OBJECT = "OBJECT";
    private static final String CHART = "CHART";
    protected static final String GRID = "GRID";
    protected static final String WRITE_MODE_OPTION_CREATE = "Create new worksheet";
    protected static final String WRITE_MODE_OPTION_EDIT = "Append/edit existing worksheet";
    protected static final Set<String> WRITE_MODE_OPTIONS =
            ImmutableSet.of(WRITE_MODE_OPTION_CREATE, WRITE_MODE_OPTION_EDIT);
    protected static final String CONDITION_WRITE_MODE_IS_CREATE =
            "$.settings." + KEY_WRITE_MODE + ".value == '" + WRITE_MODE_OPTION_CREATE + "'";
    protected static final String CONDITION_WRITE_MODE_IS_NOT_CREATE =
            "$.settings." + KEY_WRITE_MODE + ".value != '" + WRITE_MODE_OPTION_CREATE + "'";
    protected static final String CONDITION_CELL_REFERENCE_BLANK =
            "$.settings." + KEY_CELL_REFERENCE + ".value == null || $.settings." +
                    KEY_CELL_REFERENCE + ".value == ''";

    protected Drive googleDrive;
    protected Sheets sheets;
    protected ExpressionProperty spreadsheetExp;
    protected ExpressionProperty worksheetExp;
    protected String spreadsheetNameOrId;
    protected String worksheetName;
    protected String spreadsheetId;
    protected boolean keyIncludeSharedDrive;
    protected boolean keyDisplaySpreadsheetId;
    protected boolean headerExists;
    protected boolean overwriteWorksheet;
    protected boolean writeHeaderRow;
    protected String writeMode;
    protected String cellReference;
    protected ConnectionResult connectionResult;
    protected ExpressionProperty numOfRetriesExpr;
    protected ExpressionProperty retryIntervalExpr;
    protected int numOfRetries = DEFAULT_RETRIES;
    protected int retryInterval = DEFAULT_RETRY_INTERVAL;
    protected String retriedTimes;
    private int readTimeout;
    private int connTimeout;
    @Inject
    protected Account<ConnectionResult> googleAccount;

    @Override
    public Module getManagedAccountModule(final Account<ConnectionResult> account) {
        return new AbstractModule() {
            @Override
            protected void configure() {
                bind(Key.get(new TypeLiteral<Account<ConnectionResult>>() {
                }))
                        .toInstance(account);
            }
        };
    }

    @Override
    public void defineProperties(PropertyBuilder propertyBuilder) {
        propertyBuilder.describe(KEY_INCLUDE_SHARED_DRIVES, LABEL_INCLUDE_SHARED_DRIVE,
                        DESC_INCLUDE_SHARED_DRIVE)
                .type(SnapType.BOOLEAN)
                .defaultValue(false)
                .add();
        propertyBuilder.describe(KEY_DISPLAY_SPREADSHEET_ID, LABEL_DISPLAY_SPREADSHEET_ID, DESC_DISPLAY_SPREADSHEET_ID)
                .type(SnapType.BOOLEAN)
                .defaultValue(false)
                .add();
        propertyBuilder.describe(KEY_SPREADSHEET, LABEL_SPREADSHEET, String.format(
                DESC_SPREADSHEET, getDescription()))
                .required()
                .expression(SnapProperty.DecoratorType.ACCEPTS_SCHEMA)
                .withSuggestions((suggestionBuilder, propertyValues) -> {
                    ((SheetsApiAccount) googleAccount).setSheetsAPIversion(VERSION_4);
                    Drive drive = googleAccount.connect().getGoogleDrive();
                    keyIncludeSharedDrive = propertyValues.getBoolean(KEY_INCLUDE_SHARED_DRIVES, false);
                    keyDisplaySpreadsheetId = propertyValues.getBoolean(KEY_DISPLAY_SPREADSHEET_ID, false);
                    FileList fileList = getSpreadSheetList(drive);
                    Set<String> spreadsheetName = new TreeSet<>();
                    for (File file : fileList.getFiles()) {
                        // changed from getTitle()
                        // see https://stackoverflow.com/q/36485317/277133
                        if (keyDisplaySpreadsheetId) {
                            spreadsheetName.add(file.getName() + " : " + file.getId());
                        } else {
                            spreadsheetName.add(file.getName());
                        }
                    }
                    if (CollectionUtils.isNotEmpty(spreadsheetName)) {
                        suggestionBuilder.node(KEY_SPREADSHEET).suggestions(
                                spreadsheetName.toArray(new String[0]));
                    } else {
                        throw new ConfigurationException(String.format(
                                ERR_NO_SHEETS_FOUND_MSG, SPREADSHEETS));
                    }
                })
                .add();
        propertyBuilder.describe(KEY_WORKSHEET, LABEL_WORKSHEET, String.format(
                DESC_WORKSHEET, getDescription()))
                .required()
                .expression(SnapProperty.DecoratorType.ACCEPTS_SCHEMA)
                .withSuggestions((suggestionBuilder, propertyValues) -> {
                    String spreadsheetName = propertyValues.get(KEY_SPREADSHEET);
                    try {
                        Set<String> worksheetNames = new TreeSet<>();
                        if (StringUtils.isNotBlank(spreadsheetName)) {
                            ((SheetsApiAccount) googleAccount).setSheetsAPIversion(VERSION_4);
                            ConnectionResult connectionResult = googleAccount.connect();
                            connectionResult.setConnectionTimeout(connTimeout);
                            connectionResult.setReadTimeout(readTimeout);
                            Drive drive = connectionResult.getGoogleDrive();
                            keyIncludeSharedDrive = propertyValues.getBoolean(KEY_INCLUDE_SHARED_DRIVES, false);
                            keyDisplaySpreadsheetId = propertyValues.getBoolean(KEY_DISPLAY_SPREADSHEET_ID, false);
                            Sheets sheets = connectionResult.getSheets();
                            spreadsheetId = getSpreadsheetId(drive, spreadsheetName);
                            List<Sheet> sheetList = getWorksheets(sheets, spreadsheetId);
                            for (Sheet sheet : sheetList) {
                                SheetProperties properties = sheet.getProperties();
                                if (Boolean.TRUE.equals(properties.getHidden()) ||
                                        CollectionUtils.isNotEmpty(sheet.getProtectedRanges())) {
                                    continue;
                                }
                                worksheetNames.add(properties.getTitle());
                            }
                        }
                        if (CollectionUtils.isNotEmpty(worksheetNames)) {
                            suggestionBuilder.node(KEY_WORKSHEET).suggestions(
                                    worksheetNames.toArray(new String[0]));
                        } else {
                            throw new ConfigurationException(String.format(
                                    ERR_NO_SHEETS_FOUND_MSG, WORKSHEETS));
                        }
                    } catch (IOException e) {
                        throw new ConfigurationException(e, ERR_GET_WORKSHEETS)
                                .formatWith(spreadsheetName)
                                .withReason(e.getMessage())
                                .withResolution(RESOLUTION_ADDRESS_ISSUE);
                    }
                })
                .add();
        if (isReadHeaderPropertyRequired()) {
            propertyBuilder.describe(KEY_HEADER_EXISTS, LABEL_HEADER_EXISTS, DESC_HEADER_EXISTS)
                    .type(SnapType.BOOLEAN)
                    .defaultValue(true)
                    .add();
        } else {
            propertyBuilder.describe(KEY_WRITE_MODE, LABEL_WRITE_MODE,
                            DESC_WRITE_MODE)
                    .required()
                    .withAllowedValues(WRITE_MODE_OPTIONS)
                    .defaultValue(WRITE_MODE_OPTION_CREATE)
                    .add();
            propertyBuilder.describe(KEY_OVERWRITE_WORKSHEET, LABEL_OVERWRITE_WORKSHEET,
                    DESC_OVERWRITE_WORKSHEET)
                    .type(SnapType.BOOLEAN)
                    .enableIf(CONDITION_WRITE_MODE_IS_CREATE)
                    .add();
            propertyBuilder.describe(KEY_CELL_REFERENCE, LABEL_CELL_REFERENCE, DESC_CELL_REFERENCE)
                    .enableIf(CONDITION_WRITE_MODE_IS_NOT_CREATE)
                    .add();
            propertyBuilder.describe(KEY_WRITE_HEADER_ROW, LABEL_WRITE_HEADER_ROW,
                    DESC_WRITE_HEADER_ROW)
                    .type(SnapType.BOOLEAN)
                    .defaultValue(true)
                    .add();
        }
        defineAdditionalProperties(propertyBuilder);
        defineRetryProperties(propertyBuilder, RETRIES_DESC, DEFAULT_RETRIES);
        createConnectionProperties(propertyBuilder);
    }

    abstract void defineAdditionalProperties(PropertyBuilder propertyBuilder);

    protected void createConnectionProperties(PropertyBuilder propertyBuilder) {
        SnapProperty readTimeoutProp = propertyBuilder
                .describe(READ_TIMEOUT_PROP, READ_TIMEOUT_LABEL, READ_TIMEOUT_DESC)
                .expression()
                .type(SnapType.INTEGER)
                .withMinValue(0)
                .withMaxValue(Integer.MAX_VALUE)
                .defaultValue(DEFAULT_READ_TIMEOUT_IN_SEC)
                .build();
        SnapProperty connTimeoutProp = propertyBuilder
                .describe(CONN_TIMEOUT_PROP, CONN_TIMEOUT_LABEL, CONN_TIMEOUT_DESC)
                .expression()
                .type(SnapType.INTEGER)
                .withMinValue(0)
                .withMaxValue(Integer.MAX_VALUE)
                .defaultValue(DEFAULT_CONN_TIMEOUT_IN_SEC)
                .build();
        PropertyBuilder connPropertiesBuilder = propertyBuilder
                .describe(CONNECTION_PROPERTIES_PROP, CONNECTION_PROPERTIES_LABEL,
                        CONNECTION_PROPERTIES_DESC)
                .type(SnapType.COMPOSITE)
                .withEntry(readTimeoutProp)
                .withEntry(connTimeoutProp);
        connPropertiesBuilder.add();
    }

    @Override
    public void configure(PropertyValues propertyValues) throws ConfigurationException {
        keyIncludeSharedDrive = propertyValues.getBoolean(KEY_INCLUDE_SHARED_DRIVES, false);
        spreadsheetExp = propertyValues.getAsExpression(KEY_SPREADSHEET);
        keyDisplaySpreadsheetId = propertyValues.getBoolean(KEY_DISPLAY_SPREADSHEET_ID, false);
        worksheetExp = propertyValues.getAsExpression(KEY_WORKSHEET);
        ExpressionProperty readTimeoutExp = propertyValues.getExpressionPropertyFor(
                propertyValues.get(CONNECTION_PROPERTIES_PROP), READ_TIMEOUT_PROP);
        readTimeout = evalIntProperty(readTimeoutExp,
                null, DEFAULT_READ_TIMEOUT_IN_SEC, 0, errorViews);
        ExpressionProperty connTimeoutExp = propertyValues.getExpressionPropertyFor(
                propertyValues.get(CONNECTION_PROPERTIES_PROP), CONN_TIMEOUT_PROP);
        connTimeout = evalIntProperty(connTimeoutExp,
                null, DEFAULT_CONN_TIMEOUT_IN_SEC, 0, errorViews);
        checkAccount();
        configureAdditional(propertyValues);
        initSpreadsheetAndDriveServices();
        retriedTimes = String.format(FORMAT_RETRIED, numOfRetries);
        numOfRetriesExpr = propertyValues.getAsExpression(RETRIES_PROP);
        retryIntervalExpr = propertyValues.getAsExpression(RETRY_INTERVAL_PROP);
    }

    private void checkAccount() {
        if (googleAccount == null) {
            throw new ConfigurationException(ERR_INIT_GOOGLE_ACCOUNT)
                    .withReason(REASON_GOOGLE_ACCOUNT)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
    }

    /**
     * Initialises service objects to interact with Google Drive and Google Spreadsheets
     *
     */
    protected void initSpreadsheetAndDriveServices() {
        if (googleAccount instanceof SheetsApiAccount) {
            ((SheetsApiAccount) googleAccount).setRetry(numOfRetries, retryInterval);
        }
        connectionResult = googleAccount.connect();
        connectionResult.setConnectionTimeout(connTimeout);
        connectionResult.setReadTimeout(readTimeout);
        googleDrive = connectionResult.getGoogleDrive();
        sheets = connectionResult.getSheets();
    }

    /**
     * Allows the snaps to read their additional specific properties.
     *
     * @param propertyValues
     */
    protected void configureAdditional(final PropertyValues propertyValues) {
        // NO OP
    }

    /**
     * Subclass must override this method to tell is the header exists property required or not
     *
     * @return true if header required, false otherwise
     */
    protected abstract boolean isReadHeaderPropertyRequired();

    @Override
    public void defineInputSchema(SchemaProvider schemaProvider) {
        if (!schemaProvider.getRegisteredInputViewNames().isEmpty()) {
            String inputViewName = schemaProvider.getRegisteredInputViewNames().iterator().next();
            List<Schema> schemas = new ArrayList<>();
            defineInputSchemaAdditional(schemaProvider, schemas);
            SchemaBuilder schemaBuilder = schemaProvider.getSchemaBuilder(inputViewName);
            for (Schema schema : schemas) {
                schemaBuilder.withChildSchema(schema);
            }
            schemaBuilder.build();
        }
    }

    /**
     * Subclasses can override this method to provide the input view fields.
     *
     * @param schemaProvider
     * @param schemas
     */
    protected void defineInputSchemaAdditional(SchemaProvider schemaProvider,
            List<Schema> schemas) {
        // NO OP
    }

    protected String getId(Drive drive, String name) {
        return getId(drive, name, false);
    }

    protected String getSpreadsheetId(Drive drive, String name) {
        return getSpreadsheetId(drive, name, false);
    }

    /**
     * Gets the spreadsheet ID from its name by using Google Drive API.
     *
     * @param drive - Google Drive
     * @param name - spreadsheet name
     *
     * @return spreadsheet ID (also called 'key')
     */
    protected String getId(Drive drive, String name, boolean nullIfNotExists) {
        FileList fileList;
        try {
            String query = String.format(FORMAT_NAME, escapeSheetName(name));
            fileList = Failsafe.with(getRetryPolicy(numOfRetries, retryInterval))
                    .onFailedAttempt(e -> LOG.warn("Failed to get spreadsheet file list, {}",
                            e.getMessage()))
                    .get(context -> {
                        logRetryAttempt(context, LOG);
                        if (keyIncludeSharedDrive) {
                            return drive.files().list().setFields(FILES_ID_NAME)
                                    .setQ(query)
                                    .setSupportsAllDrives(true)
                                    .setIncludeItemsFromAllDrives(true)
                                    .execute();
                        } else {
                            return drive.files().list().setFields(FILES_ID_NAME)
                                    .setQ(query)
                                    .execute();
                        }
                    });
        } catch (Throwable t) {
            Throwable t2 =  t instanceof FailsafeException ? t.getCause() : t;
            throw new SnapDataException(t2, ERR_SPREADSHEET_NOT_FOUND)
                    .formatWith(name)
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }
        List<String> idList = new ArrayList<>();
        if (fileList != null) {
            for (File file : fileList.getFiles()) {
                if (StringUtils.equals(file.getName(), name)) {
                    String id = file.getId();
                    if (StringUtils.isNotBlank(id)) {
                        idList.add(id);
                    } else {
                        throw new SnapDataException(ERR_UNEXPECTED_SEARCH_RESULT)
                                .formatWith(name)
                                .withReason(REASON_EMPTY_ID)
                                .withResolutionAsDefect();
                    }
                }
            }
        }
        switch (idList.size()) {
            case 0:
                if (nullIfNotExists) {
                    return null;
                }
                throw new SnapDataException(ERR_SPREADSHEET_NOT_FOUND)
                        .formatWith(name)
                        .withReason(REASON_SPREADSHEET_NOT_FOUND)
                        .withResolution(RESOLUTION_ADDRESS_ISSUE);
            case 1:
                return idList.get(0);
            default:
                throw new SnapDataException(ERR_UNEXPECTED_SEARCH_RESULT)
                        .formatWith(name)
                        .withReason(REASON_TOO_MANY)
                        .withResolution(RESOLUTION_DUPLICATE_SPREADSHEET);
        }
    }

    /**
     * Checking the given KEY_SPREADSHEET property is ID or Name And
     * Gets the spreadsheet ID
     *
     * @param drive - Google Drive
     * @param spreadsheetNameOrId - spreadsheet name/id
     *
     * @return spreadsheet ID (also called 'key')
     */
    protected String getSpreadsheetId(Drive drive, String spreadsheetNameOrId, boolean nullIfNotExists){
        FileList fileList = getSpreadSheetList(drive);
        Set<String> setOfSpreadsheetNames = new TreeSet<>();
        Set<String> setOfSpreadsheetIds = new TreeSet<>();
        Set<String> spreadsheetNameAndId = new TreeSet<>();
        for (File file : fileList.getFiles()) {
            setOfSpreadsheetNames.add(file.getName());
            setOfSpreadsheetIds.add(file.getId());
            spreadsheetNameAndId.add(file.getName() + " : " + file.getId());
        }
        if (setOfSpreadsheetNames.contains(spreadsheetNameOrId)) {
            spreadsheetId = getId(drive, spreadsheetNameOrId);
        } else if (setOfSpreadsheetIds.contains(spreadsheetNameOrId)) {
            spreadsheetId = spreadsheetNameOrId;
        } else if (spreadsheetNameAndId.contains(spreadsheetNameOrId)) {
            // Splitting the given spreadsheetName by separating spreadsheetId
            String[] spreadsheets = spreadsheetNameOrId.split("\\s:\\s");

            spreadsheetId = spreadsheets[spreadsheets.length-1];
        } else {
            if (nullIfNotExists) {
                //For Worksheet Writer
                spreadsheetId = null;
            } else {
                //For Worksheet Reader
                throw new SnapDataException(ERR_SPREADSHEET_NOT_FOUND)
                        .formatWith(spreadsheetNameOrId)
                        .withReason(REASON_SPREADSHEET_NOT_FOUND)
                        .withResolution(RESOLUTION_ADDRESS_ISSUE);
            }
        }
        return spreadsheetId;
    }

    @VisibleForTesting
    static String escapeSheetName(String name) {
        // Escape all backslashes and single quotes in the Spreadsheet name
        return name.replaceAll("([\\\\'])", "\\\\$1");
    }

    protected FileList getSpreadSheetList(Drive drive) {
        try {
            return Failsafe.with(getRetryPolicy(numOfRetries, retryInterval))
                    .onFailedAttempt(e -> LOG.warn("Failed to get spreadsheet list, {}",
                            e.getMessage()))
                    .get(context -> {
                        logRetryAttempt(context, LOG);
                        if (keyIncludeSharedDrive) {
                            return drive.files()
                                    .list()
                                    .setFields(FILES_ID_NAME)
                                    .setQ(ACTIVE_SHEETS)
                                    .setIncludeItemsFromAllDrives(true)
                                    .setSupportsAllDrives(true)
                                    .execute();
                        } else {
                            return drive.files()
                                    .list()
                                    .setFields(FILES_ID_NAME)
                                    .setQ(ACTIVE_SHEETS)
                                    .execute();
                        }
                    });
        } catch (Throwable t) {
            Throwable t2 = t instanceof FailsafeException ? t.getCause() : t;
            throw new SnapDataException(t2, ERR_GET_SPREADSHEETS)
                    .withReason(t2.getMessage())
                    .withResolution(RESOLUTION_ADDRESS_ISSUE);
        }

    }

    /**
     *  Gets a list of worksheets for a given spreadshsheet ID.
     *
     * @param sheets        - Sheets object
     * @param spreadsheetId - spreadsheet ID
     *
     * @return a list of worksheets
     *
     * @throws IOException if fails during the request execution
     */
    protected List<Sheet> getWorksheets(Sheets sheets, String spreadsheetId) throws IOException {
        try {
            return Failsafe.with(getRetryPolicy(numOfRetries, retryInterval))
                    .onFailedAttempt(e -> LOG.warn("Failed to get worksheet list for {}, {}",
                            spreadsheetNameOrId, e.getMessage()))
                    .get(context -> {
                        logRetryAttempt(context, LOG);
                        return getWorksheetsWithDelay(sheets, spreadsheetId);
                    });
        } catch (Throwable t) {
            Throwable t2 = t instanceof FailsafeException ? t.getCause() : t;
            if (t2 instanceof IOException) {
                throw (IOException) t2;
            }
            throw new IOException(t2);
        }
    }

    private List<Sheet> getWorksheetsWithDelay(Sheets sheets, String spreadsheetId)
            throws IOException {
        try {
            Spreadsheet spreadsheet = sheets.spreadsheets()
                    .get(spreadsheetId)
                    .execute();
            return spreadsheet.getSheets();
        } catch (GoogleJsonResponseException e) {
            // The error "429 Too Many Requests ..." may occur intermittently. Sleep n seconds, log
            // and retry. Refer to https://developers.google.com/sheets/api/limits for usage limit.
            if (StringUtils.startsWithIgnoreCase(e.getMessage(), TOO_MANY_REQUESTS)) {
                sleepNoInterrupt(SLEEP_SECONDS_ERR_429, TimeUnit.SECONDS, LOG);
                LOG.info("Too many requests have been sent to Google Spreadsheets, will " +
                        "wait for {} seconds and retry, detail: {}", SLEEP_SECONDS_ERR_429,
                        e.getMessage());
            }
            throw e;
        }
    }

    protected abstract String getDescription();

    @Override
    public void process(Document document, String inputViewName) {
        try {
            numOfRetries = evalIntProperty(numOfRetriesExpr, null, DEFAULT_RETRIES, MIN_RETRIES,
                    errorViews);
            retryInterval = evalIntProperty(retryIntervalExpr, null, MIN_RETRY_INTERVAL,
                    MIN_RETRY_INTERVAL, errorViews);
            processAdditional(document, inputViewName);
        } catch (SuggestViewAbortException e) {
            throw e;
        } catch (SnapDataException e) {
            errorViews.write(e, document);
        } catch (ExecutionException e) {
            SnapDataException ex = new SnapDataException(e.getMessage())
                    .withReason(e.getReason())
                    .withResolution(e.getResolution());
            errorViews.write(ex, document);
        } catch (Exception e) {
            errorViews.write((SnapDataException) new SnapDataException(e, e.getMessage())
                    .withResolution(RESOLUTION_ADDRESS_ISSUE), document);
        }
    }

    /**
     * This method does the actual processing of the incoming document.
     * Spreadsheet snaps must override this method to process the document accordingly.
     *
     * @param document
     * @param inputViewName
     */
    protected abstract void processAdditional(Document document, String inputViewName);

    /**
     * Refreshes access token if the account is OAuth2.
     *
     * @param e - exception caught at the time of calling or null if no exception
     *
     * @return true if refreshed, false if not refreshed
     */
    protected boolean refreshAccessToken(Exception e) {
        if (googleAccount instanceof GoogleSpreadsheetOAuth2Account) {
            GoogleSpreadsheetOAuth2Account account = (GoogleSpreadsheetOAuth2Account) googleAccount;
            if (account.reloadAccount()) {
                initSpreadsheetAndDriveServices();
                SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
                Long accessTokenExpiration = account.getAccessTokenExpiration() * 1000;
                LOG.warn(String.format("Access token is refreshed at %s, and will expire at %s",
                        formatter.format(System.currentTimeMillis()),
                        formatter.format(accessTokenExpiration)), e);
                return true;
            }
        }
        return false;
    }

    private String evaluateSheetName(ExpressionProperty expression, Document document) {
        try {
            return expression.eval(document);
        } catch (SnapDataException e) {
            if (StringUtils.contains(e.getMessage(), IS_UNDEFINED)) {
                // If the value of the JSON path for the sheet name is null, write more relevant
                // error message instead of throwing the error from the platform.
                return null;
            }
            throw e;
        }
    }

    /**
     * Evaluates spreadsheet name and worksheet name expression properties.
     *
     * @param document - input document to be used for evaluation
     *
     * @return true if spreadsheet name or worksheet name is blank to handle error accordingly
     */
    protected boolean evalSheetNames(Document document) {
        spreadsheetNameOrId = evaluateSheetName(spreadsheetExp, document);
        worksheetName = evaluateSheetName(worksheetExp, document);
        return StringUtils.isBlank(spreadsheetNameOrId) || StringUtils.isBlank(worksheetName);
    }

    /**
     * Instantiates a RetryPolicy object.
     *
     * @param numOfRetries  - max number of retries
     * @param retryInterval - retry interval in seconds
     *
     * @return RetryPolicy object
     */
    protected static RetryPolicy getRetryPolicy(int numOfRetries, int retryInterval) {
        return new RetryPolicy()
                .withMaxRetries(numOfRetries)
                .withDelay(retryInterval, TimeUnit.SECONDS)
                .abortOn(SuggestViewAbortException.class);
    }

    /**
     * Writes a warning-level log with the retry attempt sequence number.
     * The first execution is 0 and is not logged.
     *
     * @param context - Failsafe retry execution context
     * @param log     - Logger from the calling class
     */
    protected static void logRetryAttempt(ExecutionContext context, Logger log) {
        int count = context.getExecutions();
        if (count > 0) {
            log.warn("Retry attempt: {}", count);
        }
    }

    protected boolean isEmptyRow(Map<Object, Object> map) {
        if (map != null)  {
            for (Object value : map.values()) {
                if (value instanceof String && StringUtils.isBlank((String) value)
                        || value == null) {
                    continue;
                }
                return false;
            }
        }
        return true;
    }

    protected Map<Object, Object> getRecord(List<CellData> dataColumns, List<String> header) {
        CellData dataColumn;
        CellFormat cellFormat;
        ExtendedValue cellExtendedValue;
        int columnIndex = 0;
        boolean writeValueAsDate = false;
        Map<Object, Object> record = new LinkedHashMap<>();

        for (Object key : header) {
            // If a row is empty, dataColumns List will be null
            if (dataColumns != null) {
                /* This check is to avoid failing in case the last column
                 * has no data - SWAT-1727.
                 * In such a case header.size() > dataColumns.size()
                 * */
                if (columnIndex < dataColumns.size()) {
                    dataColumn = dataColumns.get(columnIndex++);
                } else {
                    dataColumn = null;
                }
                if (dataColumn != null) {
                    cellFormat = dataColumn.getEffectiveFormat();
                    cellExtendedValue = dataColumn.getEffectiveValue();
                } else {
                    cellFormat = null;
                    cellExtendedValue = null;
                }
                if (cellFormat != null) {
                    NumberFormat numberFormat = cellFormat.getNumberFormat();
                    if (numberFormat != null) {
                        String type = numberFormat.getType();
                        if (TYPE_DATE.equalsIgnoreCase(type)) {
                            writeValueAsDate = true;
                        }
                    }
                }
            } else {
                cellExtendedValue = null;
            }

            record.put(key, parseExtendedValue(cellExtendedValue,
                    writeValueAsDate));
            writeValueAsDate = false;
        }
        return record;
    }

    /**
     * Parses the given {@link ExtendedValue} to get the actual value
     *
     * @param extendedValue
     * @param writeValueAsDate
     *
     * @return actual value with actual type
     */
    private Object parseExtendedValue(ExtendedValue extendedValue, boolean writeValueAsDate) {
        if (extendedValue == null) {
            return null;
        }

        Object finalValue;
        // attempt boolean value first
        finalValue = extendedValue.getBoolValue();
        if (finalValue == null) {
            // attempt number value next
            finalValue = extendedValue.getNumberValue();
            if (finalValue == null) {
                // attempt string value next
                finalValue = extendedValue.getStringValue();
                if (finalValue == null) {
                    // attempt formula value next
                    finalValue = extendedValue.getFormulaValue();
                    if (finalValue == null) {
                        // attempt error value finally
                        finalValue = extendedValue.getErrorValue().getType();
                    }
                }
            } else {
                // Date value is represented as number by Google Spreadsheet API
                // So if a numeric value is of type date then its converted into
                //   Joda DateTime object
                if (writeValueAsDate) {
                    finalValue = new LocalDate(new DateTime(DateUtil.getJavaDate(
                            (Double) finalValue)));
                }
            }
        }
        return finalValue;
    }

    protected List<GridData> readWorksheet(String spreadsheetId, String worksheetName)
            throws IOException {
        try {
            Sheets.Spreadsheets.Get getRequest = sheets
                    .spreadsheets()
                    .get(spreadsheetId)
                    .setIncludeGridData(true)
                    .setRanges(Arrays.asList(String.format(DEFAULT_RANGE, worksheetName)));
            return getRequest.execute().getSheets().get(0).getData();
        } catch (GoogleJsonResponseException e) {
            // The error "503 Service Unavailable ..." or "429 Too Many Requests ..." occurs
            // intermittently. Sleep n seconds, log and retry.
            String errMessage = e.getMessage();
            if (StringUtils.startsWithIgnoreCase(errMessage, TOO_MANY_REQUESTS)) {
                // if number of requests exceeded the hourly limit, wait longer and retry
                sleepNoInterrupt(SLEEP_SECONDS_ERR_429, TimeUnit.SECONDS, LOG);
            } else if (StringUtils.containsIgnoreCase(errMessage, INVALID_RANGE)) {
                // The error "Invalid range" occurs if the worksheet is a chart or an image.
                String sheetType = getSheetType(spreadsheetId, this.worksheetName);
                if (sheetType != null && !GRID.equalsIgnoreCase(sheetType)) {
                    // Worksheet Reader can read 'GRID' type only
                    throw getErrorReadWorksheet(e, worksheetName, String.format(
                            REASON_UPSUPPORTED_WORKSHEET_TYPE, sheetType));
                }
            }
            throw e;
        }
    }

    protected String getSheetType(String spreadsheetId, String worksheetName) {
        try {
            for (Sheet sheet : getWorksheets(sheets, spreadsheetId)) {
                SheetProperties properties = sheet.getProperties();
                if (properties.getTitle().equals(worksheetName)) {
                    String sheetType = properties.getSheetType();
                    if (OBJECT.equalsIgnoreCase(sheetType) && sheet.getCharts() != null) {
                        return CHART;
                    } else {
                        return sheetType;
                    }
                }
            }
        } catch (IOException ioe) {
            LOG.error("Error getting sheet type {}: ", worksheetName, ioe.getMessage());
            return null;
        }
        return null;
    }

    protected SnapDataException getErrorReadWorksheet(Throwable e, String range, String reason) {
        return (SnapDataException) new SnapDataException(e, ERR_READ_WORKSHEET)
                .formatWith(range, spreadsheetNameOrId)
                .withReason(reason)
                .withResolution(RESOLUTION_ADDRESS_ISSUE);
    }
}
