/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.drive.Drive;
import com.snaplogic.account.api.AccountType;
import com.snaplogic.account.api.ValidatableAccount;
import com.snaplogic.account.api.capabilities.AccountCategory;
import com.snaplogic.api.ExecutionException;
import com.snaplogic.snap.api.account.oauth2.DynamicOauth2Account;
import com.snaplogic.snap.api.capabilities.General;
import com.snaplogic.snap.api.capabilities.Version;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.snaplogic.snaps.google.spreadsheet.Constants.DRIVE_SERVICE_NAME;
import static com.snaplogic.snaps.google.spreadsheet.GoogleSpreadsheetOAuth2Account.HTTP_TRANSPORT;
import static com.snaplogic.snaps.google.spreadsheet.Messages.DYNAMIC_AUTH_ACCOUNT_DOC_LINK;
import static com.snaplogic.snaps.google.spreadsheet.Messages.DYNAMIC_AUTH_ACCOUNT_TITLE;
import static com.snaplogic.snaps.google.spreadsheet.Messages.ERR_SERVICES_INSTANTIATION_MSG;
import static com.snaplogic.snaps.google.spreadsheet.Messages.ERR_SERVICES_INSTANTIATION_RESOLUTION;
import static com.snaplogic.snaps.google.spreadsheet.SpreadsheetsBase.DEFAULT_RETRIES;
import static com.snaplogic.snaps.google.spreadsheet.SpreadsheetsBase.DEFAULT_RETRY_INTERVAL;

/**
 * Represents connection to google spreadsheet server.
 * Encapsulates access token.
 *
 * @author smudassir
 */
@General(title = DYNAMIC_AUTH_ACCOUNT_TITLE, docLink = DYNAMIC_AUTH_ACCOUNT_DOC_LINK)
@Version(snap = 1)
@AccountCategory(type = AccountType.CUSTOM)
public class GoogleSpreadsheetDynamicOAuth2Account extends DynamicOauth2Account<ConnectionResult>
        implements ValidatableAccount<ConnectionResult>, SheetsApiAccount {
    private static final Logger LOG =
            LoggerFactory.getLogger(GoogleSpreadsheetDynamicOAuth2Account.class);
    private int sheetsApiVersion = 4;
    private int numOfRetries = DEFAULT_RETRIES;
    private int retryInterval = DEFAULT_RETRY_INTERVAL;

    @Override
    public ConnectionResult connect() throws ExecutionException {
        try {
            GoogleCredential credential = new GoogleCredential.Builder().build();
            credential.setAccessToken(getAccessToken());
            Drive googleDrive = new Drive.Builder(HTTP_TRANSPORT,
                    JacksonFactory.getDefaultInstance(), credential)
                    .setApplicationName(DRIVE_SERVICE_NAME)
                    .build();
            return new ConnectionResult(googleDrive)
                    .withCredential(credential);
        } catch (Throwable e) {
            throw new ExecutionException(ERR_SERVICES_INSTANTIATION_MSG)
                    .withReason(e.getMessage())
                    .withResolution(ERR_SERVICES_INSTANTIATION_RESOLUTION);
        }
    }

    @Override
    public void disconnect() throws ExecutionException {
        // NO OP
    }

    @Override
    public int getSheetsAPIversion() {
        return sheetsApiVersion;
    }

    @Override
    public void setSheetsAPIversion(int version) {
        this.sheetsApiVersion = version;
    }

    @Override
    public void setRetry(int numOfRetries, int retryInterval) {
        this.numOfRetries = numOfRetries;
        this.retryInterval = retryInterval;
    }
}