/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.services.drive.Drive;
import com.google.api.services.sheets.v4.Sheets;

import java.io.IOException;

import static com.snaplogic.snaps.google.spreadsheet.Constants.SPREADSHEET_SERVICE_NAME;
import static com.snaplogic.snaps.google.spreadsheet.GoogleSpreadsheetOAuth2Account.HTTP_TRANSPORT;
import static com.snaplogic.snaps.google.spreadsheet.GoogleSpreadsheetOAuth2Account.JACKSON_FACTORY;

/**
 * Represents successful connection to google drive and spreadsheets services
 *
 * @author smudassir
 */
public class ConnectionResult {
    private final Drive googleDrive;
    private GoogleCredential credential;
    private int readTimeout;
    private int connTimeout;
    private static final int SEC_TO_MSEC = 1000;


    /**
     * one-arg constructor
     *
     * @param googleDrive
     */
    public ConnectionResult(Drive googleDrive) {
        this.googleDrive = googleDrive;
    }

    public Drive getGoogleDrive() {
        return googleDrive;
    }

    public ConnectionResult withCredential(GoogleCredential credential) {
        this.credential = credential;
        return this;
    }

    public void setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
    }

    public void setConnectionTimeout(int connTimeout) {
        this.connTimeout = connTimeout;
    }

    /**
     * Gets a Sheets object (Google Sheets API service).
     *
     * @return Sheets object
     */
    public Sheets getSheets() {
        HttpRequestInitializer httpRequestInitializer = new HttpRequestInitializer() {
            @Override
            public void initialize(final HttpRequest httpRequest) throws IOException {
                httpRequest.setConnectTimeout(connTimeout * SEC_TO_MSEC);
                httpRequest.setReadTimeout(readTimeout * SEC_TO_MSEC);
                credential.initialize(httpRequest);
            }
        };
        return new Sheets.Builder(HTTP_TRANSPORT, JACKSON_FACTORY, httpRequestInitializer)
                .setApplicationName(SPREADSHEET_SERVICE_NAME)
                .build();
    }
}
