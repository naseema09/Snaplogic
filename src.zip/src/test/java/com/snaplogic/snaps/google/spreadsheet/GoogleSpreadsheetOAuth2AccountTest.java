package com.snaplogic.snaps.google.spreadsheet;

import com.snaplogic.common.SnapType;
import com.snaplogic.common.properties.AllowedValuesConstraint;
import com.snaplogic.common.properties.SnapProperty;
import com.snaplogic.common.properties.SnapPropertyImpl;
import com.snaplogic.common.properties.builders.PropertyBuilderImpl;
import com.snaplogic.snap.api.PropertyCategory;
import com.snaplogic.snap.api.PropertyValues;
import com.snaplogic.snap.test.harness.MockSnapDefinition;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.util.ArrayList;
import java.util.List;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

/**
 * Tests OAuth 2.0 scenarios for Google Spreadsheet Accounts
 *
 * @author rhowlett
 */
public class GoogleSpreadsheetOAuth2AccountTest {

    @Rule
    public final ExpectedException exception = ExpectedException.none();

    private GoogleSpreadsheetOAuth2Account spreadsheetOAuth2Account;

    @Before
    public void setUp() throws Exception {
        spreadsheetOAuth2Account = new GoogleSpreadsheetOAuth2Account();
    }

    @Test
    public void defineAuthEndpointProperties_IsEqualToImmutableSnapPropertyWithOfflineAccessType()
            throws Exception {
        SnapProperty expectedAccessTypeSnapProperty = new SnapPropertyImpl(
                "access_type", Messages.ACCESS_TYPE_LABEL, Messages.ACCESS_TYPE_DESC,
                PropertyCategory.SETTINGS, SnapType.STRING);
        expectedAccessTypeSnapProperty.setDefaultValue("offline");
        expectedAccessTypeSnapProperty.setImmutable(true);

        SnapProperty expectedApprovalPromptSnapProperty = new SnapPropertyImpl(
                "approval_prompt", Messages.APPROVAL_PROMPT_LABEL, Messages.APPROVAL_PROMPT_DESC,
                PropertyCategory.SETTINGS, SnapType.STRING);
        expectedApprovalPromptSnapProperty.addConstraint(AllowedValuesConstraint.constrainTo
                ("auto", "force"));
        expectedApprovalPromptSnapProperty.setDefaultValue("auto");

        List<SnapProperty> expectedSnapProperties = new ArrayList<>();
        expectedSnapProperties.add(expectedAccessTypeSnapProperty);
        expectedSnapProperties.add(expectedApprovalPromptSnapProperty);

        PropertyBuilderImpl propertyBuilder = new PropertyBuilderImpl(new MockSnapDefinition(),
                PropertyCategory.ACCOUNT);

        // Method under test
        List<SnapProperty> actualSnapProperties =
                spreadsheetOAuth2Account.defineAuthEndpointProperties(propertyBuilder);

        assertThat(actualSnapProperties, equalTo(expectedSnapProperties));
    }

    @Test
    public void
    configureAdditionalProperties_WithoutAutoRefreshToken_UpdatesTheAccountRefreshToken() throws
            Exception {
        PropertyValues propertyValues = createMock(PropertyValues.class);
        expect(propertyValues.get(GoogleSpreadsheetOAuth2Account.AUTO_REFRESH_TOKEN)).andReturn
                (Boolean.FALSE);
        expect(propertyValues.get(GoogleSpreadsheetOAuth2Account.REFRESH_TOKEN)).andReturn
                ("abcd1234");
        replay(propertyValues);

        // Method under test
        spreadsheetOAuth2Account.configureAdditional(propertyValues);

        assertThat("The refreshToken must be null as auto-refresh has not been enabled",
                spreadsheetOAuth2Account.getRefreshToken(), nullValue(String.class));
    }

    @Test
    public void configureAdditionalProperties_WithAutoRefreshToken_UpdatesTheAccountRefreshToken
            () throws Exception {
        String expectedRefreshTokenValue = "abcd1234";

        PropertyValues propertyValues = createMock(PropertyValues.class);
        expect(propertyValues.get(GoogleSpreadsheetOAuth2Account.AUTO_REFRESH_TOKEN))
                .andReturn(Boolean.TRUE);
        expect(propertyValues.get(GoogleSpreadsheetOAuth2Account.REFRESH_TOKEN))
                .andReturn(expectedRefreshTokenValue);
        replay(propertyValues);

        // Method under test
        spreadsheetOAuth2Account.configureAdditional(propertyValues);

        assertThat("The refreshToken must have been updated to the expected value as auto-refresh" +
                " has been enabled", spreadsheetOAuth2Account.getRefreshToken(), equalTo
                (expectedRefreshTokenValue));
    }
}
