package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.AddSheetRequest;
import com.google.api.services.sheets.v4.model.AddSheetResponse;
import com.google.api.services.sheets.v4.model.AppendValuesResponse;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetRequest;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetResponse;
import com.google.api.services.sheets.v4.model.DeleteSheetRequest;
import com.google.api.services.sheets.v4.model.GridProperties;
import com.google.api.services.sheets.v4.model.Request;
import com.google.api.services.sheets.v4.model.Response;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.Spreadsheet;
import com.google.api.services.sheets.v4.model.SpreadsheetProperties;
import com.google.api.services.sheets.v4.model.UpdateValuesResponse;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.common.collect.Lists;
import com.snaplogic.api.ConfigurationException;
import com.snaplogic.snap.api.SnapDataException;
import com.snaplogic.snap.test.harness.SnapTestRunner;
import com.snaplogic.snap.test.harness.TestFixture;
import com.snaplogic.snap.test.harness.TestResult;
import com.snaplogic.snap.test.harness.TestSetup;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.math.BigInteger;
import java.util.List;

import static org.easymock.EasyMock.anyInt;
import static org.easymock.EasyMock.anyObject;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.mock;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.fail;

/**
 * Tests for {@link WorksheetWriter}
 *
 * @author aoutzen
 */
@RunWith(SnapTestRunner.class)
@TestFixture(
        snap = WorksheetWriter.class,
        input = "data/writer/worksheet_writer_input_data.json",
        properties = "data/writer/worksheet_writer_properties.json",
        account = GoogleSpreadsheetOAuth2Account.class,
        expectedErrorPath = "expected/writer/err",
        expectedOutputPath = "expected/writer/out"
)
public class WorksheetWriterTest {
    GoogleSpreadsheetOAuth2Account googleAccount;
    ConnectionResult googleConnection;
    Drive googleDrive;
    Sheets sheets;

    @Before
    public void setup() {
        // Initialize of Account, Connection, Drive, and Sheets client
        googleAccount = mock(GoogleSpreadsheetOAuth2Account.class);
        googleConnection = mock(ConnectionResult.class);
        googleDrive = mock(Drive.class);
        sheets = mock(Sheets.class);
        googleAccount.setRetry(anyInt(), anyInt());
        expectLastCall();
        expect(googleAccount.connect()).andReturn(googleConnection).anyTimes();
        googleConnection.setConnectionTimeout(20);
        expectLastCall();
        googleConnection.setReadTimeout(180);
        expectLastCall();
        expect(googleConnection.getGoogleDrive()).andReturn(googleDrive);
        expect(googleConnection.getSheets()).andReturn(sheets);
        ((SheetsApiAccount) googleAccount).setSheetsAPIversion(4);
        expectLastCall();
        replay(googleAccount, googleConnection);
    }

    @TestFixture
    public void testCreateNewWorksheetOnExistingSpreadsheet(TestSetup setup) throws Exception {
        testNewWorksheetCreationOnExistingSpreadsheet(setup, false, "New Worksheet");
    }

    @TestFixture(
            propertyOverrides = {
                    "$.settings.KeyOverwriteWorksheet.value", "true",
                    "$.settings.KeyWorksheet.value", "\"Existing Worksheet\""
            }
    )
    public void testCreateNewWorksheetWithExistingWorksheetOverwriteOnExistingSpreadsheet(TestSetup setup) throws Exception {
        testNewWorksheetCreationOnExistingSpreadsheet(setup, true, "Existing Worksheet");
    }

    @TestFixture(
            propertyOverrides = {"$.settings.KeySpreadsheet.value", "\"New Spreadsheet\""}
    )
    public void testCreateNewWorksheetOnNewSpreadsheet(TestSetup setup) throws Exception {
        testNewWorksheetCreationOnNewSpreadsheet(setup, false, "New Worksheet");
    }

    @TestFixture(
            propertyOverrides = {
                    "$.settings.KeySpreadsheet.value", "\"New Spreadsheet\"",
                    "$.settings.KeyWorksheet.value", "\"Sheet1\""
            }
    )
    public void testNewWorksheetSheet1OnNewSpreadsheet(TestSetup setup) throws Exception {
        testNewWorksheetCreationOnNewSpreadsheet(setup, true, "Sheet1");
    }

    @TestFixture(
            propertyOverrides = {
                    "$.settings.KeyWriteMode.value", "\"Append/edit existing worksheet\"",
                    "$.settings.KeyWorksheet.value", "\"Existing Worksheet\""
            }
    )
    public void testAppendExistingWorksheet(TestSetup setup) throws Exception {
        testExistingWorksheetEditing(setup, true, "Existing Worksheet");
    }

    @TestFixture(
            propertyOverrides = {
                    "$.settings.KeyWriteMode.value", "\"Append/edit existing worksheet\"",
                    "$.settings.KeyWorksheet.value", "\"Existing Worksheet\"",
                    "$.settings.KeyCellReference.value", "\"ZZ4\""
            }
    )
    public void testAppendExistingWorksheetWithCellReference(TestSetup setup) throws Exception {
        testExistingWorksheetEditing(setup, false, String.format("%s!%s%d:%s%d", "Existing Worksheet", "ZZ", 4, "AAC", 7));
    }

    @TestFixture(
            propertyOverrides = {
                    "$.settings.KeyWriteMode.value", "\"Append/edit existing worksheet\"",
                    "$.settings.KeyWorksheet.value", "\"Existing Worksheet\"",
                    "$.settings.KeyCellReference.value", "\"ZAB4\""
            }
    )
    public void testAppendExistingWorksheetWithCellReferenceZInEndColumn(TestSetup setup) throws Exception {
        testExistingWorksheetEditing(setup, false, String.format("%s!%s%d:%s%d", "Existing Worksheet", "ZAB", 4, "ZAE", 7));
    }

    @TestFixture(
            propertyOverrides = {"$.settings.KeyWorksheet.value", "\"Existing Worksheet\""}
    )
    public void testCreateNewWorksheetWithExistingWorksheetOnExistingSpreadsheet(TestSetup setup) throws Exception {
        // Details about new and existing spreadsheets and worksheets
        String existingSpreadsheetName = "Existing Spreadsheet";
        String existingSpreadsheetId = "existingspreadsheet123";
        String existingWorksheetName = "Existing Worksheet";
        int existingWorksheetId = 456;

        // Existing files for spreadsheet list request
        File existingSpreadsheetFile = new File().setId(existingSpreadsheetId).setName(existingSpreadsheetName);
        List<File> existingSpreadsheetFiles = Lists.newArrayList(existingSpreadsheetFile);
        FileList existingFiles = new FileList();
        existingFiles.setFiles(existingSpreadsheetFiles);

        // Existing worksheets and spreadsheet
        Sheet existingWorksheet = new Sheet().setProperties(
                new SheetProperties().setSheetId(existingWorksheetId).setTitle(existingWorksheetName)
        );
        List<Sheet> existingWorksheets = Lists.newArrayList(existingWorksheet);
        Spreadsheet existingSpreadsheet = new Spreadsheet()
                .setSpreadsheetId(existingSpreadsheetId)
                .setSheets(existingWorksheets)
                .setProperties(new SpreadsheetProperties().setTitle(existingSpreadsheetName));

        // Mocks
        Drive.Files.List driveFilesList = mock(Drive.Files.List.class);
        Sheets.Spreadsheets sheetsSpreadsheets = mock(Sheets.Spreadsheets.class);
        Sheets.Spreadsheets.Get sheetsSpreadsheetsGet = mock(Sheets.Spreadsheets.Get.class);
        //

        // Expected calls to mocks
        // Expected calls for retrieval of a FileList from the Google account
        expectGoogleFileListRetrieval(driveFilesList, existingFiles, existingSpreadsheetName);

        // Calls to Sheets mock
        expect(sheets.spreadsheets()).andReturn(sheetsSpreadsheets).anyTimes();
        replay(sheets);

        // Calls to Sheets.Spreadsheets mock
        expect(sheetsSpreadsheets.get(existingSpreadsheetId)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        replay(sheetsSpreadsheets);

        // Calls to Sheets.Spreadsheets.Get mock
        expect(sheetsSpreadsheetsGet.setIncludeGridData(true)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.setRanges(anyObject())).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.execute()).andReturn(existingSpreadsheet).anyTimes();
        replay(sheetsSpreadsheetsGet);

        setup.inject().fieldName("googleAccount").dependency(googleAccount).add();
        setup.test();

        verify(googleAccount, googleConnection, googleDrive, googleDrive.files(), driveFilesList,
                sheets, sheetsSpreadsheets, sheetsSpreadsheetsGet);
    }

    @TestFixture(
            propertyOverrides = {
                    "$.settings.KeyWriteMode.value", "\"Append/edit existing worksheet\"",
                    "$.settings.KeyWorksheet.value", "\"Existing Worksheet\"",
                    "$.settings.KeyCellReference.value", "\"1A\""
            }
    )
    public void testAppendExistingWorksheetWithInvalidCellReference(TestSetup setup) throws Exception {
        try {
            setup.inject().fieldName("googleAccount").dependency(googleAccount).add();
            setup.test();
        } catch (ConfigurationException e) {
            assertEquals("Cell reference is invalid", e.getMessage());
            assertEquals("Cell reference does not follow A1 notation", e.getReason());
            assertEquals("Address the reported issue.", e.getResolution());
        }
    }

    @TestFixture(
            propertyOverrides = {
                    "$.settings.KeyWriteMode.value", "\"Append/edit existing worksheet\"",
                    "$.settings.KeySpreadsheet.value", "\"DNE Spreadsheet\""
            }
    )
    public void testAppendExistingWorksheetSpreadsheetNotFound(TestSetup setup) throws Exception {
        // Details about new and existing spreadsheets and worksheets
        String existingSpreadsheetName = "Existing Spreadsheet";
        String existingSpreadsheetId = "existingSpreadsheet123";

        // Existing files for spreadsheet list request
        File existingSpreadsheetFile = new File().setId(existingSpreadsheetId).setName(existingSpreadsheetName);
        List<File> existingSpreadsheetFiles = Lists.newArrayList(existingSpreadsheetFile);
        FileList existingFiles = new FileList();
        existingFiles.setFiles(existingSpreadsheetFiles);

        // Mocks
        Drive.Files.List driveFilesList = mock(Drive.Files.List.class);
        Sheets.Spreadsheets sheetsSpreadsheets = mock(Sheets.Spreadsheets.class);
        Sheets.Spreadsheets.Get sheetsSpreadsheetsGet = mock(Sheets.Spreadsheets.Get.class);
        //

        // Expected calls to mocks
        // Expected calls for retrieval of a FileList from the Google account
        expectGoogleFileListRetrieval(driveFilesList, existingFiles, "DNE Spreadsheet");

        // Calls to Sheets mock
        expect(sheets.spreadsheets()).andReturn(sheetsSpreadsheets).anyTimes();
        replay(sheets);

        // Calls to Sheets.Spreadsheets mock
        expect(sheetsSpreadsheets.get(existingSpreadsheetId)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        replay(sheetsSpreadsheets);

        // Calls to Sheets.Spreadsheets.Get mock
        expect(sheetsSpreadsheetsGet.setIncludeGridData(true)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.setRanges(anyObject())).andReturn(sheetsSpreadsheetsGet).anyTimes();
        replay(sheetsSpreadsheetsGet);

        setup.inject().fieldName("googleAccount").dependency(googleAccount).add();
        setup.test();

        verify(googleAccount, googleConnection, googleDrive, googleDrive.files(), driveFilesList,
                sheets, sheetsSpreadsheets, sheetsSpreadsheetsGet);
    }

    @TestFixture(
            propertyOverrides = {
                    "$.settings.KeyWriteMode.value", "\"Append/edit existing worksheet\"",
                    "$.settings.KeyWorksheet.value", "\"DNE Worksheet\""
            }
    )
    public void testAppendExistingWorksheetNotFound(TestSetup setup) throws Exception {
        // Details about new and existing spreadsheets and worksheets
        String existingSpreadsheetName = "Existing Spreadsheet";
        String existingSpreadsheetId = "existingSpreadsheet123";
        String existingWorksheetName = "Existing Worksheet";
        int existingWorksheetId = 456;

        // Existing files for spreadsheet list request
        File existingSpreadsheetFile = new File().setId(existingSpreadsheetId).setName(existingSpreadsheetName);
        List<File> existingSpreadsheetFiles = Lists.newArrayList(existingSpreadsheetFile);
        FileList existingFiles = new FileList();
        existingFiles.setFiles(existingSpreadsheetFiles);

        // Existing worksheets and spreadsheet
        Sheet existingWorksheet = new Sheet().setProperties(
                new SheetProperties().setSheetId(existingWorksheetId).setTitle(existingWorksheetName)
        );
        List<Sheet> existingWorksheets = Lists.newArrayList(existingWorksheet);
        Spreadsheet existingSpreadsheet = new Spreadsheet()
                .setSpreadsheetId(existingSpreadsheetId)
                .setSheets(existingWorksheets)
                .setProperties(new SpreadsheetProperties().setTitle(existingSpreadsheetName));

        // Mocks
        Drive.Files.List driveFilesList = mock(Drive.Files.List.class);
        Sheets.Spreadsheets sheetsSpreadsheets = mock(Sheets.Spreadsheets.class);
        Sheets.Spreadsheets.Get sheetsSpreadsheetsGet = mock(Sheets.Spreadsheets.Get.class);
        //

        // Expected calls to mocks
        // Expected calls for retrieval of a FileList from the Google account
        expectGoogleFileListRetrieval(driveFilesList, existingFiles, existingSpreadsheetName);

        // Calls to Sheets mock
        expect(sheets.spreadsheets()).andReturn(sheetsSpreadsheets).anyTimes();
        replay(sheets);

        // Calls to Sheets.Spreadsheets mock
        expect(sheetsSpreadsheets.get(existingSpreadsheetId)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        replay(sheetsSpreadsheets);

        // Calls to Sheets.Spreadsheets.Get mock
        expect(sheetsSpreadsheetsGet.setIncludeGridData(true)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.setRanges(anyObject())).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.execute()).andReturn(existingSpreadsheet).anyTimes();
        replay(sheetsSpreadsheetsGet);

        setup.inject().fieldName("googleAccount").dependency(googleAccount).add();
        setup.test();

        verify(googleAccount, googleConnection, googleDrive, googleDrive.files(), driveFilesList,
                sheets, sheetsSpreadsheets, sheetsSpreadsheetsGet);
    }

    private void testNewWorksheetCreationOnNewSpreadsheet(TestSetup setup, boolean expectTempSheetSwap, String newWorksheetName) throws Exception {
        String newSpreadsheetName = "New Spreadsheet";
        String newSpreadsheetId = "newSpreadsheet123";
        String defaultWorksheetName = "Sheet1";
        int defaultWorksheetId = 0;

        String existingSpreadsheetName = "Existing Spreadsheet";
        String existingSpreadsheetId = "existingSpreadsheet123";
        int newWorksheetId = 789;

        String tempWorksheetName = null;
        int tempWorksheetId = -1;
        if (expectTempSheetSwap) {
            tempWorksheetName = "TempSheet";
            tempWorksheetId = 100;
        }

        // Proposed spreadsheet File (for #create)
        File newSpreadsheetFile = new File()
                .setName(newSpreadsheetName)
                .setMimeType("application/vnd.google-apps.spreadsheet");
        // New spreadsheet File (returned from #create)
        File createdSpreadsheetFile = new File()
                .setName(newSpreadsheetName)
                .setMimeType("application/vnd.google-apps.spreadsheet")
                .setId(newSpreadsheetId)
                .setKind("drive#file");

        // New Spreadsheet and default worksheet
        Sheet defaultWorksheet = new Sheet().setProperties(
                new SheetProperties().setSheetId(defaultWorksheetId).setTitle(defaultWorksheetName)
        );
        List<Sheet> newSpreadsheetWorksheets = Lists.newArrayList(defaultWorksheet);
        Spreadsheet newSpreadsheet = new Spreadsheet()
                .setSpreadsheetId(newSpreadsheetId)
                .setSheets(newSpreadsheetWorksheets)
                .setProperties(new SpreadsheetProperties().setTitle(newSpreadsheetName));

        // Existing Files for spreadsheet list request
        File existingSpreadsheetFile = new File().setId(existingSpreadsheetId).setName(existingSpreadsheetName);
        List<File> existingSpreadsheetFiles = Lists.newArrayList(existingSpreadsheetFile);
        FileList existingFiles = new FileList();
        existingFiles.setFiles(existingSpreadsheetFiles);

        // BatchUpdateSpreadsheetRequest for adding either a temp worksheet (for adding "Sheet1" worksheet)
        // or the specified named new worksheet (no existing sheet name matches) to a new spreadsheet
        GridProperties newWorksheet1GridProperties = new GridProperties().setColumnCount(1).setRowCount(1);
        SheetProperties newWorksheet1Properties = new SheetProperties()
                .setTitle(expectTempSheetSwap ? tempWorksheetName : newWorksheetName)
                .setGridProperties(newWorksheet1GridProperties);
        AddSheetRequest addSheetRequestWorksheet1 = new AddSheetRequest().setProperties(newWorksheet1Properties);
        Request baseRequestWorksheet1 = new Request().setAddSheet(addSheetRequestWorksheet1);
        List<Request> requestsWorksheet1 = Lists.newArrayList(baseRequestWorksheet1);
        BatchUpdateSpreadsheetRequest busRequestCreateWorksheet1 = new BatchUpdateSpreadsheetRequest().setRequests(requestsWorksheet1);

        // BatchUpdateSpreadsheetRequest for delete of default "Sheet1" worksheet
        DeleteSheetRequest deleteSheetRequestWorksheetSheet1 = new DeleteSheetRequest().setSheetId(defaultWorksheetId);
        Request baseRequestDeleteWorksheetSheet1 = new Request().setDeleteSheet(deleteSheetRequestWorksheetSheet1);
        BatchUpdateSpreadsheetRequest busRequestDeleteWorksheetSheet1 = new BatchUpdateSpreadsheetRequest()
                .setRequests(Lists.newArrayList(baseRequestDeleteWorksheetSheet1))
                .setIncludeSpreadsheetInResponse(true);

        BatchUpdateSpreadsheetRequest busRequestCreateWorksheet2 = null;
        BatchUpdateSpreadsheetRequest busRequestDeleteWorksheet1 = null;
        if (expectTempSheetSwap) {
            // BatchUpdateSpreadsheetRequest for creation of new worksheet
            GridProperties newWorksheet2GridProperties = new GridProperties().setColumnCount(1).setRowCount(1);
            SheetProperties newWorksheet2Properties = new SheetProperties().
                    setTitle(newWorksheetName)
                    .setGridProperties(newWorksheet2GridProperties);
            AddSheetRequest addSheetRequestWorksheet2 = new AddSheetRequest().setProperties(newWorksheet2Properties);
            Request baseRequestWorksheet2 = new Request().setAddSheet(addSheetRequestWorksheet2);
            List<Request> requestsWorksheet2 = Lists.newArrayList(baseRequestWorksheet2);
            busRequestCreateWorksheet2 = new BatchUpdateSpreadsheetRequest().setRequests(requestsWorksheet2);

            // BatchUpdateSpreadsheetRequest for delete temp worksheet
            DeleteSheetRequest deleteSheetRequestWorksheet1 = new DeleteSheetRequest().setSheetId(tempWorksheetId);
            Request baseRequestDeleteWorksheet1 = new Request().setDeleteSheet(deleteSheetRequestWorksheet1);
            busRequestDeleteWorksheet1 = new BatchUpdateSpreadsheetRequest()
                    .setRequests(Lists.newArrayList(baseRequestDeleteWorksheet1))
                    .setIncludeSpreadsheetInResponse(true);
        }

        // BatchUpdateSpreadsheetResponse from worksheet 1/temp creation
        AddSheetResponse addSheetResponseWorksheet1 = new AddSheetResponse().setProperties(
                new SheetProperties()
                        .setSheetId(expectTempSheetSwap ? tempWorksheetId : newWorksheetId)
                        .setTitle(expectTempSheetSwap ? tempWorksheetName : newWorksheetName)
        );
        Response baseResponseWorksheet1 = new Response().setAddSheet(addSheetResponseWorksheet1);
        BatchUpdateSpreadsheetResponse busResponseCreateWorksheet1 =
                new BatchUpdateSpreadsheetResponse()
                        .setReplies(Lists.newArrayList(baseResponseWorksheet1));

        Sheet remainingWorksheet = new Sheet().setProperties(
                new SheetProperties()
                        .setSheetId(expectTempSheetSwap ? tempWorksheetId : newWorksheetId)
                        .setTitle(expectTempSheetSwap ? tempWorksheetName : newWorksheetName)
        );
        Spreadsheet newSpreadsheetPostSheet1Deletion = new Spreadsheet()
                .setSpreadsheetId(newSpreadsheetId)
                .setSheets(Lists.newArrayList(remainingWorksheet))
                .setProperties(new SpreadsheetProperties().setTitle(newSpreadsheetName));
        BatchUpdateSpreadsheetResponse busResponseDeleteWorksheetSheet1 =
                new BatchUpdateSpreadsheetResponse()
                        .setUpdatedSpreadsheet(newSpreadsheetPostSheet1Deletion);

        BatchUpdateSpreadsheetResponse busResponseCreateWorksheet2 = null;
        BatchUpdateSpreadsheetResponse busResponseDeleteWorksheet1 = null;
        if (expectTempSheetSwap) {
            // BatchUpdateSpreadsheetResponse from new worksheet creation
            AddSheetResponse addSheetResponse = new AddSheetResponse().setProperties(
                    new SheetProperties().setSheetId(newWorksheetId).setTitle(newWorksheetName)
            );
            Response baseResponse = new Response().setAddSheet(addSheetResponse);
            List<Response> responses = Lists.newArrayList(baseResponse);
            busResponseCreateWorksheet2 =
                    new BatchUpdateSpreadsheetResponse().setReplies(responses);

            // BatchUpdateSpreadsheetResponse from temp worksheet deletion
            Sheet newWorksheet = new Sheet().setProperties(
                    new SheetProperties().setSheetId(newWorksheetId).setTitle(newWorksheetName)
            );
            Spreadsheet newSpreadsheetPostTempSheetDeletion = new Spreadsheet()
                    .setSpreadsheetId(newSpreadsheetId)
                    .setSheets(Lists.newArrayList(newWorksheet))
                    .setProperties(new SpreadsheetProperties().setTitle(newSpreadsheetName));
            busResponseDeleteWorksheet1 = new BatchUpdateSpreadsheetResponse()
                            .setUpdatedSpreadsheet(newSpreadsheetPostTempSheetDeletion);
        }

        String expectedRange = newWorksheetName;

        // Expected value range for append request
        List<Object> row1 = Lists.newArrayList("Column1", "Column2", "Column3", "Column4");
        List<Object> row2 = Lists.newArrayList(BigInteger.valueOf(1), BigInteger.valueOf(2),
                BigInteger.valueOf(3), BigInteger.valueOf(4));
        List<Object> row3 = Lists.newArrayList(BigInteger.valueOf(5), BigInteger.valueOf(6),
                BigInteger.valueOf(7), BigInteger.valueOf(8));
        List<Object> row4 = Lists.newArrayList(BigInteger.valueOf(9), BigInteger.valueOf(10),
                BigInteger.valueOf(11), BigInteger.valueOf(12));
        List<List<Object>> expectedRows = Lists.newArrayList(row1, row2, row3, row4);
        ValueRange expectedValueRange = new ValueRange().setValues(expectedRows).setMajorDimension("ROWS");

        // Expected AppendValuesResponse from append request
        UpdateValuesResponse updateValuesResponse = new UpdateValuesResponse().setUpdatedRows(4);
        AppendValuesResponse appendValuesResponse = new AppendValuesResponse().setUpdates(updateValuesResponse);

        // Mocks
        Drive.Files.List driveFilesList = mock(Drive.Files.List.class);
        Drive.Files.Create driveFilesCreate = mock(Drive.Files.Create.class);
        Sheets.Spreadsheets sheetsSpreadsheets = mock(Sheets.Spreadsheets.class);
        Sheets.Spreadsheets.Get sheetsSpreadsheetsGet = mock(Sheets.Spreadsheets.Get.class);
        Sheets.Spreadsheets.BatchUpdate sheetsSpreadsheetsBatchUpdateCreateWorksheet1 =
                mock(Sheets.Spreadsheets.BatchUpdate.class);
        Sheets.Spreadsheets.BatchUpdate sheetsSpreadsheetsBatchUpdateDeleteWorksheetSheet1 =
                mock(Sheets.Spreadsheets.BatchUpdate.class);
        Sheets.Spreadsheets.BatchUpdate sheetsSpreadsheetsBatchUpdateCreateWorksheet2 = null;
        Sheets.Spreadsheets.BatchUpdate sheetsSpreadsheetsBatchUpdateDeleteWorksheet1 = null;
        if (expectTempSheetSwap) {
            sheetsSpreadsheetsBatchUpdateCreateWorksheet2 = mock(Sheets.Spreadsheets.BatchUpdate.class);
            sheetsSpreadsheetsBatchUpdateDeleteWorksheet1 = mock(Sheets.Spreadsheets.BatchUpdate.class);
        }
        Sheets.Spreadsheets.Values sheetsSpreadsheetsValues = mock(Sheets.Spreadsheets.Values.class);
        Sheets.Spreadsheets.Values.Append sheetsSpreadsheetsValuesAppend =
                mock(Sheets.Spreadsheets.Values.Append.class);
        //

        // Expected calls to mocks
        // Calls to Drive mock
        expect(googleDrive.files()).andReturn(mock(Drive.Files.class)).anyTimes();
        replay(googleDrive);

        // Calls to Drive.Files mock
        expect(googleDrive.files().list()).andReturn(driveFilesList).anyTimes();
        expect(googleDrive.files().create(newSpreadsheetFile)).andReturn(driveFilesCreate).anyTimes();
        replay(googleDrive.files());

        String listQueryFormat = "name='%s' AND mimeType='application/vnd.google-apps.spreadsheet' AND trashed = false";
        String listQuery = String.format(listQueryFormat, newSpreadsheetName);

        // Calls to Drive.Files.List mock
        expect(driveFilesList.setFields("files(id, name)")).andReturn(driveFilesList).anyTimes();
        expect(driveFilesList.setQ(listQuery)).andReturn(driveFilesList).anyTimes();
        expect(driveFilesList.execute()).andReturn(existingFiles).anyTimes();
        replay(driveFilesList);

        // Calls to Drive.Files.Create mock
        expect(driveFilesCreate.execute()).andReturn(createdSpreadsheetFile).anyTimes();
        replay(driveFilesCreate);

        // Calls to Sheets mock
        expect(sheets.spreadsheets()).andReturn(sheetsSpreadsheets).anyTimes();
        replay(sheets);

        // Calls to Sheets.Spreadsheets mock
        expect(sheetsSpreadsheets.get(newSpreadsheetId)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheets.batchUpdate(newSpreadsheetId, busRequestCreateWorksheet1))
                .andReturn(sheetsSpreadsheetsBatchUpdateCreateWorksheet1).anyTimes();
        expect(sheetsSpreadsheets.batchUpdate(newSpreadsheetId, busRequestDeleteWorksheetSheet1))
                .andReturn(sheetsSpreadsheetsBatchUpdateDeleteWorksheetSheet1).anyTimes();
        if (expectTempSheetSwap) {
            expect(sheetsSpreadsheets.batchUpdate(newSpreadsheetId, busRequestCreateWorksheet2))
                    .andReturn(sheetsSpreadsheetsBatchUpdateCreateWorksheet2).anyTimes();
            expect(sheetsSpreadsheets.batchUpdate(newSpreadsheetId, busRequestDeleteWorksheet1))
                    .andReturn(sheetsSpreadsheetsBatchUpdateDeleteWorksheet1).anyTimes();
        }
        expect(sheetsSpreadsheets.values()).andReturn(sheetsSpreadsheetsValues).anyTimes();
        replay(sheetsSpreadsheets);

        // Calls to Sheets.Spreadsheets.Get mock
        expect(sheetsSpreadsheetsGet.execute()).andReturn(newSpreadsheet);
        replay(sheetsSpreadsheetsGet);

        // Calls to Sheets.Spreadsheets.BatchUpdate mocks
        expect(sheetsSpreadsheetsBatchUpdateCreateWorksheet1.execute())
                .andReturn(busResponseCreateWorksheet1).anyTimes();
        expect(sheetsSpreadsheetsBatchUpdateDeleteWorksheetSheet1.execute())
                .andReturn(busResponseDeleteWorksheetSheet1).anyTimes();
        if (expectTempSheetSwap) {
            expect(sheetsSpreadsheetsBatchUpdateCreateWorksheet2.execute())
                    .andReturn(busResponseCreateWorksheet2).anyTimes();
            expect(sheetsSpreadsheetsBatchUpdateDeleteWorksheet1.execute())
                    .andReturn(busResponseDeleteWorksheet1).anyTimes();
        }
        replay(sheetsSpreadsheetsBatchUpdateCreateWorksheet1);
        replay(sheetsSpreadsheetsBatchUpdateDeleteWorksheetSheet1);
        if (expectTempSheetSwap) {
            replay(sheetsSpreadsheetsBatchUpdateCreateWorksheet2);
            replay(sheetsSpreadsheetsBatchUpdateDeleteWorksheet1);
        }

        // Calls to Sheets.Spreadsheets.Values mock
        expect(sheetsSpreadsheetsValues.append(newSpreadsheetId, expectedRange, expectedValueRange)).andReturn(sheetsSpreadsheetsValuesAppend).anyTimes();
        replay(sheetsSpreadsheetsValues);

        // Calls to Sheets.Spreadsheets.Values.Append mock
        expect(sheetsSpreadsheetsValuesAppend.setValueInputOption("RAW")).andReturn(sheetsSpreadsheetsValuesAppend).anyTimes();
        expect(sheetsSpreadsheetsValuesAppend.execute()).andReturn(appendValuesResponse).anyTimes();
        replay(sheetsSpreadsheetsValuesAppend);

        setup.inject().fieldName("googleAccount").dependency(googleAccount).add();
        setup.test();

        verify(googleAccount, googleConnection, googleDrive, googleDrive.files(), driveFilesList,
                sheets, sheetsSpreadsheets, sheetsSpreadsheetsBatchUpdateCreateWorksheet1,
                sheetsSpreadsheetsBatchUpdateDeleteWorksheetSheet1, sheetsSpreadsheetsValues,
                sheetsSpreadsheetsValuesAppend);
        if (expectTempSheetSwap) {
            verify(sheetsSpreadsheetsBatchUpdateCreateWorksheet2, sheetsSpreadsheetsBatchUpdateDeleteWorksheet1);
        }
    }

    private void testNewWorksheetCreationOnExistingSpreadsheet(TestSetup setup, boolean expectTempSheetSwap, String newWorksheetName) throws Exception {
        String existingSpreadsheetName = "Existing Spreadsheet";
        String existingSpreadsheetId = "existingSpreadsheet123";
        String existingWorksheetName = "Existing Worksheet";
        int existingWorksheetId = 456;

        int newWorksheetId = 789;

        String tempWorksheetName = null;
        int tempWorksheetId = -1;
        if (expectTempSheetSwap) {
            tempWorksheetName = "TempSheet";
            tempWorksheetId = 100;
        }

        // Existing files for spreadsheet list request
        File existingSpreadsheetFile = new File().setId(existingSpreadsheetId).setName(existingSpreadsheetName);
        List<File> existingSpreadsheetFiles = Lists.newArrayList(existingSpreadsheetFile);
        FileList existingFiles = new FileList();
        existingFiles.setFiles(existingSpreadsheetFiles);

        // Existing worksheets and spreadsheet
        Sheet existingWorksheet = new Sheet().setProperties(
                new SheetProperties().setSheetId(existingWorksheetId).setTitle(existingWorksheetName)
        );
        List<Sheet> existingWorksheets = Lists.newArrayList(existingWorksheet);
        Spreadsheet existingSpreadsheet = new Spreadsheet()
                .setSpreadsheetId(existingSpreadsheetId)
                .setSheets(existingWorksheets)
                .setProperties(new SpreadsheetProperties().setTitle(existingSpreadsheetName));

        // Create BatchUpdateSpreadsheetRequests
        BatchUpdateSpreadsheetRequest busRequestCreateTempWorksheet = null;
        BatchUpdateSpreadsheetRequest busRequestDeleteExistingWorksheet = null;
        if (expectTempSheetSwap) {
            // BatchUpdateSpreadsheetRequest for temp worksheet
            GridProperties tempWorksheetGridProperties = new GridProperties().setColumnCount(1).setRowCount(1);
            SheetProperties tempWorksheetProperties = new SheetProperties().setTitle(tempWorksheetName)
                    .setGridProperties(tempWorksheetGridProperties);
            AddSheetRequest addSheetRequestTemp = new AddSheetRequest().setProperties(tempWorksheetProperties);
            Request baseRequestTemp = new Request().setAddSheet(addSheetRequestTemp);
            List<Request> requestsTemp = Lists.newArrayList(baseRequestTemp);
            busRequestCreateTempWorksheet = new BatchUpdateSpreadsheetRequest().setRequests(requestsTemp);

            // BatchUpdateSpreadsheetRequest for delete existing worksheet
            DeleteSheetRequest deleteSheetRequestExistingWorksheet = new DeleteSheetRequest()
                    .setSheetId(existingWorksheetId);
            Request baseRequestDeleteExistingWorksheet = new Request()
                    .setDeleteSheet(deleteSheetRequestExistingWorksheet);
            busRequestDeleteExistingWorksheet = new BatchUpdateSpreadsheetRequest()
                    .setRequests(Lists.newArrayList(baseRequestDeleteExistingWorksheet))
                    .setIncludeSpreadsheetInResponse(true);
        }

        // BatchUpdateSpreadsheetRequest for new worksheet
        GridProperties newWorksheetGridProperties = new GridProperties().setColumnCount(1).setRowCount(1);
        SheetProperties newWorksheetProperties = new SheetProperties().setTitle(newWorksheetName)
                .setGridProperties(newWorksheetGridProperties);
        AddSheetRequest addSheetRequest = new AddSheetRequest().setProperties(newWorksheetProperties);
        Request baseRequest = new Request().setAddSheet(addSheetRequest);
        List<Request> requests = Lists.newArrayList(baseRequest);
        BatchUpdateSpreadsheetRequest busRequestCreateNewWorksheet =
                new BatchUpdateSpreadsheetRequest().setRequests(requests);

        BatchUpdateSpreadsheetRequest busRequestDeleteTempWorksheet = null;
        if (expectTempSheetSwap) {
            // BatchUpdateSpreadsheetRequest for delete temp worksheet
            DeleteSheetRequest deleteSheetRequestTempWorksheet = new DeleteSheetRequest()
                    .setSheetId(tempWorksheetId);
            Request baseRequestDeleteTempWorksheet = new Request()
                    .setDeleteSheet(deleteSheetRequestTempWorksheet);
            busRequestDeleteTempWorksheet = new BatchUpdateSpreadsheetRequest()
                    .setRequests(Lists.newArrayList(baseRequestDeleteTempWorksheet))
                    .setIncludeSpreadsheetInResponse(true);
        }

        // Create BatchUpdateSpreadsheetResponses
        BatchUpdateSpreadsheetResponse busResponseCreateTempWorksheet = null;
        BatchUpdateSpreadsheetResponse busResponseDeleteExistingWorksheet = null;
        if (expectTempSheetSwap) {
            // BatchUpdateSpreadsheetResponse from temp worksheet creation
            AddSheetResponse addSheetResponseCreateTemp = new AddSheetResponse().setProperties(
                    new SheetProperties().setSheetId(tempWorksheetId).setTitle(tempWorksheetName)
            );
            Response baseResponseCreateTemp = new Response().setAddSheet(addSheetResponseCreateTemp);
            busResponseCreateTempWorksheet =
                    new BatchUpdateSpreadsheetResponse()
                            .setReplies(Lists.newArrayList(baseResponseCreateTemp));

            // BatchUpdateSpreadsheetResponse from existing worksheet deletion
            Sheet tempWorksheet = new Sheet().setProperties(
                    new SheetProperties().setSheetId(tempWorksheetId).setTitle(tempWorksheetName)
            );
            Spreadsheet existingSpreadsheetPostOldSheetDeletion = new Spreadsheet()
                    .setSpreadsheetId(existingSpreadsheetId)
                    .setSheets(Lists.newArrayList(tempWorksheet))
                    .setProperties(new SpreadsheetProperties().setTitle(existingSpreadsheetName));
            busResponseDeleteExistingWorksheet =
                    new BatchUpdateSpreadsheetResponse()
                            .setUpdatedSpreadsheet(existingSpreadsheetPostOldSheetDeletion);
        }

        // BatchUpdateSpreadsheetResponse from new worksheet creation
        AddSheetResponse addSheetResponse = new AddSheetResponse().setProperties(
                new SheetProperties().setSheetId(newWorksheetId).setTitle(newWorksheetName)
        );
        Response baseResponse = new Response().setAddSheet(addSheetResponse);
        List<Response> responses = Lists.newArrayList(baseResponse);
        BatchUpdateSpreadsheetResponse busResponseCreateNewWorksheet =
                new BatchUpdateSpreadsheetResponse().setReplies(responses);

        BatchUpdateSpreadsheetResponse busResponseDeleteTempWorksheet = null;
        if (expectTempSheetSwap) {
            // BatchUpdateSpreadsheetResponse from temp worksheet deletion
            Sheet newWorksheet = new Sheet().setProperties(
                    new SheetProperties().setSheetId(newWorksheetId).setTitle(newWorksheetName)
            );
            Spreadsheet existingSpreadsheetPostTempSheetDeletion = new Spreadsheet()
                    .setSpreadsheetId(existingSpreadsheetId)
                    .setSheets(Lists.newArrayList(newWorksheet))
                    .setProperties(new SpreadsheetProperties().setTitle(existingSpreadsheetName));
            busResponseDeleteTempWorksheet =
                    new BatchUpdateSpreadsheetResponse()
                            .setUpdatedSpreadsheet(existingSpreadsheetPostTempSheetDeletion);
        }

        String expectedRange = newWorksheetName;

        // Expected value range for append request
        List<Object> row1 = Lists.newArrayList("Column1", "Column2", "Column3", "Column4");
        List<Object> row2 = Lists.newArrayList(BigInteger.valueOf(1), BigInteger.valueOf(2),
                BigInteger.valueOf(3), BigInteger.valueOf(4));
        List<Object> row3 = Lists.newArrayList(BigInteger.valueOf(5), BigInteger.valueOf(6),
                BigInteger.valueOf(7), BigInteger.valueOf(8));
        List<Object> row4 = Lists.newArrayList(BigInteger.valueOf(9), BigInteger.valueOf(10),
                BigInteger.valueOf(11), BigInteger.valueOf(12));
        List<List<Object>> expectedRows = Lists.newArrayList(row1, row2, row3, row4);
        ValueRange expectedValueRange = new ValueRange().setValues(expectedRows).setMajorDimension("ROWS");

        // Expected AppendValuesResponse from append request
        UpdateValuesResponse updateValuesResponse = new UpdateValuesResponse().setUpdatedRows(4);
        AppendValuesResponse appendValuesResponse = new AppendValuesResponse().setUpdates(updateValuesResponse);

        // Mocks
        Drive.Files.List driveFilesList = mock(Drive.Files.List.class);
        Sheets.Spreadsheets sheetsSpreadsheets = mock(Sheets.Spreadsheets.class);
        Sheets.Spreadsheets.Get sheetsSpreadsheetsGet = mock(Sheets.Spreadsheets.Get.class);
        Sheets.Spreadsheets.BatchUpdate sheetsSpreadsheetsBatchUpdateCreateNewWorksheet =
                mock(Sheets.Spreadsheets.BatchUpdate.class);
        Sheets.Spreadsheets.BatchUpdate sheetsSpreadsheetsBatchUpdateCreateTempWorksheet = null;
        Sheets.Spreadsheets.BatchUpdate sheetsSpreadsheetsBatchUpdateDeleteExistingWorksheet = null;
        Sheets.Spreadsheets.BatchUpdate sheetsSpreadsheetsBatchUpdateDeleteTempWorksheet = null;
        if (expectTempSheetSwap) {
            sheetsSpreadsheetsBatchUpdateCreateTempWorksheet = mock(Sheets.Spreadsheets.BatchUpdate.class); //
            sheetsSpreadsheetsBatchUpdateDeleteExistingWorksheet = mock(Sheets.Spreadsheets.BatchUpdate.class); //
            sheetsSpreadsheetsBatchUpdateDeleteTempWorksheet = mock(Sheets.Spreadsheets.BatchUpdate.class); //
        }
        Sheets.Spreadsheets.Values sheetsSpreadsheetsValues = mock(Sheets.Spreadsheets.Values.class);
        Sheets.Spreadsheets.Values.Append sheetsSpreadsheetsValuesAppend = mock(Sheets.Spreadsheets.Values.Append.class);
        //

        // Expected calls to mocks
        // Expected calls for retrieval of a FileList from the Google account
        expectGoogleFileListRetrieval(driveFilesList, existingFiles, existingSpreadsheetName);

        // Calls to Sheets mock
        expect(sheets.spreadsheets()).andReturn(sheetsSpreadsheets).anyTimes();
        replay(sheets);

        // Calls to Sheets.Spreadsheets mock
        expect(sheetsSpreadsheets.get(existingSpreadsheetId)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheets.batchUpdate(existingSpreadsheetId, busRequestCreateNewWorksheet))
                .andReturn(sheetsSpreadsheetsBatchUpdateCreateNewWorksheet).anyTimes();
        if (expectTempSheetSwap) {
            expect(sheetsSpreadsheets.batchUpdate(existingSpreadsheetId, busRequestCreateTempWorksheet))
                    .andReturn(sheetsSpreadsheetsBatchUpdateCreateTempWorksheet).anyTimes();
            expect(sheetsSpreadsheets.batchUpdate(existingSpreadsheetId, busRequestDeleteExistingWorksheet))
                    .andReturn(sheetsSpreadsheetsBatchUpdateDeleteExistingWorksheet).anyTimes();
            expect(sheetsSpreadsheets.batchUpdate(existingSpreadsheetId, busRequestDeleteTempWorksheet))
                    .andReturn(sheetsSpreadsheetsBatchUpdateDeleteTempWorksheet).anyTimes();
        }
        expect(sheetsSpreadsheets.values()).andReturn(sheetsSpreadsheetsValues).anyTimes();
        replay(sheetsSpreadsheets);

        // Calls to Sheets.Spreadsheets.Get mock
        expect(sheetsSpreadsheetsGet.setIncludeGridData(true)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.setRanges(anyObject())).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.execute()).andReturn(existingSpreadsheet).anyTimes();
        replay(sheetsSpreadsheetsGet);

        // Calls to Sheets.Spreadsheets.BatchUpdate mocks
        expect(sheetsSpreadsheetsBatchUpdateCreateNewWorksheet.execute())
                .andReturn(busResponseCreateNewWorksheet).anyTimes();
        replay(sheetsSpreadsheetsBatchUpdateCreateNewWorksheet);
        if (expectTempSheetSwap) {
            expect(sheetsSpreadsheetsBatchUpdateCreateTempWorksheet.execute())
                    .andReturn(busResponseCreateTempWorksheet).anyTimes();
            expect(sheetsSpreadsheetsBatchUpdateDeleteExistingWorksheet.execute())
                    .andReturn(busResponseDeleteExistingWorksheet).anyTimes();
            expect(sheetsSpreadsheetsBatchUpdateDeleteTempWorksheet.execute())
                    .andReturn(busResponseDeleteTempWorksheet).anyTimes();
            replay(sheetsSpreadsheetsBatchUpdateCreateTempWorksheet);
            replay(sheetsSpreadsheetsBatchUpdateDeleteExistingWorksheet);
            replay(sheetsSpreadsheetsBatchUpdateDeleteTempWorksheet);
        }

        // Calls to Sheets.Spreadsheets.Values mock
        expect(sheetsSpreadsheetsValues.append(existingSpreadsheetId, expectedRange, expectedValueRange))
                .andReturn(sheetsSpreadsheetsValuesAppend).anyTimes();
        replay(sheetsSpreadsheetsValues);

        // Calls to Sheets.Spreadsheets.Values.Append mock
        expect(sheetsSpreadsheetsValuesAppend.setValueInputOption("RAW"))
                .andReturn(sheetsSpreadsheetsValuesAppend).anyTimes();
        expect(sheetsSpreadsheetsValuesAppend.execute()).andReturn(appendValuesResponse).anyTimes();
        replay(sheetsSpreadsheetsValuesAppend);

        setup.inject().fieldName("googleAccount").dependency(googleAccount).add();
        setup.test();

        verify(googleAccount, googleConnection, googleDrive, googleDrive.files(), driveFilesList,
                sheets, sheetsSpreadsheets, sheetsSpreadsheetsGet, sheetsSpreadsheetsBatchUpdateCreateNewWorksheet,
                sheetsSpreadsheetsValues, sheetsSpreadsheetsValuesAppend);
        if (expectTempSheetSwap) {
            verify(sheetsSpreadsheetsBatchUpdateCreateTempWorksheet, sheetsSpreadsheetsBatchUpdateDeleteExistingWorksheet, sheetsSpreadsheetsBatchUpdateDeleteTempWorksheet);
        }
    }

    private void testExistingWorksheetEditing(TestSetup setup, boolean isCellReferenceBlank, String expectedRange) throws Exception {
        // Details about new and existing spreadsheets and worksheets
        String existingSpreadsheetName = "Existing Spreadsheet";
        String existingSpreadsheetId = "existingSpreadsheet123";
        String existingWorksheetName = "Existing Worksheet";
        int existingWorksheetId = 456;

        // Existing files for spreadsheet list request
        File existingSpreadsheetFile = new File().setId(existingSpreadsheetId)
                .setName(existingSpreadsheetName);
        List<File> existingSpreadsheetFiles = Lists.newArrayList(existingSpreadsheetFile);
        FileList existingFiles = new FileList();
        existingFiles.setFiles(existingSpreadsheetFiles);

        // Existing worksheets and spreadsheet
        Sheet existingWorksheet = new Sheet().setProperties(
                new SheetProperties().setSheetId(existingWorksheetId).setTitle(existingWorksheetName)
        );
        List<Sheet> existingWorksheets = Lists.newArrayList(existingWorksheet);
        Spreadsheet existingSpreadsheet = new Spreadsheet()
                .setSpreadsheetId(existingSpreadsheetId)
                .setSheets(existingWorksheets)
                .setProperties(new SpreadsheetProperties().setTitle(existingSpreadsheetName));

        // Expected value range for append request
        List<Object> row1 = Lists.newArrayList("Column1", "Column2", "Column3", "Column4");
        List<Object> row2 = Lists.newArrayList(BigInteger.valueOf(1), BigInteger.valueOf(2),
                BigInteger.valueOf(3), BigInteger.valueOf(4));
        List<Object> row3 = Lists.newArrayList(BigInteger.valueOf(5), BigInteger.valueOf(6),
                BigInteger.valueOf(7), BigInteger.valueOf(8));
        List<Object> row4 = Lists.newArrayList(BigInteger.valueOf(9), BigInteger.valueOf(10),
                BigInteger.valueOf(11), BigInteger.valueOf(12));
        List<List<Object>> expectedRows = Lists.newArrayList(row1, row2, row3, row4);
        ValueRange expectedValueRange = new ValueRange().setValues(expectedRows).setMajorDimension("ROWS");

        // Expected AppendValuesResponse from append request
        UpdateValuesResponse updateValuesResponse = new UpdateValuesResponse().setUpdatedRows(4);
        AppendValuesResponse appendValuesResponse = null;
        if (isCellReferenceBlank) {
            appendValuesResponse = new AppendValuesResponse().setUpdates(updateValuesResponse);
        }

        // Mocks
        Drive.Files.List driveFilesList = mock(Drive.Files.List.class);
        Sheets.Spreadsheets sheetsSpreadsheets = mock(Sheets.Spreadsheets.class);
        Sheets.Spreadsheets.Get sheetsSpreadsheetsGet = mock(Sheets.Spreadsheets.Get.class);
        Sheets.Spreadsheets.Values sheetsSpreadsheetsValues = mock(Sheets.Spreadsheets.Values.class);
        Sheets.Spreadsheets.Values.Update sheetsSpreadsheetsValuesUpdate = mock(Sheets.Spreadsheets.Values.Update.class);
        Sheets.Spreadsheets.Values.Append sheetsSpreadsheetsValuesAppend = mock(Sheets.Spreadsheets.Values.Append.class);
        //

        // Expected calls to mocks
        // Expected calls for retrieval of a FileList from the Google account
        expectGoogleFileListRetrieval(driveFilesList, existingFiles, existingSpreadsheetName);

        // Calls to Sheets mock
        expect(sheets.spreadsheets()).andReturn(sheetsSpreadsheets).anyTimes();
        replay(sheets);

        // Calls to Sheets.Spreadsheets mock
        expect(sheetsSpreadsheets.get(existingSpreadsheetId)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheets.values()).andReturn(sheetsSpreadsheetsValues).anyTimes();
        replay(sheetsSpreadsheets);

        // Calls to Sheets.Spreadsheets.Get mock
        expect(sheetsSpreadsheetsGet.setIncludeGridData(true)).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.setRanges(anyObject())).andReturn(sheetsSpreadsheetsGet).anyTimes();
        expect(sheetsSpreadsheetsGet.execute()).andReturn(existingSpreadsheet).anyTimes();
        replay(sheetsSpreadsheetsGet);

        // Calls to Sheets.Spreadsheets.Values mocks
        if (isCellReferenceBlank) {
            // Calls to Sheets.Spreadsheets.Values mock
            expect(sheetsSpreadsheetsValues.append(existingSpreadsheetId, expectedRange, expectedValueRange))
                    .andReturn(sheetsSpreadsheetsValuesAppend).anyTimes(); // during write batch
            replay(sheetsSpreadsheetsValues);

            // Calls to Sheets.Spreadsheets.Values.Append mock
            expect(sheetsSpreadsheetsValuesAppend.setValueInputOption("RAW")).andReturn(sheetsSpreadsheetsValuesAppend).anyTimes();
            expect(sheetsSpreadsheetsValuesAppend.execute()).andReturn(appendValuesResponse).anyTimes();
            replay(sheetsSpreadsheetsValuesAppend);
        } else {
            // Calls to Sheets.Spreadsheets.Values mock
            expect(sheetsSpreadsheetsValues.update(existingSpreadsheetId, expectedRange, expectedValueRange)).andReturn(sheetsSpreadsheetsValuesUpdate).anyTimes();
            replay(sheetsSpreadsheetsValues);

            // Calls to Sheets.Spreadsheets.Values.Update mock
            expect(sheetsSpreadsheetsValuesUpdate.setValueInputOption("RAW")).andReturn(sheetsSpreadsheetsValuesUpdate).anyTimes();
            expect(sheetsSpreadsheetsValuesUpdate.execute()).andReturn(updateValuesResponse);
            replay(sheetsSpreadsheetsValuesUpdate);
        }

        setup.inject().fieldName("googleAccount").dependency(googleAccount).add();
        setup.test();

        verify(googleAccount, googleConnection, googleDrive, googleDrive.files(), driveFilesList, sheets, sheetsSpreadsheets, sheetsSpreadsheetsGet, sheetsSpreadsheetsValues);
        if (isCellReferenceBlank) {
            verify(sheetsSpreadsheetsValuesAppend);
        } else {
            verify(sheetsSpreadsheetsValuesUpdate);
        }
    }

    private void expectGoogleFileListRetrieval(Drive.Files.List mockDriveFilesList, FileList existingFilesList, String requestedSpreadsheetName) throws Exception {
        expect(googleDrive.files()).andReturn(mock(Drive.Files.class)).anyTimes();
        replay(googleDrive);

        expect(googleDrive.files().list()).andReturn(mockDriveFilesList).anyTimes();
        replay(googleDrive.files());

        String listQueryFormat = "name='%s' AND mimeType='application/vnd.google-apps.spreadsheet' AND trashed = false";
        String listQuery = String.format(listQueryFormat, requestedSpreadsheetName);

        expect(mockDriveFilesList.setFields("files(id, name)")).andReturn(mockDriveFilesList).anyTimes();
        expect(mockDriveFilesList.setQ(listQuery)).andReturn(mockDriveFilesList).anyTimes();
        expect(mockDriveFilesList.execute()).andReturn(existingFilesList).anyTimes();
        replay(mockDriveFilesList);
    }

    @Test
    public void testComputeColumnRangeOneLetterCode() {
        testComputeColumnRange("E", 3, "G");
    }

    @Test
    public void testComputeColumnRangeThreeLetterCode() {
        testComputeColumnRange("ABC", 3, "ABE");
    }

    @Test
    public void testComputeColumnRangeOneToTwoLetterCodes() {
        testComputeColumnRange("Z", 3, "AB");
    }

    @Test
    public void testComputeColumnRangeTwoToThreeLetterCodes() {
        testComputeColumnRange("ZZ", 3, "AAB");
    }

    @Test
    public void testComputeColumnRangeEndColumnContainsA() {
        testComputeColumnRange("DY", 3, "EA");
    }

    @Test
    public void testComputeColumnRangeEndColumnContainsZ() {
        testComputeColumnRange("AYZ", 3, "AZB");
    }

    @Test
    public void testComputeColumnRangeEndColumnExceedsMaxColumn() {
        SnapDataException e = assertThrows("Expected SnapDataException", SnapDataException.class, () -> {
            testComputeColumnRange("ZZZ", 2, "Not possible");
        });

        assertEquals("Invalid range to write 2 columns starting at cell ZZZ1", e.getMessage());
        assertEquals("Range end column exceeds max column ZZZ", e.getReason());
        assertEquals("Reduce the number of columns in the written data or adjust " +
                "the starting cell reference to fit all columns", e.getResolution());
    }

    private void testComputeColumnRange(String startColumn, int columnCount, String expectedEndColumn) {
        WorksheetWriter worksheetWriter = new WorksheetWriter();
        worksheetWriter.cellReference = startColumn + 1;
        String expectedRange = String.format("%%s!%s%%d:%s%%d", startColumn, expectedEndColumn);

        String computedRange = worksheetWriter.computeColumnRange(startColumn, columnCount);

        assertEquals(expectedRange, computedRange);
    }

    @TestFixture(snap = MockWorksheetWriter.class,
            account = MockOAuth2Account.class,
            input = "data/test_writer_data.json",
            outputs = "out",
            errors = "err",
            expectedOutputPath = "data/writer",
            expectedErrorPath = "data/writer",
            properties = "data/writer_properties_with_spreadsheetid.json")
    public void testBatchWriteWithSpreadsheetId(TestResult result) {
    }

    @TestFixture(snap = MockWorksheetWriter.class,
            account = MockOAuth2Account.class,
            outputs = "out",
            errors = "err",
            expectedOutputPath = "data/writer",
            expectedErrorPath = "data/writer",
            input = "data/test_writer_data1.json",
            properties = "data/writer_properties.json")
    public void testBatchWriteWithSpreadsheetName(TestResult result) {
    }

    @TestFixture(snap = MockWorksheetWriter.class,
            account = MockOAuth2Account.class,
            input = "data/test_writer_data.json",
            outputs = "out",
            errors = "err",
            expectedOutputPath = "data/writer",
            expectedErrorPath = "data/writer",
            properties = "data/writer_properties_create_spreadsheet.json")
    public void testBatchWriteWithMultipleFilesWithSameName(TestResult result) {
    }

    @TestFixture(snap = MockWorksheetWriter.class,
            account = MockOAuth2Account.class,
            input = "data/test_writer_data.json",
            outputs = "out",
            errors = "err",
            expectedOutputPath = "data/writer",
            expectedErrorPath = "data/writer",
            properties = "data/writer_properties_with_spreadsheetnameandid.json")
    public void testBatchWriteWithSpreadsheetNameAndId(TestResult result) {
    }

}
