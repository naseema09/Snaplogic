/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;

/**
 * Mock Account.
 *
 * @author smudassir
 */
public class MockOAuth2Account extends GoogleSpreadsheetOAuth2Account {

    @Override
    public ConnectionResult connect() {
        try {
            Credential credential = new GoogleCredential.Builder().build();
            credential.setAccessToken("mocktoken");
            return new MockConnectionResult(new MockDrive(GoogleNetHttpTransport.newTrustedTransport(),
                            JacksonFactory.getDefaultInstance(), credential));
        } catch (Exception e1) {
            return  null;
        }
    }
}
