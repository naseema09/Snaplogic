/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2019, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */
package com.snaplogic.snaps.google.spreadsheet.writer;

import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.common.collect.ImmutableList;
import com.snaplogic.snaps.google.spreadsheet.WorksheetWriter;

import java.io.IOException;
import java.util.List;

/**
 * Mock class for unit test testBatchWriteCreateSpreadsheet()
 *
 * @since Apr, 2019
 */
public class MockWorksheetWriterCreateSpreadsheet extends WorksheetWriter {

    @Override
    protected String getId(Drive drive, String title, boolean nullIfNotExists) {
        return null;
    }

    @Override
    protected File createGoogleDriveFile(File file) throws Throwable {
        file.setId("dummyAbc");
        return  file;
    }

    @Override
    protected List<Sheet> getWorksheets(Sheets sheets, String spreadsheetId) throws IOException {
        return ImmutableList.of();
    }

    @Override
    protected Integer createSheet(String sheetTitle) {
        return 123;
    }

    @Override
    protected void writeBatch() {
    }
}