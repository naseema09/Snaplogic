/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */

package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import com.snaplogic.snap.api.SnapDataException;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;

import static com.snaplogic.snaps.google.spreadsheet.SpreadsheetsBase.FILES_ID_NAME;

/**
 * Mocks Google Drive service.
 *
 * @author smudassir
 */
public class MockDrive extends Drive {
    private boolean isRetry = true;

    /**
     * Mocks Drive.Files
     */
    private class MockFiles extends Files {
        /**
         * Mocks Files.Create (as of v3; previously known as Insert)
         */
        private class MockCreate extends Create {
            protected MockCreate(File p2) {
                super(p2);
            }

            @Override
            public File execute() {
                return null;
            }
        }

        @Override
        public Create create(File file) {
            return new MockCreate(file);
        }

        /**
         * Mocks Files.List
         */
        private class MockList extends List {
            protected MockList() {
                super();
            }

            @Override
            public List setFields(String s) {
                if (!s.equals(FILES_ID_NAME)) {
                    throw new SnapDataException("Unexpected fields");
                }
                return super.setFields(s);
            }

            @Override
            public List setQ(String s) {
                String nameInQuery = StringUtils.substringBetween(s, "name='", "' AND");
                if (StringUtils.countMatches(nameInQuery, "'")
                        != StringUtils.countMatches(nameInQuery, "\\'")) {
                    throw new SnapDataException("Quotes not escaped");
                }
                return super.setQ(s);
            }

            @Override
            public FileList execute() {
                if (isRetry) {
                    isRetry = false;
                    throw new SnapDataException("Internal server error");
                } else {
                    isRetry = true;
                    java.util.List<File> files = new ArrayList<>(1);
                    files.add(new File().setName("dummy spreadsheet").setId("xyz123"));
                    files.add(new File().setName(" space spreadsheet").setId("space123"));
                    files.add(new File().setName("Some 'quoted' text").setId("someid"));
                    files.add(new File().setName("spreadsheetxyz").setId("spreadsheetidxyz"));
                    files.add(new File().setName("spreadsheetxyz").setId("spreadsheetid2"));
                    return new FileList().setFiles(files);
                }
            }
        }

        @Override
        public List list() {
            return new MockList();
        }
    }

    public MockDrive(HttpTransport httpTransport, JsonFactory jsonFactory,
                     HttpRequestInitializer httpRequestInitializer) {
        super(httpTransport, jsonFactory, httpRequestInitializer);
    }

    @Override
    public Files files() {
        return new MockFiles();
    }
}