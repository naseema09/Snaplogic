/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2018, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */
package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.Spreadsheet;
import com.google.common.collect.ImmutableList;
import com.snaplogic.snap.api.SnapDataException;

import java.io.IOException;

import static com.snaplogic.snaps.google.spreadsheet.GoogleSpreadsheetOAuth2Account.HTTP_TRANSPORT;
import static com.snaplogic.snaps.google.spreadsheet.GoogleSpreadsheetOAuth2Account.JACKSON_FACTORY;

/**
 * Mock class for ConnectionResult
 *
 * @since Aug, 2018
 */
public class MockConnectionResult extends ConnectionResult {
    private boolean isRetry = true;

    /**
     * one-arg constructor
     *
     * @param googleDrive
     */
    public MockConnectionResult(Drive googleDrive) {
        super(googleDrive);
    }

    @Override
    public Sheets getSheets() {
        HttpRequestInitializer httpRequestInitializer = new HttpRequestInitializer() {
            @Override
            public void initialize(final HttpRequest httpRequest) throws IOException {
                // No-Op
            }
        };
        return new MockSheets(HTTP_TRANSPORT, JACKSON_FACTORY, httpRequestInitializer);
    }

    public class MockSheets extends Sheets {

        public MockSheets(HttpTransport httpTransport, JsonFactory jsonFactory,
                HttpRequestInitializer httpRequestInitializer) {
            super(httpTransport, jsonFactory, httpRequestInitializer);
        }

        public class MockSpreadsheets extends Spreadsheets {

            public class MockGet extends Get {

                protected MockGet(String id) {
                    super(id);
                }

                @Override
                public Spreadsheet execute() {
                    if (isRetry) {
                        isRetry = false;
                        throw new SnapDataException("Internal server error");
                    } else {
                        isRetry = true;
                        return new Spreadsheet().setSheets(ImmutableList.of());
                    }
                }
            }

            @Override
            public Get get(String id) {
                return new MockGet(id);
            }
        }

        @Override
        public Spreadsheets spreadsheets() {
            return new MockSpreadsheets();
        }
    }
}
