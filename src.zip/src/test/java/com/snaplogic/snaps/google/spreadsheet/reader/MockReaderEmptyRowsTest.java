/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2019, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */
package com.snaplogic.snaps.google.spreadsheet.reader;

import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.common.collect.Lists;
import com.snaplogic.snaps.google.spreadsheet.WorksheetReader;

import java.util.List;

/**
 * For testing {@link WorksheetReader} to test if empty rows do not produce any output document
 */
public class MockReaderEmptyRowsTest extends WorksheetReader {

    @Override
    protected List<ValueRange> readWorksheetNoGridInfo(String spreadsheetId,
            String worksheetName) {
        String data = "Data%s%s";
        String field = "Field%s";
        // spreadsheet with
        List<Object> headerRow = Lists.newArrayList();
        List<Object> row1 = Lists.newArrayList();
        List<Object> row2 = Lists.newArrayList();
        List<Object> row3 = Lists.newArrayList();
        List<Object> row4 = Lists.newArrayList();
        for (int i = 1; i <= 2; i++) {
            headerRow.add(String.format(field, i));
            row1.add(String.format(data, "1", i));
            row2.add("");
            row3.add(String.format(data, "3", i));
            row4.add("");
        }
        List<List<Object>> range1 = Lists.newArrayList();
        range1.add(headerRow);
        range1.add(row1);
        List<List<Object>> range2 = Lists.newArrayList();
        range2.add(row2);
        List<List<Object>> range3 = Lists.newArrayList();
        range3.add(row3);
        List<List<Object>> range4 = Lists.newArrayList();
        range4.add(row4);
        ValueRange valRange1 = new ValueRange();
        valRange1.setValues(range1);
        ValueRange valRange2 = new ValueRange();
        valRange2.setValues(range2);
        ValueRange valRange3 = new ValueRange();
        valRange3.setValues(range3);
        ValueRange valRange4 = new ValueRange();
        valRange4.setValues(range4);
        List<ValueRange> valueRangeList = Lists.newArrayList(valRange1, valRange2, valRange3,
                valRange4);
        return valueRangeList;
    }
}
