/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2019, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */
package com.snaplogic.snaps.google.spreadsheet.reader;

import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.GridProperties;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.snaplogic.snaps.google.spreadsheet.WorksheetReader;

import java.io.IOException;
import java.util.List;

import static org.apache.xmlbeans.impl.jam.xml.JamXmlElements.FIELD;

/**
 * Mock WorksheetReader class to test retry
 */
public class MockReaderRetry extends WorksheetReader {
    public int retries = 0;

    @Override
    protected List<Sheet> getWorksheets(Sheets sheets, String spreadsheetId) throws IOException {
        SheetProperties sheetProperties = new SheetProperties()
                .setTitle("dummy worksheet")
                .setGridProperties(new GridProperties().setRowCount(1));
        Sheet sheet = new Sheet().setProperties(sheetProperties);
        return ImmutableList.of(sheet);
    }

    @Override
    protected List<ValueRange> readWorksheetNoGridInfo(String spreadsheetId, List<String> ranges)
            throws IOException {
        if (retries == 0) {
            retries++;
            throw new IOException("First attempt to read worksheet failed");
        }
        String COL_DATA = "Data%s%s";
        // spreadsheet with header and 3 rows with 2 empty rows in between
        List<Object> headerRow = Lists.newArrayList();
        List<Object> row1 = Lists.newArrayList();
        List<Object> row2 = Lists.newArrayList();
        List<Object> row3 = Lists.newArrayList();
        for (int i = 1; i <= 5; i++) {
            headerRow.add(String.format(FIELD, i));
            row1.add(String.format(COL_DATA, "1", i));
            row2.add(String.format(COL_DATA, "2", i));
            row3.add(i); // Number data row
        }
        List<List<Object>> range1 = Lists.newArrayList();
        range1.add(headerRow);
        range1.add(row1);
        List<List<Object>> range3 = Lists.newArrayList();
        range3.add(row2);
        range3.add(row3);
        ValueRange valRange1 = new ValueRange();
        valRange1.setValues(range1);
        // Case where a batch of rows are empty in between rows with data
        ValueRange valRange2 = new ValueRange();
        valRange2.setValues(null);
        ValueRange valRange3 = new ValueRange();
        valRange3.setValues(range3);
        List<ValueRange> valueRangeList = Lists.newArrayList(valRange1, valRange2, valRange3);
        return valueRangeList;
    }

}
