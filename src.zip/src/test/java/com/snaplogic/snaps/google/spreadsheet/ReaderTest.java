/*
 * SnapLogic - Data Integration
 *
 * Copyright (C) 2015 - 2020, SnapLogic, Inc.  All rights reserved.
 *
 * This program is licensed under the terms of
 * the SnapLogic Commercial Subscription agreement.
 *
 * "SnapLogic" is a trademark of SnapLogic, Inc.
 */
package com.snaplogic.snaps.google.spreadsheet;

import com.google.api.services.drive.Drive;
import com.google.api.services.sheets.v4.model.CellData;
import com.google.api.services.sheets.v4.model.CellFormat;
import com.google.api.services.sheets.v4.model.ErrorValue;
import com.google.api.services.sheets.v4.model.ExtendedValue;
import com.google.api.services.sheets.v4.model.GridData;
import com.google.api.services.sheets.v4.model.NumberFormat;
import com.google.api.services.sheets.v4.model.RowData;
import com.google.api.services.sheets.v4.model.ValueRange;
import com.google.common.collect.Lists;
import com.snaplogic.snap.test.harness.SnapTestRunner;
import com.snaplogic.snap.test.harness.TestFixture;
import com.snaplogic.snap.test.harness.TestResult;
import com.snaplogic.snaps.google.spreadsheet.reader.MockReaderEmptyRowsTest;
import com.snaplogic.snaps.google.spreadsheet.reader.MockReaderRetry;

import org.junit.runner.RunWith;

import java.time.LocalDate;
import java.util.List;

import static com.snaplogic.snaps.google.spreadsheet.Messages.FIELD;

import static org.junit.Assert.assertEquals;

/**
 * Tests Reader Snap.
 *
 * @author smudassir
 */
@RunWith(SnapTestRunner.class)
@TestFixture(account = MockOAuth2Account.class,
        outputs = "out",
        errors = "err",
        properties = "data/read_reader_properties.json",
        expectedOutputPath = "data/reader",
        expectedErrorPath = "data/reader")
public class ReaderTest {
    /**
     * For testing {@link WorksheetReader} to ensure output column types are intact
     */
    public static final class MockReaderForDataTypesTest extends WorksheetReader {
        @Override
        protected List<GridData> readWorksheet(String spreadsheetId, String range) {
            List<CellData> headerCols = Lists.newArrayList();
            CellData headerCol = new CellData();
            headerCol.setFormattedValue("boolCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("numericCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("stringCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("formulaCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("errorCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("nullCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("dateCol");
            headerCols.add(headerCol);
            /* Last column with header but no data
             * Keep this column as the last column to
             * cover the IndexOutOfBounds test for
             * SWAT-1737
             */
            headerCol = new CellData();
            headerCol.setFormattedValue("lastNullCol");
            headerCols.add(headerCol);
            RowData headerRow = new RowData();
            headerRow.setValues(headerCols);
            List<CellData> dataCols = Lists.newArrayList();
            CellData dataColBool = new CellData();
            dataColBool.setEffectiveValue(new ExtendedValue().setBoolValue(true));
            dataCols.add(dataColBool);
            CellData dataColNum = new CellData();
            dataColNum.setEffectiveValue(new ExtendedValue().setNumberValue(44.50));
            dataCols.add(dataColNum);
            CellData dataColStr = new CellData();
            dataColStr.setEffectiveValue(new ExtendedValue().setStringValue("snaplogic"));
            dataCols.add(dataColStr);
            CellData dataColFormula = new CellData();
            dataColFormula.setEffectiveValue(new ExtendedValue().setFormulaValue("=C12+C13"));
            dataCols.add(dataColFormula);
            CellData dataColErr = new CellData();
            dataColErr.setEffectiveValue(new ExtendedValue().setErrorValue(
                    new ErrorValue().setType("N/A")));
            dataCols.add(dataColErr);
            CellData dataColNull = new CellData();
            dataColNull.setEffectiveValue(null);
            dataCols.add(dataColNull);
            CellData dataColDate = new CellData();
            dataColDate.setEffectiveValue(new ExtendedValue().setNumberValue(42000.5d));
            CellFormat dateCellFormat = new CellFormat();
            NumberFormat dateNumberFormat = new NumberFormat();
            dateNumberFormat.setType("DATE");
            dateCellFormat.setNumberFormat(dateNumberFormat);
            dataColDate.setEffectiveFormat(dateCellFormat);
            dataCols.add(dataColDate);
            /* Adding null explicitly to indicate the last column has no data
             * IMPORTANT: The last data column (corresponding to column header
             * "nullDataCol" needs to be kept null to test an edge case.
             */
            dataCols.add(null);
            RowData[] dataArray = new RowData[2];
            RowData dataRow = new RowData();
            dataRow.setValues(dataCols);
            /* Add an empty row in the beginning
             * to test for null pointer errors; SNAP-4773
             */
            RowData emptyRow = new RowData();
            dataArray[0] = emptyRow;
            dataArray[1] = dataRow;
            List<RowData> rowDataList = Lists.asList(headerRow, dataArray);
            GridData gridData = new GridData();
            gridData.setRowData(rowDataList);
            return Lists.asList(gridData, new GridData[0]);
        }

        @Override
        protected List<ValueRange> readWorksheetNoGridInfo(String spreadsheetId,
                                                           String worksheetName) {
            String COL_DATA = "Data%s%s";
            // spreadsheet with header and 3 rows
            List<Object> headerRow = Lists.newArrayList();
            List<Object> row1 = Lists.newArrayList();
            List<Object> row2 = Lists.newArrayList();
            List<Object> row3 = Lists.newArrayList();
            String dateStr = "2013-08-29";
            LocalDate dateObj = LocalDate.parse(dateStr);
            for (int i = 1; i <= 5; i++) {
                headerRow.add(String.format(FIELD, i));
                row1.add(String.format(COL_DATA, "1", i)); //String data row
                row2.add(dateObj); // Date data row
                row3.add(i); // Number data row
            }
            List<List<Object>> range1 = Lists.newArrayList();
            range1.add(headerRow);
            range1.add(row1);
            List<List<Object>> range2 = Lists.newArrayList();
            range2.add(row2);
            range2.add(row3);
            ValueRange valRange1 = new ValueRange();
            valRange1.setValues(range1);
            ValueRange valRange2 = new ValueRange();
            valRange2.setValues(range2);
            List<ValueRange> valueRangeList = Lists.newArrayList(valRange1, valRange2);
            return valueRangeList;
        }

        @Override
        protected String getId(Drive drive, String title) {
            return null;
        }

        @Override
        protected void initSpreadsheetAndDriveServices() {
            // NO OP
        }
    }

    /**
     * For testing {@link WorksheetReader} to test extra data column with no header case
     */
    public static final class MockReaderForExtraDataColTest extends WorksheetReader {
        @Override
        protected List<GridData> readWorksheet(String spreadsheetId, String range) {
            RowData[] dataArray = new RowData[1];
            List<CellData> headerCols = Lists.newArrayList();
            CellData headerCol = new CellData();
            headerCol.setFormattedValue("boolCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("numericCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("stringCol");
            headerCols.add(headerCol);
            headerCol = new CellData();
            headerCol.setFormattedValue("errorCol");
            headerCols.add(headerCol);
            RowData headerRow = new RowData();
            headerRow.setValues(headerCols);
            // Data Row with one extra data column and no header
            List<CellData> dataCols = Lists.newArrayList();
            CellData dataColBool = new CellData();
            dataColBool.setEffectiveValue(new ExtendedValue().setBoolValue(true));
            dataCols.add(dataColBool);
            CellData dataColNum = new CellData();
            dataColNum.setEffectiveValue(new ExtendedValue().setNumberValue(44.50));
            dataCols.add(dataColNum);
            CellData dataColStr = new CellData();
            dataColStr.setEffectiveValue(new ExtendedValue().setStringValue("snaplogic"));
            dataCols.add(dataColStr);
            CellData dataColErr = new CellData();
            dataColErr.setEffectiveValue(new ExtendedValue().setErrorValue(
                    new ErrorValue().setType("N/A")));
            dataCols.add(dataColErr);
            CellData extraColStr = new CellData();
            extraColStr.setEffectiveValue(new ExtendedValue().setStringValue("extra"));
            dataCols.add(extraColStr);
            RowData extraColRow = new RowData();
            extraColRow.setValues(dataCols);
            dataArray[0] = extraColRow;
            List<RowData> rowDataList = Lists.asList(headerRow, dataArray);
            GridData gridData = new GridData();
            gridData.setRowData(rowDataList);
            return Lists.asList(gridData, new GridData[0]);
        }

        @Override
        protected List<ValueRange> readWorksheetNoGridInfo(String spreadsheetId,
                                                           String worksheetName) {
            String COL_DATA = "Data%s%s";
            // spreadsheet with
            List<Object> headerRow = Lists.newArrayList();
            List<Object> row1 = Lists.newArrayList();
            List<Object> row2 = Lists.newArrayList();
            List<Object> row3 = Lists.newArrayList();
            for (int i = 1; i <= 5; i++) {
                // Number of header cols < num of data columns
                if (i < 5) {
                    headerRow.add(String.format(FIELD, i));
                }
                row1.add(String.format(COL_DATA, "1", i));
                row2.add(String.format(COL_DATA, "2", i));
                row3.add(String.format(COL_DATA, "3", i));
            }
            List<List<Object>> range1 = Lists.newArrayList();
            range1.add(headerRow);
            range1.add(row1);
            List<List<Object>> range2 = Lists.newArrayList();
            range2.add(row2);
            range2.add(row3);
            ValueRange valRange1 = new ValueRange();
            valRange1.setValues(range1);
            ValueRange valRange2 = new ValueRange();
            valRange2.setValues(range2);
            List<ValueRange> valueRangeList = Lists.newArrayList(valRange1, valRange2);
            return valueRangeList;
        }
    }

    /**
     * For testing {@link WorksheetReader} if a range of cells (an entire batch)
     * are empty and in between rows with data. The range of empty cells is returned as
     * null from the spreadsheet. Test this case to make sure no NPE is thrown.
     */
    public static final class MockReaderForNullRangeTest extends WorksheetReader {
        @Override
        protected List<ValueRange> readWorksheetNoGridInfo(String spreadsheetId,
                                                           String worksheetName) {
            String COL_DATA = "Data%s%s";
            // spreadsheet with header and 3 rows with 2 empty rows in between
            List<Object> headerRow = Lists.newArrayList();
            List<Object> row1 = Lists.newArrayList();
            List<Object> row2 = Lists.newArrayList();
            List<Object> row3 = Lists.newArrayList();
            for (int i = 1; i <= 5; i++) {
                headerRow.add(String.format(FIELD, i));
                row1.add(String.format(COL_DATA, "1", i));
                row2.add(String.format(COL_DATA, "2", i));
                row3.add(i); // Number data row
            }
            List<List<Object>> range1 = Lists.newArrayList();
            range1.add(headerRow);
            range1.add(row1);
            List<List<Object>> range3 = Lists.newArrayList();
            range3.add(row2);
            range3.add(row3);
            ValueRange valRange1 = new ValueRange();
            valRange1.setValues(range1);
            // Case where a batch of rows are empty in between rows with data
            ValueRange valRange2 = new ValueRange();
            valRange2.setValues(null);
            ValueRange valRange3 = new ValueRange();
            valRange3.setValues(range3);
            List<ValueRange> valueRangeList = Lists.newArrayList(valRange1, valRange2, valRange3);
            return valueRangeList;
        }

    }

    @TestFixture(snap = MockReaderForDataTypesTest.class)
    public void testReaderWithDefaultColumnTypes(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderForDataTypesTest.class,
            propertyOverrides = {"$settings.preserveDataTypes.value", "true"})
    public void testReaderWithActualColumnTypes(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderForExtraDataColTest.class,
            propertyOverrides = {"$settings.KeyHeaderExists.value", "false",
                                 "$settings.preserveDataTypes.value", "true"})
    public void testReaderWithExtraColumnNoHeaderChecked(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderForExtraDataColTest.class,
            propertyOverrides = {"$settings.preserveDataTypes.value", "true"})
    public void testReaderWithExtraColumnWithHeaderChecked(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderForExtraDataColTest.class,
            propertyOverrides = {"$settings.KeyHeaderExists.value", "false"})
    public void testReaderWithExtraColNoHdrChkdDefaultDataType(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderForExtraDataColTest.class)
    public void testReaderWithExtraColWithHdrChkdDefaultDataType(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderForNullRangeTest.class,
            propertyOverrides = {"$settings.KeyHeaderExists.value", "false"})
    public void testReaderWithNullRange(TestResult testResult) {
    }

    @TestFixture(snap = WorksheetReader.class,
            properties = "data/read_reader_spreadsheettitle_spaces_properties.json")
    public void testReaderWithBlankSpaceInSpreadsheetTitle(TestResult testResult) {
    }

    @TestFixture(snap = WorksheetReader.class,
            properties = "data/read_reader_worksheettitle_spaces_properties.json")
    public void testReaderWithBlankSpaceInWorksheetTitle(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderRetry.class,
            propertyOverrides = {"$settings.KeyHeaderExists.value", "false"})
    public void testReaderRetry(TestResult result) {
        assertEquals(1, ((MockReaderRetry) result.getSnap()).retries);
    }

    @TestFixture(snap = MockReaderEmptyRowsTest.class)
    public void testReaderIgnoreEmptyRow(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderEmptyRowsTest.class,
            propertyOverrides = {"$settings.KeySpreadsheet.value", "\"Some 'quoted' text\""})
    public void testReaderWithQuoteInSpreadsheetName() {
    }


    @TestFixture(snap = WorksheetReader.class,
            properties = "data/read_reader_spreadsheettitle_spreadsheetname.json")
    public void testReaderWithMultipleFilesWithSameName(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderEmptyRowsTest.class,
            properties = "data/read_reader_spreadsheettitle_spreadsheetid.json")
    public void testReaderWithSpreadsheetId(TestResult testResult) {
    }

    @TestFixture(snap = MockReaderEmptyRowsTest.class,
            properties = "data/read_reader_spreadsheet_id_and_name.json")
    public void testReaderWithSpreadsheetNameAndId(TestResult testResult) {
    }


}
